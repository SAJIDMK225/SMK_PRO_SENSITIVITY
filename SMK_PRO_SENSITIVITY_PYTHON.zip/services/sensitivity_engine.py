"""
Rules-Based Deterministic Sensitivity Engine for SMK PRO SENSITIVITY.
Calculates optimal 0-200 sensitivity settings based on device hardware and player mechanics.

DISCLAIMER:
This engine is a mathematical recommendation calculator based on screen refresh dynamics,
touch sampling rates, and player HUD ergonomics. It does NOT promise 100% headshots and
NEVER interacts with, injects, or modifies game files or memory. All settings are manual.
"""
from typing import Dict, Any, Tuple


class SensitivityEngine:
    """Deterministic rules-based Free Fire sensitivity calculator."""

    MIN_SENS = 0
    MAX_SENS = 200

    @classmethod
    def clamp(cls, value: float) -> int:
        """Clamps any calculated value strictly between 0 and 200."""
        return max(cls.MIN_SENS, min(cls.MAX_SENS, int(round(value))))

    @classmethod
    def calculate(
        cls,
        refresh_rate: int = 60,
        fps_support: int = 60,
        aim_style: str = "headshot_drag",
        graphics: str = "smooth",
        hud_fingers: int = 2,
        gyro_mode: str = "disabled",
        dpi_factor: float = 1.0,
        base_general_override: int = 0
    ) -> Dict[str, Any]:
        """
        Calculates all 6 sensitivity channels.
        Returns a dictionary with values and diagnostic explanation.
        """
        # 1. Base Starting Sensitivity
        if base_general_override > 0:
            base_general = float(base_general_override)
        else:
            # Baseline is adjusted inversely to refresh rate:
            # High Hz (120Hz/144Hz) has fast digitizer response, so baseline is ~175.
            # Low Hz (60Hz) needs higher drag velocity multiplier (~195) to complete 1-tap flick.
            if refresh_rate >= 144:
                base_general = 168.0
            elif refresh_rate >= 120:
                base_general = 176.0
            elif refresh_rate >= 90:
                base_general = 184.0
            else:
                base_general = 195.0

        # 2. Aim Style Adjustments
        aim_style = aim_style.lower()
        if "headshot" in aim_style or "drag" in aim_style:
            # High flick drag on general & red dot for instant upward head targeting
            general_mod = +6.0
            red_dot_mod = +4.0
            scope2_mod = -2.0
            scope4_mod = -4.0
            sniper_mod = -10.0
            free_look_mod = +5.0
        elif "speed" in aim_style or "rush" in aim_style:
            # High 360 degree quick turns
            general_mod = +12.0
            red_dot_mod = +8.0
            scope2_mod = +5.0
            scope4_mod = +2.0
            sniper_mod = -5.0
            free_look_mod = +15.0
        elif "sniper" in aim_style or "precision" in aim_style:
            # Steady ADS for long-range AWM / M82B tracking
            general_mod = -8.0
            red_dot_mod = -12.0
            scope2_mod = -15.0
            scope4_mod = -18.0
            sniper_mod = +12.0
            free_look_mod = -5.0
        else:  # Balanced
            general_mod = 0.0
            red_dot_mod = -5.0
            scope2_mod = -10.0
            scope4_mod = -15.0
            sniper_mod = -20.0
            free_look_mod = 0.0

        # 3. Graphics Preset Adjustments
        # Lower graphics = less frame jitter, higher frame consistency
        if graphics.lower() == "smooth":
            gfx_mod = +3.0
        elif graphics.lower() == "ultra":
            gfx_mod = -2.0
        elif graphics.lower() == "max":
            gfx_mod = -4.0
        else:
            gfx_mod = 0.0

        # 4. Claw HUD Finger Factor
        # 2-finger players have smaller thumb travel arc -> need higher sensitivity.
        # 4/5 finger claw players have dedicated aim finger -> can control lower, steadier sens.
        if hud_fingers <= 2:
            claw_mod = +5.0
        elif hud_fingers == 3:
            claw_mod = +2.0
        elif hud_fingers >= 4:
            claw_mod = -4.0
        else:
            claw_mod = 0.0

        # 5. Gyroscope Sensor Adjustments
        if gyro_mode.lower() in ("always", "always_on"):
            gyro_scope_mod = -10.0  # Wrist assists ADS, so screen sens can be calmer
            gyro_general_mod = -5.0
        elif gyro_mode.lower() in ("scope", "scope_only"):
            gyro_scope_mod = -6.0
            gyro_general_mod = 0.0
        else:
            gyro_scope_mod = 0.0
            gyro_general_mod = 0.0

        # Apply calculations
        gen = (base_general + general_mod + gfx_mod + claw_mod + gyro_general_mod) * dpi_factor
        red = (gen * 0.94 + red_dot_mod)
        s2 = (gen * 0.88 + scope2_mod + gyro_scope_mod)
        s4 = (gen * 0.82 + scope4_mod + gyro_scope_mod)
        snp = (gen * 0.55 + sniper_mod + gyro_scope_mod)
        fl = (gen * 0.90 + free_look_mod)

        results = {
            "general": cls.clamp(gen),
            "red_dot": cls.clamp(red),
            "scope_2x": cls.clamp(s2),
            "scope_4x": cls.clamp(s4),
            "sniper": cls.clamp(snp),
            "free_look": cls.clamp(fl),
            "metadata": {
                "refresh_rate": refresh_rate,
                "aim_style": aim_style,
                "hud_fingers": hud_fingers,
                "graphics": graphics,
                "gyro_mode": gyro_mode,
            }
        }
        return results

    @classmethod
    def get_calibration_guide(cls) -> str:
        """Returns training ground calibration steps for users."""
        return (
            "TRAINING GROUND CALIBRATION STEPS:\n"
            "1. Enter Training Ground in Free Fire and pick an assault rifle (e.g. M4A1 or AK) and a shotgun (M1887).\n"
            "2. Stand 15 meters from the stationary target dummy.\n"
            "3. Perform standard 'J-drag' or upward flick drag:\n"
            "   - If your crosshair stays glued to the chest and doesn't lift: Increase 'General' by +4 to +6.\n"
            "   - If your bullets fly above the dummy's head: Decrease 'General' by -4.\n"
            "4. Switch to Red Dot and 2x Scope, repeat drag while running sideways.\n"
            "5. Fine-tune until 4 out of 5 quick drags lock onto the head consistently.\n"
            "6. Save the calibrated numbers as a custom profile inside this app!"
        )
