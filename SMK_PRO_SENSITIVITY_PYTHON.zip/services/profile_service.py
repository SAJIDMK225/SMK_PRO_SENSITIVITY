"""
Profile Management Service for SMK PRO SENSITIVITY.
Coordinates profile CRUD, cloning, comparison, and validation.
"""
from typing import List, Dict, Any, Optional, Tuple
from database.db import DatabaseManager


class ProfileService:
    """Business logic for sensitivity profiles."""

    @classmethod
    def list_all(cls) -> List[Dict[str, Any]]:
        return DatabaseManager.get_all_profiles()

    @classmethod
    def get_by_name(cls, name: str) -> Optional[Dict[str, Any]]:
        return DatabaseManager.get_profile_by_name(name)

    @classmethod
    def save_or_update(
        cls,
        name: str,
        general: int,
        red_dot: int,
        scope_2x: int,
        scope_4x: int,
        sniper: int,
        free_look: int,
        aim_style: str = "Balanced",
        device_model: str = "",
        refresh_rate: int = 60,
        hud_fingers: int = 2,
        notes: str = ""
    ) -> Tuple[bool, str]:
        if not name or not name.strip():
            return False, "Profile name cannot be empty."

        # Validate values in range 0-200
        for val, label in [
            (general, "General"), (red_dot, "Red Dot"), (scope_2x, "2x Scope"),
            (scope_4x, "4x Scope"), (sniper, "Sniper"), (free_look, "Free Look")
        ]:
            if not (0 <= val <= 200):
                return False, f"{label} sensitivity must be between 0 and 200."

        DatabaseManager.save_profile(
            name=name.strip(),
            general=general,
            red_dot=red_dot,
            scope_2x=scope_2x,
            scope_4x=scope_4x,
            sniper=sniper,
            free_look=free_look,
            aim_style=aim_style,
            device_model=device_model,
            refresh_rate=refresh_rate,
            hud_fingers=hud_fingers,
            notes=notes
        )
        return True, f"Profile '{name.strip()}' saved successfully."

    @classmethod
    def duplicate(cls, source_profile_name: str, new_name: str) -> Tuple[bool, str]:
        source = DatabaseManager.get_profile_by_name(source_profile_name)
        if not source:
            return False, f"Source profile '{source_profile_name}' not found."

        return cls.save_or_update(
            name=new_name,
            general=source["general"],
            red_dot=source["red_dot"],
            scope_2x=source["scope_2x"],
            scope_4x=source["scope_4x"],
            sniper=source["sniper"],
            free_look=source["free_look"],
            aim_style=source["aim_style"],
            device_model=source["device_model"],
            refresh_rate=source["refresh_rate"],
            hud_fingers=source["hud_fingers"],
            notes=f"Copy of {source_profile_name}. " + (source["notes"] or "")
        )

    @classmethod
    def compare(cls, p1_name: str, p2_name: str) -> Optional[Dict[str, Any]]:
        p1 = DatabaseManager.get_profile_by_name(p1_name)
        p2 = DatabaseManager.get_profile_by_name(p2_name)
        if not p1 or not p2:
            return None

        fields = ["general", "red_dot", "scope_2x", "scope_4x", "sniper", "free_look"]
        diffs = {}
        for f in fields:
            diffs[f] = {
                "p1_val": p1[f],
                "p2_val": p2[f],
                "delta": p2[f] - p1[f]
            }

        return {
            "p1": p1,
            "p2": p2,
            "diffs": diffs
        }

    @classmethod
    def delete(cls, profile_id: int) -> bool:
        return DatabaseManager.delete_profile(profile_id)
