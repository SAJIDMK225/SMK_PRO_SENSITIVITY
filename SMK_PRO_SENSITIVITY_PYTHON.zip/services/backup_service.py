"""
Offline Backup & Restore Service for SMK PRO SENSITIVITY.
Generates structured, checksum-protected JSON archives and safely restores data.
"""
import json
import os
import hashlib
from datetime import datetime
from typing import Tuple, Dict, Any
from database.db import DatabaseManager
from core.config import APP_VERSION, get_app_dir


class BackupService:
    """Manages offline exports and secure data restorations."""

    BACKUP_MAGIC = "SMK_PRO_BACKUP"

    @classmethod
    def _compute_checksum(cls, data_dict: dict) -> str:
        """Computes SHA256 of the serialized data excluding the checksum itself."""
        serialized = json.dumps(data_dict, sort_keys=True)
        return hashlib.sha256(serialized.encode("utf-8")).hexdigest()

    @classmethod
    def create_backup_data(cls) -> Dict[str, Any]:
        """Collects database tables into a structured dict with metadata."""
        profiles = DatabaseManager.get_all_profiles()
        custom_phones = DatabaseManager.search_phones()
        feedback = DatabaseManager.get_all_feedback()

        payload = {
            "magic": cls.BACKUP_MAGIC,
            "version": APP_VERSION,
            "created_at": datetime.now().isoformat(),
            "data": {
                "profiles": profiles,
                "phone_devices": custom_phones,
                "feedback": feedback
            }
        }
        checksum = cls._compute_checksum(payload["data"])
        payload["checksum"] = checksum
        return payload

    @classmethod
    def export_to_file(cls, target_path: str = "") -> Tuple[bool, str]:
        """Writes backup JSON to disk."""
        try:
            if not target_path:
                filename = f"SMK_PRO_Backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
                target_path = os.path.join(get_app_dir(), filename)

            payload = cls.create_backup_data()
            with open(target_path, "w", encoding="utf-8") as f:
                json.dump(payload, f, indent=2, ensure_ascii=False)

            return True, target_path
        except Exception as e:
            return False, f"Export failed: {str(e)}"

    @classmethod
    def validate_backup_data(cls, payload: Any) -> Tuple[bool, str]:
        """Strict validation of structure, magic tag, and SHA256 checksum."""
        if not isinstance(payload, dict):
            return False, "Backup content must be a JSON object."

        if payload.get("magic") != cls.BACKUP_MAGIC:
            return False, "Unrecognized backup file. Missing SMK_PRO_BACKUP signature."

        if "data" not in payload or "checksum" not in payload:
            return False, "Malformed backup file. Missing data or integrity checksum."

        computed = cls._compute_checksum(payload["data"])
        if computed != payload["checksum"]:
            return False, "Integrity check failed! Backup file has been modified or corrupted."

        data = payload["data"]
        if not isinstance(data.get("profiles", []), list):
            return False, "Invalid profiles payload structure."

        return True, "Backup file verified successfully."

    @classmethod
    def restore_from_data(cls, payload: dict) -> Tuple[bool, str]:
        """Restores verified backup payload into local SQLite database."""
        valid, msg = cls.validate_backup_data(payload)
        if not valid:
            return False, msg

        data = payload["data"]
        restored_profiles = 0
        restored_phones = 0

        with DatabaseManager.get_connection() as conn:
            cursor = conn.cursor()
            
            # Restore Profiles
            for p in data.get("profiles", []):
                cursor.execute("""
                    INSERT INTO profiles 
                    (name, general, red_dot, scope_2x, scope_4x, sniper, free_look, 
                     aim_style, device_model, refresh_rate, hud_fingers, notes, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(name) DO UPDATE SET
                        general = excluded.general,
                        red_dot = excluded.red_dot,
                        scope_2x = excluded.scope_2x,
                        scope_4x = excluded.scope_4x,
                        sniper = excluded.sniper,
                        free_look = excluded.free_look,
                        aim_style = excluded.aim_style,
                        device_model = excluded.device_model,
                        refresh_rate = excluded.refresh_rate,
                        hud_fingers = excluded.hud_fingers,
                        notes = excluded.notes,
                        updated_at = excluded.updated_at
                """, (
                    p.get("name"), p.get("general", 180), p.get("red_dot", 170),
                    p.get("scope_2x", 160), p.get("scope_4x", 150), p.get("sniper", 120),
                    p.get("free_look", 180), p.get("aim_style", "Balanced"),
                    p.get("device_model", ""), p.get("refresh_rate", 60),
                    p.get("hud_fingers", 2), p.get("notes", ""),
                    p.get("created_at", datetime.now().isoformat()),
                    datetime.now().isoformat()
                ))
                restored_profiles += 1

            # Restore Phone records
            for dev in data.get("phone_devices", []):
                cursor.execute("""
                    INSERT OR IGNORE INTO phone_devices 
                    (brand, model, ram_gb, storage_gb, refresh_rate, chipset, fps_support, 
                     verification_status, recommended_general, recommended_red_dot, notes)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    dev.get("brand"), dev.get("model"), dev.get("ram_gb", 6),
                    dev.get("storage_gb", 128), dev.get("refresh_rate", 60),
                    dev.get("chipset", "Unknown"), dev.get("fps_support", 60),
                    dev.get("verification_status", "user_confirmed"),
                    dev.get("recommended_general", 180), dev.get("recommended_red_dot", 170),
                    dev.get("notes", "")
                ))
                restored_phones += 1

            conn.commit()

        return True, f"Successfully restored {restored_profiles} profiles and {restored_phones} device records."

    @classmethod
    def restore_from_file(cls, filepath: str) -> Tuple[bool, str]:
        """Loads and restores from a local file path."""
        if not os.path.exists(filepath):
            return False, f"File not found: {filepath}"
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                payload = json.load(f)
            return cls.restore_from_data(payload)
        except Exception as e:
            return False, f"Failed to parse backup file: {str(e)}"
