"""
SMK PRO SENSITIVITY - Main Entry Point.
A complete, professional, offline-first Free Fire sensitivity optimizer built with Python & Kivy.
"""
import sys
import os

# Ensure current directory is in sys.path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from kivy.app import App
from kivy.core.window import Window
from kivy.uix.screenmanager import ScreenManager, FadeTransition
from kivy.config import Config

# Configure default phone viewport aspect ratio for desktop preview
Config.set('graphics', 'width', '420')
Config.set('graphics', 'height', '780')
Config.set('kivy', 'exit_on_escape', '0')

from core.config import APP_NAME
from database.db import DatabaseManager
from screens.splash_screen import SplashScreen
from screens.home_screen import HomeScreen
from screens.generator_screen import GeneratorScreen
from screens.device_screen import DeviceScreen
from screens.phone_db_screen import PhoneDatabaseScreen
from screens.profiles_screen import ProfilesScreen
from screens.admin_login_screen import AdminLoginScreen
from screens.admin_panel_screen import AdminPanelScreen
from screens.feedback_screen import FeedbackScreen
from screens.settings_screen import SettingsScreen
from screens.backup_screen import BackupScreen
from screens.help_screen import HelpScreen
from screens.about_screen import AboutScreen


class SMKProSensitivityApp(App):
    """Main application lifecycle controller."""

    def build(self):
        self.title = APP_NAME
        Window.clearcolor = (0.04, 0.04, 0.07, 1.0)

        # 1. Initialize SQLite Database & Seeds
        DatabaseManager.init_database()

        # 2. Setup Screen Manager with Fade Transition
        self.sm = ScreenManager(transition=FadeTransition(duration=0.25))

        # 3. Add all 13 working screens
        self.sm.add_widget(SplashScreen())
        self.sm.add_widget(HomeScreen())
        self.sm.add_widget(GeneratorScreen())
        self.sm.add_widget(DeviceScreen())
        self.sm.add_widget(PhoneDatabaseScreen())
        self.sm.add_widget(ProfilesScreen())
        self.sm.add_widget(AdminLoginScreen())
        self.sm.add_widget(AdminPanelScreen())
        self.sm.add_widget(FeedbackScreen())
        self.sm.add_widget(SettingsScreen())
        self.sm.add_widget(BackupScreen())
        self.sm.add_widget(HelpScreen())
        self.sm.add_widget(AboutScreen())

        # Bind hardware Android back key / Escape on desktop
        Window.bind(on_keyboard=self._on_keyboard_handler)

        return self.sm

    def _on_keyboard_handler(self, window, key, scancode, codepoint, modifier):
        # 27 is the Escape key on Desktop / Back Button on Android
        if key == 27:
            if self.sm.current != "home" and self.sm.current != "splash":
                self.sm.current = "home"
                return True
        return False


if __name__ == "__main__":
    SMKProSensitivityApp().run()
