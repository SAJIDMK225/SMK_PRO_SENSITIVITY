"""
Authentication & Access Control Security Engine for SMK PRO SENSITIVITY.
Implements PBKDF2-HMAC-SHA256 salted password hashing, rate limiting, and session security.
"""
import hashlib
import secrets
import hmac
import time
from datetime import datetime
from typing import Tuple, Optional
from database.db import DatabaseManager
from core.config import INITIAL_OWNER_USERNAME, MAX_LOGIN_ATTEMPTS, LOCKOUT_DURATION_SECONDS, SESSION_INACTIVITY_TIMEOUT_SECONDS


class AdminAuthService:
    """Handles admin credentials verification, lockout, and password management."""
    
    PBKDF2_ITERATIONS = 120_000
    
    _current_session_token: Optional[str] = None
    _last_activity_time: float = 0.0

    @classmethod
    def _hash_password(cls, password: str, salt: str) -> str:
        """Derives key using PBKDF2-HMAC-SHA256."""
        derived = hashlib.pbkdf2_hmac(
            "sha256",
            password.encode("utf-8"),
            salt.encode("utf-8"),
            cls.PBKDF2_ITERATIONS
        )
        return derived.hex()

    @classmethod
    def is_first_run(cls) -> bool:
        """Checks if owner credentials need initial setup."""
        with DatabaseManager.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) as cnt FROM admin_auth WHERE username = ?", (INITIAL_OWNER_USERNAME,))
            row = cursor.fetchone()
            return row["cnt"] == 0

    @classmethod
    def setup_initial_owner_password(cls, password: str) -> Tuple[bool, str]:
        """Sets up the initial owner password on first run."""
        if len(password) < 6:
            return False, "Password must be at least 6 characters long."
            
        salt = secrets.token_hex(16)
        pwd_hash = cls._hash_password(password, salt)
        now = datetime.now().isoformat()
        
        with DatabaseManager.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO admin_auth 
                (username, password_hash, salt, failed_attempts, lockout_until, created_at, updated_at)
                VALUES (?, ?, ?, 0, 0.0, ?, ?)
                ON CONFLICT(username) DO UPDATE SET
                    password_hash = excluded.password_hash,
                    salt = excluded.salt,
                    failed_attempts = 0,
                    lockout_until = 0.0,
                    updated_at = excluded.updated_at
            """, (INITIAL_OWNER_USERNAME, pwd_hash, salt, now, now))
            conn.commit()
            
        return True, "Initial owner credentials successfully configured."

    @classmethod
    def authenticate(cls, username: str, password: str) -> Tuple[bool, str]:
        """
        Authenticates admin user.
        Applies lockout protection, constant-time compare, and generic error messages.
        """
        now_ts = time.time()
        username = username.strip()
        
        with DatabaseManager.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM admin_auth WHERE username = ?", (username,))
            user = cursor.fetchone()
            
            if not user:
                # Still compute dummy hash to avoid timing side-channels
                cls._hash_password(password, "dummy_salt_for_timing_safety")
                return False, "Invalid username or password."
                
            # Check lockout
            lockout_until = user["lockout_until"]
            if lockout_until > now_ts:
                remaining = int((lockout_until - now_ts) / 60) + 1
                return False, f"Too many failed attempts. Locked out for ~{remaining} minute(s)."
                
            # Verify password
            computed_hash = cls._hash_password(password, user["salt"])
            if hmac.compare_digest(computed_hash, user["password_hash"]):
                # Success - reset attempts
                cursor.execute("""
                    UPDATE admin_auth 
                    SET failed_attempts = 0, lockout_until = 0.0, updated_at = ?
                    WHERE id = ?
                """, (datetime.now().isoformat(), user["id"]))
                conn.commit()
                
                # Create session
                cls._current_session_token = secrets.token_hex(24)
                cls._last_activity_time = time.time()
                return True, "Login successful."
            else:
                # Failed attempt
                failed = user["failed_attempts"] + 1
                new_lockout = 0.0
                if failed >= MAX_LOGIN_ATTEMPTS:
                    new_lockout = now_ts + LOCKOUT_DURATION_SECONDS
                    
                cursor.execute("""
                    UPDATE admin_auth 
                    SET failed_attempts = ?, lockout_until = ?, updated_at = ?
                    WHERE id = ?
                """, (failed, new_lockout, datetime.now().isoformat(), user["id"]))
                conn.commit()
                
                if new_lockout > 0:
                    return False, f"Too many failed attempts. Locked out for {int(LOCKOUT_DURATION_SECONDS / 60)} minutes."
                return False, "Invalid username or password."

    @classmethod
    def is_authenticated(cls) -> bool:
        """Checks if current session is active and not timed out."""
        if not cls._current_session_token:
            return False
        if time.time() - cls._last_activity_time > SESSION_INACTIVITY_TIMEOUT_SECONDS:
            cls.logout()
            return False
        cls._last_activity_time = time.time()
        return True

    @classmethod
    def logout(cls):
        """Clears active admin session."""
        cls._current_session_token = None
        cls._last_activity_time = 0.0

    @classmethod
    def change_password(cls, old_password: str, new_password: str) -> Tuple[bool, str]:
        """Allows password change when currently authenticated."""
        if not cls.is_authenticated():
            return False, "Authentication required to change password."
        if len(new_password) < 6:
            return False, "New password must be at least 6 characters long."
            
        with DatabaseManager.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM admin_auth WHERE username = ?", (INITIAL_OWNER_USERNAME,))
            user = cursor.fetchone()
            if not user:
                return False, "User not found."
                
            old_hash = cls._hash_password(old_password, user["salt"])
            if not hmac.compare_digest(old_hash, user["password_hash"]):
                return False, "Current password verification failed."
                
            new_salt = secrets.token_hex(16)
            new_hash = cls._hash_password(new_password, new_salt)
            now = datetime.now().isoformat()
            
            cursor.execute("""
                UPDATE admin_auth 
                SET password_hash = ?, salt = ?, updated_at = ?
                WHERE id = ?
            """, (new_hash, new_salt, now, user["id"]))
            conn.commit()
            
        return True, "Password updated successfully."
