"""
Local Key Management & License Validation System for SMK PRO SENSITIVITY.
Provides offline cryptographic key generation, duration licensing, and feature gating.

NOTE ON LOCAL SECURITY LIMITATIONS:
This key validation engine is fully local and offline. As with any client-side verification
system without an active internet server, a determined reverse engineer could tamper with
app bytecode or manipulate device clock timestamps. Local deactivation only alters the
records in the local SQLite database.
"""
import re
import secrets
import hashlib
from datetime import datetime, timedelta
from typing import Tuple, List, Dict, Any, Optional
from database.db import DatabaseManager


class KeyManager:
    """Manages offline pro keys generation, activation, expiration, and gating."""

    KEY_PREFIX = "SMK"
    CHECKSUM_SALT = "SMK_PRO_OFFLINE_SECRET_SALT_2026"

    @classmethod
    def _calculate_checksum(cls, payload: str) -> str:
        """Calculates 4-character deterministic hex checksum for a key payload."""
        h = hashlib.sha256((payload + cls.CHECKSUM_SALT).encode("utf-8")).hexdigest()
        return h[:4].upper()

    @classmethod
    def generate_key(cls, key_type: str = "lifetime", duration_days: int = 0, note: str = "") -> str:
        """
        Generates a 16-character structured key:
        Format: SMK-{TYPE_CODE}{RANDOM_8}-{CHECKSUM_4}
        Example: SMK-L7A3B9C2-4F1E
        """
        type_indicator = "L" if key_type == "lifetime" else f"D{min(duration_days, 999):03d}"
        random_part = secrets.token_hex(4).upper()  # 8 hex chars
        payload = f"{type_indicator}{random_part}"
        checksum = cls._calculate_checksum(payload)
        key_code = f"{cls.KEY_PREFIX}-{payload}-{checksum}"

        now = datetime.now().isoformat()
        with DatabaseManager.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO activation_keys 
                (key_code, key_type, duration_days, status, created_at, note)
                VALUES (?, ?, ?, 'unused', ?, ?)
            """, (key_code, key_type, duration_days, now, note))
            conn.commit()

        return key_code

    @classmethod
    def verify_key_format(cls, key_code: str) -> bool:
        """Checks syntactic format and internal checksum."""
        parts = key_code.strip().upper().split("-")
        if len(parts) != 3 or parts[0] != cls.KEY_PREFIX:
            return False
        payload = parts[1]
        checksum = parts[2]
        return cls._calculate_checksum(payload) == checksum

    @classmethod
    def activate_key(cls, key_code: str) -> Tuple[bool, str]:
        """
        Activates an unused key.
        Timer begins at first successful activation.
        """
        key_code = key_code.strip().upper()
        if not cls.verify_key_format(key_code):
            return False, "Invalid key structure or failed checksum."

        with DatabaseManager.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM activation_keys WHERE key_code = ?", (key_code,))
            key_record = cursor.fetchone()

            if not key_record:
                return False, "Key not found in local registry. Please ensure it was generated on this device or admin panel."

            if key_record["status"] == "active":
                return True, "Key is already actively licensed on this installation."

            if key_record["status"] == "revoked":
                return False, "This key was deactivated or revoked."

            if key_record["status"] == "expired":
                return False, "This key has expired."

            # Calculate activation and expiration
            now = datetime.now()
            activated_at_str = now.isoformat()
            expires_at_str = None

            if key_record["key_type"] == "limited":
                days = key_record["duration_days"] or 30
                expires_at = now + timedelta(days=days)
                expires_at_str = expires_at.isoformat()

            cursor.execute("""
                UPDATE activation_keys 
                SET status = 'active', activated_at = ?, expires_at = ?
                WHERE id = ?
            """, (activated_at_str, expires_at_str, key_record["id"]))

            # Store active key in app settings
            cursor.execute("""
                INSERT INTO app_settings (key, value) VALUES ('active_license_key', ?)
                ON CONFLICT(key) DO UPDATE SET value = excluded.value
            """, (key_code,))
            conn.commit()

        return True, "Key successfully activated! Pro features unlocked."

    @classmethod
    def is_pro_active(cls) -> bool:
        """
        Checks if the device has a currently valid active Pro license.
        Updates expired status if time window has passed.
        """
        with DatabaseManager.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT value FROM app_settings WHERE key = 'active_license_key'")
            row = cursor.fetchone()
            if not row or not row["value"]:
                return False

            key_code = row["value"]
            cursor.execute("SELECT * FROM activation_keys WHERE key_code = ?", (key_code,))
            key_record = cursor.fetchone()

            if not key_record or key_record["status"] != "active":
                return False

            # Check limited duration expiration
            if key_record["key_type"] == "limited" and key_record["expires_at"]:
                expires_at = datetime.fromisoformat(key_record["expires_at"])
                if datetime.now() > expires_at:
                    cursor.execute("""
                        UPDATE activation_keys SET status = 'expired' WHERE id = ?
                    """, (key_record["id"],))
                    cursor.execute("DELETE FROM app_settings WHERE key = 'active_license_key'")
                    conn.commit()
                    return False

            return True

    @classmethod
    def deactivate_key(cls, key_id: int) -> bool:
        """Locally revokes a key."""
        with DatabaseManager.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT key_code FROM activation_keys WHERE id = ?", (key_id,))
            row = cursor.fetchone()
            if not row:
                return False
            key_code = row["key_code"]

            cursor.execute("UPDATE activation_keys SET status = 'revoked' WHERE id = ?", (key_id,))
            cursor.execute("DELETE FROM app_settings WHERE key = 'active_license_key' AND value = ?", (key_code,))
            conn.commit()
            return True

    @classmethod
    def list_keys(cls, status_filter: str = "all") -> List[Dict[str, Any]]:
        """Returns list of generated keys with optional status filtering."""
        with DatabaseManager.get_connection() as conn:
            cursor = conn.cursor()
            if status_filter and status_filter.lower() != "all":
                cursor.execute("SELECT * FROM activation_keys WHERE status = ? ORDER BY id DESC", (status_filter.lower(),))
            else:
                cursor.execute("SELECT * FROM activation_keys ORDER BY id DESC")
            return [dict(row) for row in cursor.fetchall()]

    @classmethod
    def get_license_summary(cls) -> Dict[str, Any]:
        """Provides status summary for the UI."""
        with DatabaseManager.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT value FROM app_settings WHERE key = 'active_license_key'")
            row = cursor.fetchone()
            if not row or not row["value"]:
                return {"is_pro": False, "status": "Inactive", "type": "Free / Community"}

            key_code = row["value"]
            cursor.execute("SELECT * FROM activation_keys WHERE key_code = ?", (key_code,))
            key_record = cursor.fetchone()

            if not key_record:
                return {"is_pro": False, "status": "Inactive", "type": "Free"}

            is_active = cls.is_pro_active()
            return {
                "is_pro": is_active,
                "status": "Active" if is_active else "Expired",
                "key_code": key_record["key_code"],
                "type": "Lifetime" if key_record["key_type"] == "lifetime" else f"Limited ({key_record['duration_days']} days)",
                "activated_at": key_record["activated_at"],
                "expires_at": key_record["expires_at"] or "Never"
            }
