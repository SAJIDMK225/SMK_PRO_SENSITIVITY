"""
Localization dictionary and manager for SMK PRO SENSITIVITY.
Supports English, Roman Urdu, and Urdu Script.
"""

TRANSLATIONS = {
    "en": {
        # App Info
        "app_title": "SMK PRO SENSITIVITY",
        "app_tagline": "Pro Gaming Sensitivity & Calibration Tool",
        "disclaimer_banner": "Free Fire settings optimizer. Offline rules-based engine. Not affiliated with Garena.",
        
        # Navigation
        "nav_home": "Home",
        "nav_generator": "Generator",
        "nav_device": "My Device",
        "nav_phone_db": "Phone DB",
        "nav_profiles": "Profiles",
        "nav_admin": "Admin",
        "nav_feedback": "Feedback",
        "nav_settings": "Settings",
        "nav_backup": "Backup/Restore",
        "nav_help": "Help & Guide",
        "nav_about": "About & Privacy",
        
        # Actions
        "btn_generate": "GENERATE PRO SENSITIVITY",
        "btn_save_profile": "Save Profile",
        "btn_apply": "Apply Settings",
        "btn_copy": "Copy Values",
        "btn_copied": "Copied to Clipboard!",
        "btn_test_calibration": "Calibrate on Training Ground",
        "btn_login": "Login to Admin Panel",
        "btn_logout": "Logout",
        "btn_create_key": "Create Activation Key",
        "btn_activate_key": "Activate Pro Key",
        "btn_search": "Search Device",
        "btn_export_backup": "Export Backup",
        "btn_restore_backup": "Restore Backup",
        "btn_reset_defaults": "Reset Defaults",
        "btn_open_whatsapp": "Join WhatsApp Channel",
        "btn_open_youtube": "Visit YouTube Channel",
        "btn_submit_feedback": "Submit Feedback",
        "btn_share_feedback": "Share Feedback Text",
        "btn_cancel": "Cancel",
        "btn_confirm": "Confirm",
        "btn_delete": "Delete",
        "btn_duplicate": "Duplicate",
        "btn_compare": "Compare",
        
        # Sensitivities
        "sens_general": "General Sensitivity",
        "sens_red_dot": "Red Dot Sight",
        "sens_2x": "2x Scope",
        "sens_4x": "4x Scope",
        "sens_sniper": "Sniper Scope",
        "sens_free_look": "Free Camera Look",
        
        # Preferences
        "pref_refresh_rate": "Screen Refresh Rate",
        "pref_aim_style": "Aim & Drag Style",
        "pref_graphics": "Graphics Preset",
        "pref_hud_fingers": "HUD Claw Fingers",
        "pref_gyro": "Gyroscope Sensor",
        "pref_screen_dpi": "Screen DPI Sensitivity",
        
        # Aim Styles
        "aim_headshot_drag": "Fast Headshot Drag (Up-Flick)",
        "aim_balanced": "Balanced Movement & Spray",
        "aim_speed_rush": "Close-Range Rush & Quick 360",
        "aim_sniper_precision": "Long-Range Precision & Sniper",
        
        # Graphics
        "gfx_smooth": "Smooth (Max FPS / Low Lag)",
        "gfx_standard": "Standard (Balanced)",
        "gfx_ultra": "Ultra (HD High Res)",
        "gfx_max": "Max (Ultra HD 60-120fps)",
        
        # Gyro
        "gyro_off": "Disabled (Thumb Only)",
        "gyro_scope": "Scope Only (ADS)",
        "gyro_always": "Always On (Pro Gyro)",
        
        # Fingers
        "hud_2finger": "2 Finger (Thumb Player)",
        "hud_3finger": "3 Finger Claw",
        "hud_4finger": "4 Finger Claw",
        "hud_5finger": "5 Finger Pro Claw",
        
        # Key System
        "key_title": "SMK Pro Key System",
        "key_status_active": "PRO ACCESS ACTIVE",
        "key_status_inactive": "Standard Version (Enter Key for Pro)",
        "key_enter_prompt": "Enter your 16-character SMK Pro Key:",
        "key_invalid": "Invalid key format or checksum failed.",
        "key_expired": "This activation key has expired.",
        "key_activated_success": "Key successfully activated! Pro features unlocked.",
        "key_type_lifetime": "Lifetime License",
        "key_type_duration": "Limited Duration License",
        
        # Admin
        "admin_title": "Admin Dashboard",
        "admin_auth_title": "Admin Authorization",
        "admin_username": "Admin Username",
        "admin_password": "Password",
        "admin_first_run_title": "Initial Admin Password Setup",
        "admin_first_run_desc": "Set your secure owner password for privatesmk225. This password is saved locally with PBKDF2 salt.",
        "admin_confirm_password": "Confirm Password",
        "admin_btn_set_password": "Save & Initialize Admin",
        "admin_locked_out": "Too many failed attempts. Locked out for {minutes} min.",
        "admin_invalid_creds": "Invalid username or password.",
        "admin_manage_keys": "Manage Pro Activation Keys",
        "admin_system_stats": "System Diagnostics & Database",
        "admin_change_pass": "Change Admin Password",
        
        # Feedback & Settings
        "feedback_title": "Community Feedback",
        "feedback_rating": "Rating (1 to 5 Stars):",
        "feedback_comment": "Your experience or device tips:",
        "feedback_saved": "Feedback saved locally. You can copy/share it to WhatsApp.",
        "settings_theme": "Visual Theme",
        "settings_animations": "Enable Glowing Animations",
        "settings_reduced_motion": "Reduced Motion Mode",
        "settings_language": "App Language",
        "backup_title": "Offline Data Backup & Restore",
        "backup_export_info": "Exports your profiles, custom devices, and settings to a secure JSON file.",
        "backup_restore_info": "Select a previously exported SMK backup JSON to restore data.",
        "backup_created": "Backup saved successfully!",
        "backup_restored": "Data restored successfully!",
        "backup_invalid": "Invalid or corrupted backup file.",
        
        # Status labels
        "status_detected": "[Detected]",
        "status_verified": "[Verified]",
        "status_user_confirmed": "[User Confirmed]",
        "status_unknown": "[Unknown]",
    },
    
    "ur_ro": {
        # App Info
        "app_title": "SMK PRO SENSITIVITY",
        "app_tagline": "Pro Gamer Sensitivity & Calibration Engine",
        "disclaimer_banner": "Free Fire settings optimizer. Offline rules-based engine. Garena se koi taaluq nahi.",
        
        # Navigation
        "nav_home": "Home Dashboard",
        "nav_generator": "Sens Generator",
        "nav_device": "Mera Device",
        "nav_phone_db": "Phone Database",
        "nav_profiles": "Saved Profiles",
        "nav_admin": "Admin Panel",
        "nav_feedback": "Feedback",
        "nav_settings": "Settings",
        "nav_backup": "Backup/Restore",
        "nav_help": "Help & Guide",
        "nav_about": "About & Privacy",
        
        # Actions
        "btn_generate": "PRO SENSITIVITY NIKALEIN",
        "btn_save_profile": "Profile Save Karein",
        "btn_apply": "Settings Lagayein",
        "btn_copy": "Values Copy Karein",
        "btn_copied": "Clipboard me copy ho gaya!",
        "btn_test_calibration": "Training Ground Calibration",
        "btn_login": "Admin Login",
        "btn_logout": "Logout Karein",
        "btn_create_key": "Naya Key Banayein",
        "btn_activate_key": "Pro Key Activate Karein",
        "btn_search": "Phone Search Karein",
        "btn_export_backup": "Backup Export Karein",
        "btn_restore_backup": "Backup Restore Karein",
        "btn_reset_defaults": "Reset Defaults",
        "btn_open_whatsapp": "WhatsApp Channel Join Karein",
        "btn_open_youtube": "YouTube Channel Dekhein",
        "btn_submit_feedback": "Feedback Save Karein",
        "btn_share_feedback": "Feedback Text Share Karein",
        "btn_cancel": "Cancel",
        "btn_confirm": "Confirm Karein",
        "btn_delete": "Delete Karein",
        "btn_duplicate": "Copy/Duplicate",
        "btn_compare": "Muqabla (Compare)",
        
        # Sensitivities
        "sens_general": "General Sensitivity",
        "sens_red_dot": "Red Dot Sight",
        "sens_2x": "2x Scope",
        "sens_4x": "4x Scope",
        "sens_sniper": "Sniper Scope",
        "sens_free_look": "Free Look Camera",
        
        # Preferences
        "pref_refresh_rate": "Screen Refresh Rate (Hz)",
        "pref_aim_style": "Aim & Drag Style",
        "pref_graphics": "Graphics Setting",
        "pref_hud_fingers": "HUD Ungliyan (Claw)",
        "pref_gyro": "Gyroscope Sensor",
        "pref_screen_dpi": "Screen DPI Sensitivity",
        
        # Aim Styles
        "aim_headshot_drag": "Fast Headshot Drag (Up-Flick)",
        "aim_balanced": "Balanced Movement & Spray",
        "aim_speed_rush": "Close-Range Rush & 360",
        "aim_sniper_precision": "Long-Range Precision Sniper",
        
        # Graphics
        "gfx_smooth": "Smooth (Max FPS / Kam Lag)",
        "gfx_standard": "Standard (Normal)",
        "gfx_ultra": "Ultra (HD High)",
        "gfx_max": "Max (Ultra HD 60-120fps)",
        
        # Gyro
        "gyro_off": "Band (Sirf Angootha)",
        "gyro_scope": "Sirf Scope Me (ADS)",
        "gyro_always": "Hamesha On (Full Gyro)",
        
        # Fingers
        "hud_2finger": "2 Finger (Angootha)",
        "hud_3finger": "3 Finger Claw",
        "hud_4finger": "4 Finger Claw",
        "hud_5finger": "5 Finger Pro Claw",
        
        # Key System
        "key_title": "SMK Pro Key System",
        "key_status_active": "PRO ACCESS ACTIVE HAI",
        "key_status_inactive": "Standard Version (Pro key darj karein)",
        "key_enter_prompt": "Apna 16-character SMK Pro Key darj karein:",
        "key_invalid": "Ghalat key format ya checksum fail ho gaya.",
        "key_expired": "Ye activation key expire ho chuki hai.",
        "key_activated_success": "Key kamyabi se activate ho gayi! Pro features khul gaye.",
        "key_type_lifetime": "Lifetime License",
        "key_type_duration": "Limited Duration License",
        
        # Admin
        "admin_title": "Admin Dashboard",
        "admin_auth_title": "Admin Tasdeeq",
        "admin_username": "Admin Username",
        "admin_password": "Password",
        "admin_first_run_title": "Pehli Baar Admin Password Setup",
        "admin_first_run_desc": "privatesmk225 k liye apna secret owner password set karein. Ye PBKDF2 salt k sath local database me mehfooz rehta hai.",
        "admin_confirm_password": "Password Ki Tasdeeq Karein",
        "admin_btn_set_password": "Save & Initialize Karein",
        "admin_locked_out": "Bohat ziada ghalat koshishein. {minutes} minute intezar karein.",
        "admin_invalid_creds": "Ghalat username ya password.",
        "admin_manage_keys": "Pro Keys Manage Karein",
        "admin_system_stats": "System Stats & Database",
        "admin_change_pass": "Admin Password Badlein",
        
        # Feedback & Settings
        "feedback_title": "Community Feedback",
        "feedback_rating": "Rating (1 se 5 Sitare):",
        "feedback_comment": "Apna tajruba ya device tips likhein:",
        "feedback_saved": "Feedback phone me save ho gaya. Aap WhatsApp par share kar sakte hain.",
        "settings_theme": "Visual Theme",
        "settings_animations": "Glowing Animations On/Off",
        "settings_reduced_motion": "Reduced Motion Mode",
        "settings_language": "App Ki Zaban",
        "backup_title": "Offline Data Backup & Restore",
        "backup_export_info": "Apni tamam profiles aur custom devices JSON file me save karein.",
        "backup_restore_info": "Pehlay se bani hui SMK backup file choose kar k restore karein.",
        "backup_created": "Backup kamyabi se save ho gaya!",
        "backup_restored": "Data kamyabi se restore ho gaya!",
        "backup_invalid": "Backup file kharab ya na-qabil e qabool hai.",
        
        # Status labels
        "status_detected": "[Daryaft Shuda]",
        "status_verified": "[Tasdeeq Shuda]",
        "status_user_confirmed": "[Aap Ki Tasdeeq]",
        "status_unknown": "[Na-Maloom]",
    },
    
    "ur_ar": {
        # Urdu Script (Right-to-Left representation where supported)
        "app_title": "ایس ایم کے پرو سینسیٹیویٹی",
        "app_tagline": "پرو گیمنگ سینسیٹیویٹی اور کیلیبریشن ٹول",
        "disclaimer_banner": "فری فائر سیٹنگز آپٹیمائزر۔ آف لائن الگورتھم۔ گیرینا سے کوئی الحاق نہیں۔",
        
        # Navigation
        "nav_home": "ہوم",
        "nav_generator": "جنریٹر",
        "nav_device": "میرا ڈیوائس",
        "nav_phone_db": "فون ڈیٹا بیس",
        "nav_profiles": "پروفائلز",
        "nav_admin": "ایڈمن پینل",
        "nav_feedback": "فیڈ بیک",
        "nav_settings": "سیٹنگز",
        "nav_backup": "بیک اپ / بحالی",
        "nav_help": "رہنمائی",
        "nav_about": "ہمارے بارے میں",
        
        # Actions
        "btn_generate": "پرو سینسیٹیویٹی بنائیں",
        "btn_save_profile": "پروفائل محفوظ کریں",
        "btn_apply": "سیٹنگز لاگو کریں",
        "btn_copy": "کاپی کریں",
        "btn_copied": "کلپ بورڈ پر کاپی ہو گیا!",
        "btn_test_calibration": "ٹریننگ گراؤنڈ کیلیبریشن",
        "btn_login": "ایڈمن لاگ ان",
        "btn_logout": "لاگ آؤٹ",
        "btn_create_key": "نئی چابی بنائیں",
        "btn_activate_key": "پرو چابی ایکٹیویٹ کریں",
        "btn_search": "فون تلاش کریں",
        "btn_export_backup": "بیک اپ ایکسپورٹ کریں",
        "btn_restore_backup": "بیک اپ بحال کریں",
        "btn_reset_defaults": "ڈیفالٹ پر ری سیٹ کریں",
        "btn_open_whatsapp": "واٹس ایپ چینل",
        "btn_open_youtube": "یوٹیوب چینل",
        "btn_submit_feedback": "فیڈ بیک محفوظ کریں",
        "btn_share_feedback": "فیڈ بیک شیئر کریں",
        "btn_cancel": "منسوخ",
        "btn_confirm": "تصدیق کریں",
        "btn_delete": "حذف کریں",
        "btn_duplicate": "ڈپلیکیٹ",
        "btn_compare": "موازنہ کریں",
        
        # Sensitivities
        "sens_general": "جنرل سینسیٹیویٹی",
        "sens_red_dot": "ریڈ ڈاٹ سائیٹ",
        "sens_2x": "2x اسکوپ",
        "sens_4x": "4x اسکوپ",
        "sens_sniper": "سنائپر اسکوپ",
        "sens_free_look": "فری لک کیمرہ",
        
        # Preferences
        "pref_refresh_rate": "اسکرین ریفریش ریٹ",
        "pref_aim_style": "نشانہ اور ڈریگ انداز",
        "pref_graphics": "گرافکس سیٹنگ",
        "pref_hud_fingers": "انگلیاں (کلا)",
        "pref_gyro": "جائرواسکوپ سینسر",
        "pref_screen_dpi": "اسکرین ڈی پی آئی",
        
        # Aim Styles
        "aim_headshot_drag": "تیز ہیڈ شاٹ ڈریگ",
        "aim_balanced": "متوازن موومنٹ اور اسپرے",
        "aim_speed_rush": "قریبی حملہ اور تیز 360",
        "aim_sniper_precision": "طویل فاصلہ سنائپر درستگی",
        
        # Graphics
        "gfx_smooth": "ہموار (کم سے کم لیگ)",
        "gfx_standard": "معیاری (بیلنسڈ)",
        "gfx_ultra": "الٹرا (ہائی ریزولوشن)",
        "gfx_max": "میکس (فل الٹرا ایچ ڈی)",
        
        # Gyro
        "gyro_off": "بند (صرف انگوٹھا)",
        "gyro_scope": "صرف اسکوپ میں",
        "gyro_always": "ہمیشہ آن (فل جائرو)",
        
        # Fingers
        "hud_2finger": "2 انگلیاں (انگوٹھا پلیئر)",
        "hud_3finger": "3 انگلیاں کلا",
        "hud_4finger": "4 انگلیاں کلا",
        "hud_5finger": "5 انگلیاں پرو کلا",
        
        # Key System
        "key_title": "ایس ایم کے پرو کی سسٹم",
        "key_status_active": "پرو رسائی فعال ہے",
        "key_status_inactive": "معیاری ورژن (پرو چابی درج کریں)",
        "key_enter_prompt": "اپنی 16 ہندسوں کی پرو چابی درج کریں:",
        "key_invalid": "چابی کا فارمیٹ درست نہیں ہے۔",
        "key_expired": "یہ چابی ختم ہو چکی ہے۔",
        "key_activated_success": "چابی کامیابی سے فعال ہو گئی!",
        "key_type_lifetime": "لائف ٹائم لائسنس",
        "key_type_duration": "محدود مدت لائسنس",
        
        # Admin
        "admin_title": "ایڈمن ڈیش بورڈ",
        "admin_auth_title": "ایڈمن تصدیق",
        "admin_username": "ایڈمن یوزر نیم",
        "admin_password": "پاس ورڈ",
        "admin_first_run_title": "پہلی بار ایڈمن پاس ورڈ سیٹ اپ",
        "admin_first_run_desc": "privatesmk225 کے لیے محفوظ پاس ورڈ درج کریں۔",
        "admin_confirm_password": "پاس ورڈ کی تصدیق کریں",
        "admin_btn_set_password": "محفوظ اور شروع کریں",
        "admin_locked_out": "زیادہ غلط کوششیں۔ {minutes} منٹ انتظار کریں۔",
        "admin_invalid_creds": "غلط یوزر نیم یا پاس ورڈ۔",
        "admin_manage_keys": "پرو چابیاں کا انتظام",
        "admin_system_stats": "سسٹم ڈیٹا بیس اور معلومات",
        "admin_change_pass": "ایڈمن پاس ورڈ تبدیل کریں",
        
        # Feedback & Settings
        "feedback_title": "کمیونٹی فیڈ بیک",
        "feedback_rating": "درجہ بندی (1 تا 5 ستارے):",
        "feedback_comment": "اپنا تجربہ لکھیں:",
        "feedback_saved": "فیڈ بیک محفوظ ہو گیا۔ واٹس ایپ پر شیئر کر سکتے ہیں۔",
        "settings_theme": "تھیم",
        "settings_animations": "گلوئنگ اینیمیشنز",
        "settings_reduced_motion": "کم حرکت کا موڈ",
        "settings_language": "زبان کا انتخاب",
        "backup_title": "آف لائن ڈیٹا بیک اپ اور بحالی",
        "backup_export_info": "اپنی پروفائلز اور فون ڈیٹا کو محفوظ فائل میں محفوظ کریں۔",
        "backup_restore_info": "پہلے سے محفوظ بیک اپ فائل منتخب کریں۔",
        "backup_created": "بیک اپ کامیابی سے محفوظ ہو گیا!",
        "backup_restored": "ڈیٹا کامیابی سے بحال ہو گیا!",
        "backup_invalid": "بیک اپ فائل درست نہیں ہے۔",
        
        # Status labels
        "status_detected": "[دریافت شدہ]",
        "status_verified": "[تصدیق شدہ]",
        "status_user_confirmed": "[صارف کی تصدیق]",
        "status_unknown": "[نامعلوم]",
    }
}

class LocaleManager:
    """Manages active language and string lookups."""
    _current_lang = "en"
    
    @classmethod
    def set_language(cls, lang: str):
        if lang in TRANSLATIONS:
            cls._current_lang = lang
            
    @classmethod
    def get_language(cls) -> str:
        return cls._current_lang
        
    @classmethod
    def t(cls, key: str, **kwargs) -> str:
        lang_dict = TRANSLATIONS.get(cls._current_lang, TRANSLATIONS["en"])
        text = lang_dict.get(key, TRANSLATIONS["en"].get(key, key))
        if kwargs:
            try:
                return text.format(**kwargs)
            except Exception:
                return text
        return text

# Global shortcut function
def tr(key: str, **kwargs) -> str:
    return LocaleManager.t(key, **kwargs)
