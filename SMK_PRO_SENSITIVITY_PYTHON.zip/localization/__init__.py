from localization.locales import LocaleManager, tr, TRANSLATIONS

__all__ = ["LocaleManager", "tr", "TRANSLATIONS"]
