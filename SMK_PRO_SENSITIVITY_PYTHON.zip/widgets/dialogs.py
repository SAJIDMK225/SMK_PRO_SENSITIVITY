"""
Cyberpunk Neon Modals and Dialog Components for SMK PRO SENSITIVITY.
Provides confirmation for destructive actions, input prompts, and alerts.
"""
from kivy.uix.modalview import ModalView
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.graphics import Color, RoundedRectangle, Line
from widgets.neon_widgets import NeonButton, NeonCard


class NeonBaseModal(ModalView):
    """Futuristic styled base modal container."""
    def __init__(self, **kwargs):
        kwargs.setdefault("size_hint", (0.88, None))
        kwargs.setdefault("auto_dismiss", False)
        super(NeonBaseModal, self).__init__(**kwargs)
        self.background_color = (0, 0, 0, 0.75)


class NeonMessageDialog(NeonBaseModal):
    """Informational dialog with glowing OK button."""
    def __init__(self, title: str, message: str, on_ok=None, **kwargs):
        super(NeonMessageDialog, self).__init__(**kwargs)
        self.height = 230
        
        card = NeonCard(orientation="vertical", spacing=12, padding=16)
        
        lbl_title = Label(
            text=f"[b]{title}[/b]",
            markup=True,
            font_size="16sp",
            size_hint_y=None,
            height=32,
            color=(0.0, 0.94, 1.0, 1.0)
        )
        
        lbl_msg = Label(
            text=message,
            font_size="13sp",
            color=(0.9, 0.92, 0.98, 1.0),
            halign="center",
            valign="middle"
        )
        lbl_msg.bind(size=lbl_msg.setter("text_size"))
        
        btn_ok = NeonButton(text="OK", variant="primary", size_hint_y=None, height=44)
        
        def handle_ok(instance):
            self.dismiss()
            if on_ok:
                on_ok()
                
        btn_ok.bind(on_release=handle_ok)
        
        card.add_widget(lbl_title)
        card.add_widget(lbl_msg)
        card.add_widget(btn_ok)
        self.add_widget(card)


class NeonConfirmDialog(NeonBaseModal):
    """Confirmation modal for destructive actions (delete profile, reset, logout)."""
    def __init__(self, title: str, message: str, on_confirm, on_cancel=None, **kwargs):
        super(NeonConfirmDialog, self).__init__(**kwargs)
        self.height = 240
        
        card = NeonCard(orientation="vertical", spacing=12, padding=16)
        
        lbl_title = Label(
            text=f"[b]{title}[/b]",
            markup=True,
            font_size="16sp",
            size_hint_y=None,
            height=32,
            color=(1.0, 0.23, 0.36, 1.0)
        )
        
        lbl_msg = Label(
            text=message,
            font_size="13sp",
            color=(0.9, 0.92, 0.98, 1.0),
            halign="center",
            valign="middle"
        )
        lbl_msg.bind(size=lbl_msg.setter("text_size"))
        
        btn_box = BoxLayout(orientation="horizontal", spacing=10, size_hint_y=None, height=44)
        btn_cancel = NeonButton(text="Cancel", variant="purple")
        btn_confirm = NeonButton(text="Confirm", variant="danger")
        
        def handle_cancel(instance):
            self.dismiss()
            if on_cancel:
                on_cancel()
                
        def handle_confirm(instance):
            self.dismiss()
            if on_confirm:
                on_confirm()
                
        btn_cancel.bind(on_release=handle_cancel)
        btn_confirm.bind(on_release=handle_confirm)
        
        btn_box.add_widget(btn_cancel)
        btn_box.add_widget(btn_confirm)
        
        card.add_widget(lbl_title)
        card.add_widget(lbl_msg)
        card.add_widget(btn_box)
        self.add_widget(card)


class NeonInputDialog(NeonBaseModal):
    """Text input prompt modal (for profile renaming, custom values, pro keys)."""
    def __init__(self, title: str, prompt: str, default_text: str = "", on_submit=None, on_cancel=None, is_password: bool = False, **kwargs):
        super(NeonInputDialog, self).__init__(**kwargs)
        self.height = 270
        
        card = NeonCard(orientation="vertical", spacing=10, padding=16)
        
        lbl_title = Label(
            text=f"[b]{title}[/b]",
            markup=True,
            font_size="16sp",
            size_hint_y=None,
            height=30,
            color=(0.0, 0.94, 1.0, 1.0)
        )
        
        lbl_prompt = Label(
            text=prompt,
            font_size="12sp",
            size_hint_y=None,
            height=25,
            color=(0.7, 0.75, 0.88, 1.0),
            halign="left"
        )
        lbl_prompt.bind(size=lbl_prompt.setter("text_size"))
        
        self.text_input = TextInput(
            text=default_text,
            multiline=False,
            password=is_password,
            font_size="14sp",
            size_hint_y=None,
            height=42,
            background_color=(0.14, 0.16, 0.25, 1.0),
            foreground_color=(0.95, 0.96, 1.0, 1.0),
            cursor_color=(0.0, 0.94, 1.0, 1.0)
        )
        
        btn_box = BoxLayout(orientation="horizontal", spacing=10, size_hint_y=None, height=44)
        btn_cancel = NeonButton(text="Cancel", variant="purple")
        btn_submit = NeonButton(text="Submit", variant="primary")
        
        def handle_cancel(instance):
            self.dismiss()
            if on_cancel:
                on_cancel()
                
        def handle_submit(instance):
            entered = self.text_input.text.strip()
            self.dismiss()
            if on_submit:
                on_submit(entered)
                
        btn_cancel.bind(on_release=handle_cancel)
        btn_submit.bind(on_release=handle_submit)
        
        btn_box.add_widget(btn_cancel)
        btn_box.add_widget(btn_submit)
        
        card.add_widget(lbl_title)
        card.add_widget(lbl_prompt)
        card.add_widget(self.text_input)
        card.add_widget(btn_box)
        self.add_widget(card)
