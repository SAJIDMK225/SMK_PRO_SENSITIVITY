"""
Custom Neon Gaming Widgets & 3D Hacker Live Engine Background for SMK PRO SENSITIVITY.
Features a real-time 3D perspective cyber grid, falling digital matrix rain, and square neon tiles.
"""
import os
import math
import random
from kivy.uix.button import Button
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.image import Image
from kivy.uix.label import Label
from kivy.uix.widget import Widget
from kivy.graphics import Color, RoundedRectangle, Rectangle, Line, Ellipse
from kivy.animation import Animation
from kivy.clock import Clock
from kivy.properties import ListProperty, StringProperty, BooleanProperty, NumericProperty
from core.config import THEMES, ACTIVE_THEME
from database.db import DatabaseManager


def is_reduced_motion() -> bool:
    """Reads user preference for reduced motion/animations."""
    val = DatabaseManager.get_setting("reduced_motion", "false")
    return str(val).lower() in ("true", "1", "yes")


def get_asset_path(filename: str) -> str:
    """Locates an asset in the project directory."""
    base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    full = os.path.join(base, "assets", filename)
    return full if os.path.exists(full) else ""


class MagicBackground(Widget):
    """
    Real-time 3D Hacker Engine Background.
    Simulates a live 3D cyberpunk video with:
    - 3D infinite ground perspective grid moving towards the camera
    - Falling digital matrix data rain code streams
    - Holographic rotating 3D cyber radar rings
    - Drifting neon embers and cosmic wallpaper
    """
    z_scroll = NumericProperty(0.0)
    radar_angle = NumericProperty(0.0)
    rain_phase = NumericProperty(0.0)

    def __init__(self, **kwargs):
        super(MagicBackground, self).__init__(**kwargs)
        self.bg_image_path = get_asset_path("bg_cyber_gaming.png")
        
        # Initialize 16 deterministic matrix rain streams
        random.seed(1337)
        self.rain_columns = []
        for i in range(18):
            self.rain_columns.append({
                "x_rel": i / 18.0 + random.uniform(-0.02, 0.02),
                "speed": random.uniform(1.2, 2.8),
                "offset": random.uniform(0.0, 1000.0),
                "len": random.uniform(120.0, 260.0),
                "is_cyan": random.choice([True, False, True])
            })

        self.bind(pos=self._redraw, size=self._redraw, z_scroll=self._redraw, radar_angle=self._redraw, rain_phase=self._redraw)

        if not is_reduced_motion():
            Clock.schedule_interval(self._engine_tick, 1.0 / 30.0)

    def _engine_tick(self, dt):
        # 3D Grid speed
        self.z_scroll = (self.z_scroll + dt * 0.8) % 1.0
        # Radar rotation
        self.radar_angle = (self.radar_angle + dt * 25.0) % 360.0
        # Digital matrix rain
        self.rain_phase = (self.rain_phase + dt * 320.0) % 5000.0

    def _redraw(self, *args):
        self.canvas.clear()
        with self.canvas:
            w, h = self.width, self.height
            x, y = self.x, self.y

            # 1. Base Dark Void
            Color(0.02, 0.03, 0.06, 1.0)
            Rectangle(pos=self.pos, size=self.size)

            # 2. HD Cyber Matrix Wallpaper Overlay
            if self.bg_image_path:
                Color(1.0, 1.0, 1.0, 0.82)
                Rectangle(pos=self.pos, size=self.size, source=self.bg_image_path)

            # 3. Falling Digital Matrix Data Rain (Hacker Code Streams)
            for col in self.rain_columns:
                stream_x = x + col["x_rel"] * w
                current_y = (y + h - (self.rain_phase * col["speed"] + col["offset"]) % (h + 300))
                
                # Stream tail
                if col["is_cyan"]:
                    Color(0.0, 0.94, 1.0, 0.28)
                else:
                    Color(0.0, 0.95, 0.45, 0.26)
                Line(points=[stream_x, current_y + col["len"], stream_x, current_y], width=1.5)

                # Bright glowing head dot
                Color(1.0, 1.0, 1.0, 0.85)
                Ellipse(pos=(stream_x - 2, current_y - 2), size=(4, 4))

            # 4. 3D Perspective Digital Ground Grid (Moving towards camera)
            horizon_y = y + h * 0.35
            Color(0.0, 0.94, 1.0, 0.32)
            
            # Horizon boundary line
            Line(points=[x, horizon_y, x + w, horizon_y], width=2.0)

            # Converging longitudinal lines (converging to vanishing point)
            vp_x = x + w * 0.5
            vp_y = horizon_y
            for i in range(-7, 8):
                ground_x = vp_x + i * (w * 0.11)
                Line(points=[vp_x, vp_y, ground_x, y], width=1.4)

            # Scrolling transverse 3D distance lines
            num_z_lines = 8
            for i in range(num_z_lines):
                norm_z = (i / num_z_lines + self.z_scroll / num_z_lines) % 1.0
                # Non-linear 3D depth formula
                depth_ratio = norm_z ** 2.2
                line_y = horizon_y - depth_ratio * (horizon_y - y)
                line_alpha = 0.08 + 0.35 * depth_ratio
                Color(0.61, 0.31, 0.87, line_alpha)
                Line(points=[x, line_y, x + w, line_y], width=1.2 + depth_ratio * 1.5)

            # 5. Holographic Rotating 3D Cyber Radar Reticle (Top Center)
            radar_cx = x + w * 0.5
            radar_cy = y + h * 0.72
            rad = min(w * 0.26, 95)

            # Outer ring
            Color(0.0, 0.94, 1.0, 0.18)
            Line(circle=(radar_cx, radar_cy, rad), width=1.5)
            # Inner rotating radar ticks
            Color(0.61, 0.31, 0.87, 0.28)
            rad_ang = math.radians(self.radar_angle)
            for k in range(4):
                tick_ang = rad_ang + k * (math.pi / 2)
                tx1 = radar_cx + (rad - 12) * math.cos(tick_ang)
                ty1 = radar_cy + (rad - 12) * math.sin(tick_ang)
                tx2 = radar_cx + (rad + 6) * math.cos(tick_ang)
                ty2 = radar_cy + (rad + 6) * math.sin(tick_ang)
                Line(points=[tx1, ty1, tx2, ty2], width=2.0)


class NeonButton(Button):
    """
    Every interactive button in SMK PRO SENSITIVITY inherits from NeonButton.
    Features glowing aura, touch ripples, magical spark, and scale feedback.
    """
    variant = StringProperty("primary")
    neon_glow_intensity = NumericProperty(0.35)
    glow_color = ListProperty([0.0, 0.94, 1.0, 1.0])
    bg_color = ListProperty([0.07, 0.10, 0.18, 0.92])
    border_color = ListProperty([0.0, 0.94, 1.0, 0.75])
    corner_radius = NumericProperty(10)
    ripple_radius = NumericProperty(0)
    ripple_alpha = NumericProperty(0.0)
    ripple_pos = ListProperty([0, 0])

    def __init__(self, **kwargs):
        super(NeonButton, self).__init__(**kwargs)
        self.background_normal = ""
        self.background_down = ""
        self.background_color = (0, 0, 0, 0)
        self.font_name = "Roboto"
        self.bold = True
        self.font_size = "13sp"
        self.color = (0.95, 0.97, 1.0, 1.0)
        self._update_colors()
        self.bind(pos=self._redraw, size=self._redraw, variant=self._update_colors)
        self.bind(neon_glow_intensity=self._redraw, ripple_radius=self._redraw, ripple_alpha=self._redraw)

    def _update_colors(self, *args):
        theme = THEMES.get(ACTIVE_THEME, THEMES["neon_cyber"])
        if self.variant == "purple":
            self.glow_color = list(theme["neon_purple"])
            self.border_color = [theme["neon_purple"][0], theme["neon_purple"][1], theme["neon_purple"][2], 0.8]
            self.bg_color = [0.12, 0.08, 0.20, 0.92]
        elif self.variant == "success":
            self.glow_color = list(theme["neon_green"])
            self.border_color = [theme["neon_green"][0], theme["neon_green"][1], theme["neon_green"][2], 0.8]
            self.bg_color = [0.06, 0.16, 0.10, 0.92]
        elif self.variant == "danger":
            self.glow_color = list(theme["neon_red"])
            self.border_color = [theme["neon_red"][0], theme["neon_red"][1], theme["neon_red"][2], 0.8]
            self.bg_color = [0.18, 0.06, 0.09, 0.92]
        else:  # Primary Cyan
            self.glow_color = list(theme["neon_cyan"])
            self.border_color = [theme["neon_cyan"][0], theme["neon_cyan"][1], theme["neon_cyan"][2], 0.8]
            self.bg_color = [0.07, 0.12, 0.22, 0.92]

        self._redraw()

    def _redraw(self, *args):
        self.canvas.before.clear()
        with self.canvas.before:
            # Outer Glowing Halo
            Color(self.glow_color[0], self.glow_color[1], self.glow_color[2], self.neon_glow_intensity * 0.45)
            RoundedRectangle(
                pos=(self.x - 3, self.y - 3),
                size=(self.width + 6, self.height + 6),
                radius=[self.corner_radius + 2]
            )

            # Main Button Body
            Color(*self.bg_color)
            RoundedRectangle(pos=self.pos, size=self.size, radius=[self.corner_radius])

            # Top Light Glass Sheen
            Color(1.0, 1.0, 1.0, 0.08)
            RoundedRectangle(
                pos=(self.x + 2, self.y + self.height * 0.5),
                size=(self.width - 4, self.height * 0.48),
                radius=[self.corner_radius, self.corner_radius, 0, 0]
            )

            # Glowing Neon Border
            Color(*self.border_color)
            Line(rounded_rectangle=(self.x, self.y, self.width, self.height, self.corner_radius), width=1.6)

            # Magical Touch Ripple / Spark
            if self.ripple_alpha > 0.01:
                Color(self.glow_color[0], self.glow_color[1], self.glow_color[2], self.ripple_alpha)
                Ellipse(
                    pos=(self.ripple_pos[0] - self.ripple_radius, self.ripple_pos[1] - self.ripple_radius),
                    size=(self.ripple_radius * 2, self.ripple_radius * 2)
                )

    def on_touch_down(self, touch):
        if self.collide_point(*touch.pos):
            self.ripple_pos = list(touch.pos)
            if not is_reduced_motion():
                self.ripple_radius = 6
                self.ripple_alpha = 0.75
                anim = Animation(neon_glow_intensity=0.9, duration=0.1) & \
                       Animation(ripple_radius=max(self.width, self.height) * 0.95, ripple_alpha=0.0, duration=0.38, t="out_quad")
                anim.start(self)
            else:
                self.neon_glow_intensity = 0.7
            return super(NeonButton, self).on_touch_down(touch)
        return super(NeonButton, self).on_touch_down(touch)

    def on_touch_up(self, touch):
        if self.collide_point(*touch.pos):
            if not is_reduced_motion():
                anim = Animation(neon_glow_intensity=0.35, duration=0.22, t="out_cubic")
                anim.start(self)
            else:
                self.neon_glow_intensity = 0.35
        return super(NeonButton, self).on_touch_up(touch)


class NeonCard(BoxLayout):
    """Futuristic Cyber Glassmorphism card container with glowing borders."""
    corner_radius = NumericProperty(12)
    border_color = ListProperty([0.0, 0.94, 1.0, 0.45])
    bg_color = ListProperty([0.07, 0.09, 0.15, 0.88])

    def __init__(self, **kwargs):
        super(NeonCard, self).__init__(**kwargs)
        self.padding = 12
        self.spacing = 8
        self.bind(pos=self._redraw, size=self._redraw)
        self._redraw()

    def _redraw(self, *args):
        self.canvas.before.clear()
        with self.canvas.before:
            Color(*self.bg_color)
            RoundedRectangle(pos=self.pos, size=self.size, radius=[self.corner_radius])

            # Top neon highlight line
            Color(self.border_color[0], self.border_color[1], self.border_color[2], 0.75)
            Line(
                points=[
                    self.x + self.corner_radius, self.y + self.height,
                    self.x + self.width - self.corner_radius, self.y + self.height
                ],
                width=2.0
            )

            # Glowing perimeter border
            Color(*self.border_color)
            Line(rounded_rectangle=(self.x, self.y, self.width, self.height, self.corner_radius), width=1.3)


class NeonSquareTile(Button):
    """
    Dedicated Square Futuristic Tile with high-res icon, bold typography,
    and responsive glowing touch feedback.
    """
    icon_filename = StringProperty("")
    title_text = StringProperty("")
    badge_text = StringProperty("")
    variant = StringProperty("primary")
    glow_intensity = NumericProperty(0.3)
    corner_radius = NumericProperty(14)
    ripple_radius = NumericProperty(0)
    ripple_alpha = NumericProperty(0.0)
    ripple_pos = ListProperty([0, 0])

    def __init__(self, icon_name: str, title: str, badge: str = "", variant: str = "primary", **kwargs):
        super(NeonSquareTile, self).__init__(**kwargs)
        self.icon_filename = icon_name
        self.title_text = title
        self.badge_text = badge
        self.variant = variant
        self.background_normal = ""
        self.background_down = ""
        self.background_color = (0, 0, 0, 0)
        
        # Internal Content Layout
        self.layout = BoxLayout(orientation="vertical", padding=[8, 8, 8, 8], spacing=4)
        
        # High-res Icon Image
        icon_path = get_asset_path(self.icon_filename)
        if icon_path:
            self.img_icon = Image(
                source=icon_path,
                size_hint=(None, None),
                size=(52, 52),
                pos_hint={"center_x": 0.5}
            )
            self.layout.add_widget(self.img_icon)

        # Title Label
        self.lbl_title = Label(
            text=f"[b]{self.title_text}[/b]",
            markup=True,
            font_size="13sp",
            color=(0.95, 0.97, 1.0, 1.0),
            size_hint_y=None,
            height=26,
            halign="center"
        )
        self.lbl_title.bind(size=self.lbl_title.setter("text_size"))
        self.layout.add_widget(self.lbl_title)

        # Badge Label
        if self.badge_text:
            badge_col = (0.0, 0.94, 1.0, 1.0) if self.variant == "primary" else (0.61, 0.31, 0.87, 1.0)
            self.lbl_badge = Label(
                text=self.badge_text,
                font_size="10sp",
                bold=True,
                color=badge_col,
                size_hint_y=None,
                height=18,
                halign="center"
            )
            self.layout.add_widget(self.lbl_badge)

        self.add_widget(self.layout)
        self.bind(pos=self._update_layout, size=self._update_layout)
        self.bind(pos=self._redraw, size=self._redraw, glow_intensity=self._redraw, ripple_radius=self._redraw, ripple_alpha=self._redraw)
        self._redraw()

    def _update_layout(self, *args):
        self.layout.pos = self.pos
        self.layout.size = self.size

    def _redraw(self, *args):
        self.canvas.before.clear()
        theme = THEMES.get(ACTIVE_THEME, THEMES["neon_cyber"])
        if self.variant == "purple":
            glow_c = list(theme["neon_purple"])
            bg_c = [0.10, 0.07, 0.18, 0.92]
        elif self.variant == "gold":
            glow_c = [1.0, 0.75, 0.0, 1.0]
            bg_c = [0.15, 0.12, 0.06, 0.92]
        elif self.variant == "success":
            glow_c = list(theme["neon_green"])
            bg_c = [0.06, 0.16, 0.10, 0.92]
        else:
            glow_c = list(theme["neon_cyan"])
            bg_c = [0.07, 0.11, 0.20, 0.92]

        with self.canvas.before:
            # Outer Glow
            Color(glow_c[0], glow_c[1], glow_c[2], self.glow_intensity * 0.4)
            RoundedRectangle(pos=(self.x - 3, self.y - 3), size=(self.width + 6, self.height + 6), radius=[self.corner_radius + 2])
            
            # Card Body
            Color(*bg_c)
            RoundedRectangle(pos=self.pos, size=self.size, radius=[self.corner_radius])

            # Top Glowing Line
            Color(glow_c[0], glow_c[1], glow_c[2], 0.75)
            Line(
                points=[
                    self.x + self.corner_radius, self.y + self.height,
                    self.x + self.width - self.corner_radius, self.y + self.height
                ],
                width=2.2
            )

            # Border Line
            Color(glow_c[0], glow_c[1], glow_c[2], 0.65)
            Line(rounded_rectangle=(self.x, self.y, self.width, self.height, self.corner_radius), width=1.4)

            # Ripple Spark
            if self.ripple_alpha > 0.01:
                Color(glow_c[0], glow_c[1], glow_c[2], self.ripple_alpha)
                Ellipse(
                    pos=(self.ripple_pos[0] - self.ripple_radius, self.ripple_pos[1] - self.ripple_radius),
                    size=(self.ripple_radius * 2, self.ripple_radius * 2)
                )

    def on_touch_down(self, touch):
        if self.collide_point(*touch.pos):
            self.ripple_pos = list(touch.pos)
            if not is_reduced_motion():
                self.ripple_radius = 6
                self.ripple_alpha = 0.75
                anim = Animation(glow_intensity=0.85, duration=0.1) & \
                       Animation(ripple_radius=max(self.width, self.height) * 0.95, ripple_alpha=0.0, duration=0.38, t="out_quad")
                anim.start(self)
            else:
                self.glow_intensity = 0.65
            return super(NeonSquareTile, self).on_touch_down(touch)
        return super(NeonSquareTile, self).on_touch_down(touch)

    def on_touch_up(self, touch):
        if self.collide_point(*touch.pos):
            if not is_reduced_motion():
                anim = Animation(glow_intensity=0.3, duration=0.22, t="out_cubic")
                anim.start(self)
            else:
                self.glow_intensity = 0.3
        return super(NeonSquareTile, self).on_touch_up(touch)
