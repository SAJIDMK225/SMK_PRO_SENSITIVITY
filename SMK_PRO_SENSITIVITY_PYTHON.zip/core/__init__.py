"""Core package for SMK PRO SENSITIVITY."""
