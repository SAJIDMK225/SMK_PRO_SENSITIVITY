"""
Core Configuration for SMK PRO SENSITIVITY.
Zero-cost, offline-first gaming sensitivity optimizer.
"""
import os
import sys

APP_NAME = "SMK PRO SENSITIVITY"
APP_SUBTITLE = "Pro Gamer Sensitivity Tuning Engine"
APP_VERSION = "2.5.0"
APP_AUTHOR = "SMK Gaming & Community"

# Offline / Zero-cost links
WHATSAPP_CHANNEL_URL = "https://whatsapp.com/channel/0029VangZH52UPBHGbkqXH3u"
YOUTUBE_CHANNEL_URL = "https://youtube.com/@sajidgaming225?si=7YaHjdx9XuYRWZ2F"

# Security & Defaults
INITIAL_OWNER_USERNAME = "privatesmk225"
MAX_LOGIN_ATTEMPTS = 5
LOCKOUT_DURATION_SECONDS = 300  # 5 minutes
SESSION_INACTIVITY_TIMEOUT_SECONDS = 600  # 10 minutes

# Theme Palette (Neon Cyberpunk)
THEMES = {
    "neon_cyber": {
        "name": "Neon Cyber (Cyan & Blue)",
        "bg_primary": (0.04, 0.04, 0.07, 1.0),      # #0a0b12
        "bg_card": (0.08, 0.09, 0.14, 0.95),        # #141724
        "bg_card_hover": (0.12, 0.14, 0.22, 1.0),   # #1f2438
        "neon_cyan": (0.0, 0.94, 1.0, 1.0),         # #00f0ff
        "neon_blue": (0.12, 0.53, 1.0, 1.0),        # #1f87ff
        "neon_purple": (0.61, 0.31, 0.87, 1.0),     # #9d4edd
        "neon_green": (0.0, 0.9, 0.45, 1.0),        # #00e673
        "neon_red": (1.0, 0.23, 0.36, 1.0),         # #ff3b5c
        "text_primary": (0.95, 0.96, 1.0, 1.0),     # #f2f5ff
        "text_secondary": (0.62, 0.67, 0.78, 1.0),   # #9eabc7
        "border_glow": (0.0, 0.94, 1.0, 0.35),
    },
    "neon_purple": {
        "name": "Neon Syndicate (Purple & Pink)",
        "bg_primary": (0.05, 0.03, 0.08, 1.0),
        "bg_card": (0.11, 0.07, 0.17, 0.95),
        "bg_card_hover": (0.16, 0.11, 0.25, 1.0),
        "neon_cyan": (0.78, 0.2, 0.95, 1.0),
        "neon_blue": (0.55, 0.15, 0.9, 1.0),
        "neon_purple": (0.9, 0.2, 0.7, 1.0),
        "neon_green": (0.0, 0.9, 0.45, 1.0),
        "neon_red": (1.0, 0.23, 0.36, 1.0),
        "text_primary": (0.98, 0.95, 1.0, 1.0),
        "text_secondary": (0.75, 0.65, 0.85, 1.0),
        "border_glow": (0.78, 0.2, 0.95, 0.4),
    },
    "cyber_gold": {
        "name": "Amber Strike (Gold & Amber)",
        "bg_primary": (0.06, 0.05, 0.03, 1.0),
        "bg_card": (0.13, 0.11, 0.07, 0.95),
        "bg_card_hover": (0.19, 0.16, 0.10, 1.0),
        "neon_cyan": (1.0, 0.75, 0.0, 1.0),
        "neon_blue": (1.0, 0.55, 0.0, 1.0),
        "neon_purple": (0.9, 0.35, 0.0, 1.0),
        "neon_green": (0.2, 0.9, 0.3, 1.0),
        "neon_red": (1.0, 0.25, 0.25, 1.0),
        "text_primary": (1.0, 0.98, 0.92, 1.0),
        "text_secondary": (0.8, 0.75, 0.65, 1.0),
        "border_glow": (1.0, 0.75, 0.0, 0.4),
    }
}

ACTIVE_THEME = "neon_cyber"

def get_app_dir() -> str:
    """Returns safe writeable directory for databases, settings, and exports."""
    # If running on Android via python-for-android
    if "ANDROID_ARGUMENT" in os.environ or "ANDROID_PRIVATE" in os.environ:
        from android.storage import app_storage_path  # pylint: disable=import-error
        return app_storage_path()
    # Desktop fallback - current workspace or user home
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return base_dir

def get_db_path() -> str:
    """Path to the SQLite database."""
    return os.path.join(get_app_dir(), "smk_pro_sensitivity.db")
