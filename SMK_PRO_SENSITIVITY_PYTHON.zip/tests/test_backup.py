"""
Unit tests for Backup generation, integrity checksums, and restoration.
"""
import pytest
import os
import tempfile
import json
from database.db import DatabaseManager
from services.backup_service import BackupService
from services.profile_service import ProfileService


@pytest.fixture(autouse=True)
def setup_test_db():
    temp_dir = tempfile.mkdtemp()
    db_file = os.path.join(temp_dir, "test_backup.db")
    DatabaseManager.set_db_path(db_file)
    DatabaseManager.init_database()
    yield
    if os.path.exists(db_file):
        try:
            os.remove(db_file)
        except Exception:
            pass


def test_backup_export_and_validation():
    """Verify backup payload structure, magic signature, and sha256 checksum."""
    ProfileService.save_or_update("ExportTestProfile", 190, 180, 170, 160, 120, 190)
    
    payload = BackupService.create_backup_data()
    assert payload["magic"] == BackupService.BACKUP_MAGIC
    assert "checksum" in payload
    assert len(payload["data"]["profiles"]) >= 1

    valid, msg = BackupService.validate_backup_data(payload)
    assert valid is True


def test_backup_tamper_detection():
    """Verify modifying backup data invalidates checksum."""
    ProfileService.save_or_update("TamperTest", 180, 170, 160, 150, 120, 180)
    payload = BackupService.create_backup_data()

    # Tamper with the profile data
    payload["data"]["profiles"][0]["general"] = 200

    valid, msg = BackupService.validate_backup_data(payload)
    assert valid is False
    assert "Integrity check failed" in msg


def test_backup_restore_flow():
    """Verify restoration restores exported profiles."""
    ProfileService.save_or_update("ToRestoreProfile", 188, 178, 168, 158, 128, 188)
    payload = BackupService.create_backup_data()

    # Clear table
    with DatabaseManager.get_connection() as conn:
        conn.execute("DELETE FROM profiles")
        conn.commit()

    assert len(DatabaseManager.get_all_profiles()) == 0

    ok, msg = BackupService.restore_from_data(payload)
    assert ok is True
    assert len(DatabaseManager.get_all_profiles()) >= 1
    assert DatabaseManager.get_profile_by_name("ToRestoreProfile") is not None
