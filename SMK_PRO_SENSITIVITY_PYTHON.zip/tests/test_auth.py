"""
Unit tests for PBKDF2 authentication, salt derivation, and lockout security.
"""
import pytest
import os
import tempfile
import time
from database.db import DatabaseManager
from security.auth import AdminAuthService
from core.config import INITIAL_OWNER_USERNAME, MAX_LOGIN_ATTEMPTS


@pytest.fixture(autouse=True)
def setup_test_db():
    temp_dir = tempfile.mkdtemp()
    db_file = os.path.join(temp_dir, "test_auth.db")
    DatabaseManager.set_db_path(db_file)
    DatabaseManager.init_database()
    AdminAuthService.logout()
    yield
    if os.path.exists(db_file):
        try:
            os.remove(db_file)
        except Exception:
            pass


def test_first_run_detection():
    """Verify first run is true when no password is set."""
    assert AdminAuthService.is_first_run() is True


def test_setup_and_authenticate():
    """Verify owner password setup and subsequent authentication."""
    test_pwd = "SecretPassword123"
    ok, msg = AdminAuthService.setup_initial_owner_password(test_pwd)
    assert ok is True
    assert AdminAuthService.is_first_run() is False

    # Invalid login
    auth_ok, err = AdminAuthService.authenticate(INITIAL_OWNER_USERNAME, "WrongPassword")
    assert auth_ok is False
    assert "Invalid username or password" in err

    # Valid login
    auth_ok, s_msg = AdminAuthService.authenticate(INITIAL_OWNER_USERNAME, test_pwd)
    assert auth_ok is True
    assert AdminAuthService.is_authenticated() is True


def test_login_lockout_after_max_attempts():
    """Verify lockout is triggered after repeated failed attempts."""
    test_pwd = "ValidPassword999"
    AdminAuthService.setup_initial_owner_password(test_pwd)

    for i in range(MAX_LOGIN_ATTEMPTS):
        AdminAuthService.authenticate(INITIAL_OWNER_USERNAME, "WrongPassword")

    # The 6th attempt must be locked out
    ok, msg = AdminAuthService.authenticate(INITIAL_OWNER_USERNAME, "WrongPassword")
    assert ok is False
    assert "Locked out" in msg


def test_password_change_flow():
    """Verify changing password while authenticated."""
    pwd1 = "InitialPassword123"
    pwd2 = "UpdatedPassword456"
    AdminAuthService.setup_initial_owner_password(pwd1)
    AdminAuthService.authenticate(INITIAL_OWNER_USERNAME, pwd1)

    ok, msg = AdminAuthService.change_password(pwd1, pwd2)
    assert ok is True

    # Old password should no longer work
    AdminAuthService.logout()
    ok_old, _ = AdminAuthService.authenticate(INITIAL_OWNER_USERNAME, pwd1)
    assert ok_old is False

    # New password should work
    ok_new, _ = AdminAuthService.authenticate(INITIAL_OWNER_USERNAME, pwd2)
    assert ok_new is True
