"""
Smoke tests for Kivy GUI screen instantiation, screen manager registration, and back navigation.
"""
import pytest
import os
import tempfile
from database.db import DatabaseManager
from main import SMKProSensitivityApp
from screens.nav_header import ScreenHeader


@pytest.fixture(autouse=True)
def setup_test_db():
    temp_dir = tempfile.mkdtemp()
    db_file = os.path.join(temp_dir, "test_gui.db")
    DatabaseManager.set_db_path(db_file)
    DatabaseManager.init_database()
    yield
    if os.path.exists(db_file):
        try:
            os.remove(db_file)
        except Exception:
            pass


def test_app_build_and_screen_registration():
    """Verify SMKProSensitivityApp builds ScreenManager with all 13 screens."""
    app = SMKProSensitivityApp()
    sm = app.build()
    assert sm is not None

    expected_screens = [
        "splash", "home", "generator", "device", "phone_db",
        "profiles", "admin_login", "admin_panel", "feedback",
        "settings", "backup_restore", "help", "about"
    ]
    registered_screen_names = [s.name for s in sm.screens]

    for expected in expected_screens:
        assert expected in registered_screen_names, f"Screen '{expected}' not registered in ScreenManager"

    assert len(sm.screens) == 13


def test_back_button_navigation():
    """Verify ScreenHeader properly transitions back to target screen."""
    app = SMKProSensitivityApp()
    sm = app.build()

    # Switch to generator screen
    sm.current = "generator"
    assert sm.current == "generator"

    gen_screen = sm.get_screen("generator")
    # Find ScreenHeader in gen_screen
    headers = [w for w in gen_screen.walk() if isinstance(w, ScreenHeader)]
    assert len(headers) >= 1
    header = headers[0]

    # Trigger _go_back
    header._go_back()
    # Must now be at home screen!
    assert sm.current == "home"
