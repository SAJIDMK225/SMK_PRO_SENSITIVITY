"""Tests package for SMK PRO SENSITIVITY."""
