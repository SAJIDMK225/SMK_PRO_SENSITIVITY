"""
Unit tests for SQLite database operations, profiles CRUD, and offline phone lookups.
"""
import pytest
import os
import tempfile
from database.db import DatabaseManager
from services.profile_service import ProfileService


@pytest.fixture(autouse=True)
def setup_test_db():
    temp_dir = tempfile.mkdtemp()
    db_file = os.path.join(temp_dir, "test_db.db")
    DatabaseManager.set_db_path(db_file)
    DatabaseManager.init_database()
    yield
    if os.path.exists(db_file):
        try:
            os.remove(db_file)
        except Exception:
            pass


def test_initial_device_seeding():
    """Verify that default verified phones are seeded in SQLite."""
    phones = DatabaseManager.search_phones()
    assert len(phones) >= 20
    poco_models = [p for p in phones if p["brand"] == "Poco"]
    assert len(poco_models) >= 2


def test_profile_crud_operations():
    """Verify create, read, update, rename, and delete for profiles."""
    ok, msg = ProfileService.save_or_update(
        name="Tournament_Drag",
        general=185,
        red_dot=175,
        scope_2x=165,
        scope_4x=150,
        sniper=120,
        free_look=180,
        aim_style="Headshot Drag"
    )
    assert ok is True

    prof = ProfileService.get_by_name("Tournament_Drag")
    assert prof is not None
    assert prof["general"] == 185

    # Duplicate
    dup_ok, _ = ProfileService.duplicate("Tournament_Drag", "Tournament_Drag_Backup")
    assert dup_ok is True
    assert ProfileService.get_by_name("Tournament_Drag_Backup") is not None

    # Rename
    DatabaseManager.rename_profile(prof["id"], "Tournament_Finals")
    assert ProfileService.get_by_name("Tournament_Finals") is not None
    assert ProfileService.get_by_name("Tournament_Drag") is None

    # Delete
    del_ok = ProfileService.delete(prof["id"])
    assert del_ok is True
    assert ProfileService.get_by_name("Tournament_Finals") is None


def test_custom_phone_addition_and_search():
    """Verify adding custom phone and searching it."""
    DatabaseManager.add_custom_phone(
        brand="CustomTech",
        model="GamingTitan 1",
        ram_gb=16,
        storage_gb=256,
        refresh_rate=144,
        chipset="CustomChip X",
        fps_support=120,
        recommended_general=160,
        recommended_red_dot=155
    )

    results = DatabaseManager.search_phones(query="GamingTitan")
    assert len(results) == 1
    assert results[0]["brand"] == "CustomTech"
    assert results[0]["refresh_rate"] == 144
