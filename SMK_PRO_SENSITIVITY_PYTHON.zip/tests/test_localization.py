"""
Unit tests for Localization and translation completeness.
"""
import pytest
from localization.locales import LocaleManager, tr, TRANSLATIONS


def test_supported_languages():
    """Verify English, Roman Urdu, and Urdu script are available."""
    assert "en" in TRANSLATIONS
    assert "ur_ro" in TRANSLATIONS
    assert "ur_ar" in TRANSLATIONS


def test_translation_lookups():
    """Verify switching languages changes lookup outputs."""
    LocaleManager.set_language("en")
    assert tr("btn_save_profile") == "Save Profile"

    LocaleManager.set_language("ur_ro")
    assert tr("btn_save_profile") == "Profile Save Karein"

    LocaleManager.set_language("ur_ar")
    assert "پروفائل" in tr("btn_save_profile")


def test_key_coverage_consistency():
    """Ensure essential UI action keys are present across all languages."""
    essential_keys = [
        "app_title", "btn_generate", "btn_save_profile",
        "btn_login", "btn_logout", "btn_create_key",
        "sens_general", "sens_red_dot"
    ]
    for lang in ["en", "ur_ro", "ur_ar"]:
        for k in essential_keys:
            assert k in TRANSLATIONS[lang], f"Key '{k}' missing in language '{lang}'"
