"""
Unit tests for deterministic Sensitivity Recommendation Engine.
"""
import pytest
from services.sensitivity_engine import SensitivityEngine


def test_sensitivity_bounds():
    """Verify that all sensitivity outputs are strictly clamped between 0 and 200."""
    for hz in [60, 90, 120, 144]:
        for style in ["headshot_drag", "balanced", "speed_rush", "sniper_precision"]:
            for gfx in ["smooth", "standard", "ultra", "max"]:
                res = SensitivityEngine.calculate(
                    refresh_rate=hz,
                    aim_style=style,
                    graphics=gfx,
                    hud_fingers=2,
                    gyro_mode="disabled"
                )
                for channel in ["general", "red_dot", "scope_2x", "scope_4x", "sniper", "free_look"]:
                    val = res[channel]
                    assert 0 <= val <= 200, f"Channel {channel} exceeded bounds with value {val}"


def test_refresh_rate_dynamics():
    """Verify that 60Hz displays receive higher general sensitivity than 144Hz displays."""
    res_60 = SensitivityEngine.calculate(refresh_rate=60, aim_style="balanced")
    res_144 = SensitivityEngine.calculate(refresh_rate=144, aim_style="balanced")
    assert res_60["general"] > res_144["general"]


def test_aim_styles_differentiation():
    """Verify headshot drag has higher general flick than sniper precision."""
    res_drag = SensitivityEngine.calculate(refresh_rate=60, aim_style="headshot_drag")
    res_sniper = SensitivityEngine.calculate(refresh_rate=60, aim_style="sniper_precision")
    assert res_drag["general"] > res_sniper["general"]
    assert res_sniper["sniper"] > res_drag["sniper"]


def test_calibration_guide_available():
    """Ensure training ground workflow guide is non-empty and contains key keywords."""
    guide = SensitivityEngine.get_calibration_guide()
    assert "Training Ground" in guide
    assert "General" in guide
