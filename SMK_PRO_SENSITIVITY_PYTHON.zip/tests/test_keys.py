"""
Unit tests for offline Key Management and Pro feature gating.
"""
import pytest
import os
import tempfile
from database.db import DatabaseManager
from security.keys import KeyManager


@pytest.fixture(autouse=True)
def setup_test_db():
    temp_dir = tempfile.mkdtemp()
    db_file = os.path.join(temp_dir, "test_keys.db")
    DatabaseManager.set_db_path(db_file)
    DatabaseManager.init_database()
    yield
    if os.path.exists(db_file):
        try:
            os.remove(db_file)
        except Exception:
            pass


def test_key_generation_and_checksum_verification():
    """Verify keys are generated with prefix, payload, and valid checksum."""
    key = KeyManager.generate_key(key_type="lifetime")
    assert key.startswith("SMK-")
    assert KeyManager.verify_key_format(key) is True

    # Tampered key should fail verification
    tampered_key = key[:-1] + ("A" if key[-1] != "A" else "B")
    assert KeyManager.verify_key_format(tampered_key) is False


def test_lifetime_key_activation():
    """Verify activating lifetime key unlocks pro mode indefinitely."""
    assert KeyManager.is_pro_active() is False
    key = KeyManager.generate_key(key_type="lifetime")

    ok, msg = KeyManager.activate_key(key)
    assert ok is True
    assert KeyManager.is_pro_active() is True

    summary = KeyManager.get_license_summary()
    assert summary["is_pro"] is True
    assert summary["type"] == "Lifetime"


def test_limited_key_activation():
    """Verify limited-duration key registers expiration window."""
    key = KeyManager.generate_key(key_type="limited", duration_days=30)
    ok, msg = KeyManager.activate_key(key)
    assert ok is True
    assert KeyManager.is_pro_active() is True

    summary = KeyManager.get_license_summary()
    assert summary["is_pro"] is True
    assert "Limited (30 days)" in summary["type"]


def test_key_deactivation():
    """Verify local key revocation deactivates pro status."""
    key = KeyManager.generate_key(key_type="lifetime")
    KeyManager.activate_key(key)
    assert KeyManager.is_pro_active() is True

    keys = KeyManager.list_keys()
    assert len(keys) == 1
    key_id = keys[0]["id"]

    rev_ok = KeyManager.deactivate_key(key_id)
    assert rev_ok is True
    assert KeyManager.is_pro_active() is False
