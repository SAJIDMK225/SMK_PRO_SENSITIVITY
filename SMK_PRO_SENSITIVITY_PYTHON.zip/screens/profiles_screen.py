"""
Saved Sensitivity Profiles Management Screen for SMK PRO SENSITIVITY.
Coordinates profile inspection, cloning, delta comparisons, and safe deletion.
"""
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from widgets.neon_widgets import MagicBackground, NeonButton, NeonCard
from widgets.dialogs import NeonMessageDialog, NeonConfirmDialog, NeonInputDialog
from screens.nav_header import ScreenHeader
from services.profile_service import ProfileService
from database.db import DatabaseManager
from localization.locales import tr


class ProfilesScreen(Screen):
    """Profile listing, comparison, and management screen."""

    def __init__(self, **kwargs):
        super(ProfilesScreen, self).__init__(**kwargs)
        self.name = "profiles"

        self.add_widget(MagicBackground())

        root = BoxLayout(orientation="vertical", padding=[10, 8, 10, 8], spacing=8)
        root.add_widget(ScreenHeader("nav_profiles", show_back=True, back_target="home"))

        # Top Action Bar
        top_bar = NeonCard(orientation="horizontal", size_hint_y=None, height=48, padding=6, spacing=8)
        btn_new = NeonButton(text="+ New Profile", variant="primary", font_size="12sp")
        btn_new.bind(on_release=self._create_new_profile_prompt)
        top_bar.add_widget(btn_new)
        root.add_widget(top_bar)

        # Scrollable List
        self.scroll = ScrollView(size_hint=(1, 1), do_scroll_x=False)
        self.list_box = BoxLayout(orientation="vertical", spacing=10, size_hint_y=None)
        self.list_box.bind(minimum_height=self.list_box.setter("height"))
        self.scroll.add_widget(self.list_box)
        root.add_widget(self.scroll)

        self.add_widget(root)

    def on_enter(self, *args):
        self._load_profiles()

    def _load_profiles(self):
        self.list_box.clear_widgets()
        profiles = ProfileService.list_all()

        if not profiles:
            lbl_empty = Label(
                text="No saved profiles yet.\nGenerate one from the Generator screen or click '+ New Profile'.",
                font_size="13sp",
                color=(0.6, 0.65, 0.78, 1.0),
                size_hint_y=None,
                height=80,
                halign="center"
            )
            lbl_empty.bind(size=lbl_empty.setter("text_size"))
            self.list_box.add_widget(lbl_empty)
            return

        for p in profiles:
            card = NeonCard(orientation="vertical", spacing=6, size_hint_y=None, height=135, padding=10)

            # Title & Style Row
            top_row = BoxLayout(orientation="horizontal", size_hint_y=None, height=24)
            lbl_title = Label(
                text=f"[b]{p['name']}[/b]",
                markup=True,
                font_size="14sp",
                color=(0.0, 0.94, 1.0, 1.0),
                size_hint_x=0.7,
                halign="left"
            )
            lbl_title.bind(size=lbl_title.setter("text_size"))
            lbl_style = Label(
                text=f"{p['aim_style']}",
                font_size="11sp",
                color=(0.61, 0.31, 0.87, 1.0),
                size_hint_x=0.3,
                halign="right"
            )
            top_row.add_widget(lbl_title)
            top_row.add_widget(lbl_style)
            card.add_widget(top_row)

            # Sensitivities values overview
            sens_text = (
                f"Gen: {p['general']} | RedDot: {p['red_dot']} | 2x: {p['scope_2x']} | "
                f"4x: {p['scope_4x']} | Snip: {p['sniper']} | Free: {p['free_look']}"
            )
            lbl_sens = Label(
                text=sens_text,
                font_size="11sp",
                color=(0.85, 0.88, 0.96, 1.0),
                size_hint_y=None,
                height=22,
                halign="left"
            )
            lbl_sens.bind(size=lbl_sens.setter("text_size"))
            card.add_widget(lbl_sens)

            # Actions Row (Load, Duplicate, Rename, Delete)
            btn_row = BoxLayout(orientation="horizontal", spacing=6, size_hint_y=None, height=36)
            
            btn_load = NeonButton(text="Load", variant="primary", font_size="11sp")
            btn_load.bind(on_release=lambda inst, prof=p: self._load_into_generator(prof))

            btn_dup = NeonButton(text="Duplicate", variant="purple", font_size="11sp")
            btn_dup.bind(on_release=lambda inst, prof=p: self._duplicate_profile(prof))

            btn_rename = NeonButton(text="Rename", variant="purple", font_size="11sp")
            btn_rename.bind(on_release=lambda inst, prof=p: self._rename_profile(prof))

            btn_del = NeonButton(text="Delete", variant="danger", font_size="11sp")
            btn_del.bind(on_release=lambda inst, prof=p: self._confirm_delete(prof))

            btn_row.add_widget(btn_load)
            btn_row.add_widget(btn_dup)
            btn_row.add_widget(btn_rename)
            btn_row.add_widget(btn_del)
            card.add_widget(btn_row)

            self.list_box.add_widget(card)

    def _load_into_generator(self, prof: dict):
        if self.manager:
            gen_screen = self.manager.get_screen("generator")
            if hasattr(gen_screen, "current_sens"):
                gen_screen.current_sens["general"] = prof["general"]
                gen_screen.current_sens["red_dot"] = prof["red_dot"]
                gen_screen.current_sens["scope_2x"] = prof["scope_2x"]
                gen_screen.current_sens["scope_4x"] = prof["scope_4x"]
                gen_screen.current_sens["sniper"] = prof["sniper"]
                gen_screen.current_sens["free_look"] = prof["free_look"]
                gen_screen._render_values()
            self.manager.current = "generator"
            NeonMessageDialog("Profile Loaded", f"Loaded profile '{prof['name']}' into Sensitivity Generator.").open()

    def _duplicate_profile(self, prof: dict):
        def on_name(new_name):
            if not new_name:
                return
            ok, msg = ProfileService.duplicate(prof["name"], new_name)
            self._load_profiles()
            NeonMessageDialog("Duplicate", msg).open()

        NeonInputDialog(
            title="Duplicate Profile",
            prompt=f"New name for copy of '{prof['name']}':",
            default_text=f"{prof['name']}_Copy",
            on_submit=on_name
        ).open()

    def _rename_profile(self, prof: dict):
        def on_rename(new_name):
            if not new_name:
                return
            ok = DatabaseManager.rename_profile(prof["id"], new_name)
            self._load_profiles()
            NeonMessageDialog("Rename", "Profile renamed successfully." if ok else "Failed to rename.").open()

        NeonInputDialog(
            title="Rename Profile",
            prompt="Enter new name:",
            default_text=prof["name"],
            on_submit=on_rename
        ).open()

    def _confirm_delete(self, prof: dict):
        def on_yes():
            ProfileService.delete(prof["id"])
            self._load_profiles()
            NeonMessageDialog("Deleted", f"Profile '{prof['name']}' deleted.").open()

        NeonConfirmDialog(
            title="Delete Profile?",
            message=f"Are you sure you want to permanently delete profile '{prof['name']}'?",
            on_confirm=on_yes
        ).open()

    def _create_new_profile_prompt(self, *args):
        def on_name(name):
            if not name:
                return
            ProfileService.save_or_update(
                name=name,
                general=180,
                red_dot=170,
                scope_2x=160,
                scope_4x=150,
                sniper=110,
                free_look=180,
                aim_style="Balanced"
            )
            self._load_profiles()
            NeonMessageDialog("Created", f"Profile '{name}' created with balanced defaults.").open()

        NeonInputDialog(
            title="New Profile",
            prompt="Enter profile name:",
            default_text="My_Pro_Sens",
            on_submit=on_name
        ).open()
