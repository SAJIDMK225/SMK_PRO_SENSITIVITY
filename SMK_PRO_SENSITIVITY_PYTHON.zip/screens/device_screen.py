"""
My Device Specifications Screen for SMK PRO SENSITIVITY.
Inspects exposed hardware capabilities and provides manual specification verification.
"""
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from widgets.neon_widgets import MagicBackground, NeonButton, NeonCard
from widgets.dialogs import NeonMessageDialog, NeonInputDialog
from screens.nav_header import ScreenHeader
from services.device_service import DeviceService
from localization.locales import tr


class DeviceScreen(Screen):
    """Hardware inspection and verification screen."""

    def __init__(self, **kwargs):
        super(DeviceScreen, self).__init__(**kwargs)
        self.name = "device"

        self.add_widget(MagicBackground())

        root = BoxLayout(orientation="vertical", padding=[10, 8, 10, 8], spacing=8)
        root.add_widget(ScreenHeader("nav_device", show_back=True, back_target="home"))

        scroll = ScrollView(size_hint=(1, 1), do_scroll_x=False)
        content = BoxLayout(orientation="vertical", spacing=10, size_hint_y=None)
        content.bind(minimum_height=content.setter("height"))

        # Specs Overview Card
        card = NeonCard(orientation="vertical", spacing=8, size_hint_y=None)
        card.bind(minimum_height=card.setter("height"))

        lbl_header = Label(
            text="[b]Detected Hardware Environment[/b]",
            markup=True,
            font_size="14sp",
            color=(0.0, 0.94, 1.0, 1.0),
            size_hint_y=None,
            height=26
        )
        card.add_widget(lbl_header)

        self.spec_widgets = {}
        fields = [
            ("brand", "Manufacturer / Brand"),
            ("model", "Device Model"),
            ("os_version", "Operating System"),
            ("ram_gb", "Physical RAM"),
            ("refresh_rate", "Screen Refresh Rate"),
            ("screen_res", "Display Resolution"),
            ("chipset", "Processor / Chipset"),
            ("fps_support", "Target Game FPS"),
        ]

        grid = GridLayout(cols=1, spacing=6, size_hint_y=None)
        grid.bind(minimum_height=grid.setter("height"))

        for key, title in fields:
            row = BoxLayout(orientation="horizontal", size_hint_y=None, height=36, spacing=6)
            lbl_title = Label(text=title, size_hint_x=0.45, font_size="11sp", color=(0.7, 0.75, 0.88, 1.0), halign="left")
            lbl_title.bind(size=lbl_title.setter("text_size"))
            
            lbl_val = Label(text="Loading...", size_hint_x=0.35, font_size="11sp", color=(0.95, 0.96, 1.0, 1.0), bold=True)
            lbl_badge = Label(text="[Unknown]", size_hint_x=0.20, font_size="10sp", color=(0.0, 0.9, 0.45, 1.0))

            row.add_widget(lbl_title)
            row.add_widget(lbl_val)
            row.add_widget(lbl_badge)
            grid.add_widget(row)
            self.spec_widgets[key] = (lbl_val, lbl_badge)

        card.add_widget(grid)

        # Action Buttons
        btn_box = BoxLayout(orientation="horizontal", spacing=8, size_hint_y=None, height=44)
        btn_refresh = NeonButton(text="Re-Detect", variant="purple", font_size="12sp")
        btn_edit = NeonButton(text="Edit / Confirm", variant="purple", font_size="12sp")
        btn_opt = NeonButton(text="Optimize", variant="primary", font_size="12sp")

        btn_refresh.bind(on_release=self._load_specs)
        btn_edit.bind(on_release=self._edit_specs)
        btn_opt.bind(on_release=self._optimize_device)

        btn_box.add_widget(btn_refresh)
        btn_box.add_widget(btn_edit)
        btn_box.add_widget(btn_opt)
        card.add_widget(btn_box)

        content.add_widget(card)

        # Android Limitations & Permission Note Card
        info_card = NeonCard(orientation="vertical", spacing=6, size_hint_y=None, height=125, padding=10)
        lbl_info_title = Label(
            text="[b]Hardware Detection Security Notice[/b]",
            markup=True,
            font_size="12sp",
            color=(0.61, 0.31, 0.87, 1.0),
            size_hint_y=None,
            height=20
        )
        lbl_info_text = Label(
            text=(
                "SMK PRO SENSITIVITY accesses only unprivileged standard platform properties. "
                "No root access or dangerous permissions are required. If dynamic refresh rate "
                "or exact touch digitizer hz is unexposed by your manufacturer, use the 'Edit / Confirm' "
                "button above to set your verified display specs manually."
            ),
            font_size="10sp",
            color=(0.65, 0.7, 0.82, 1.0),
            halign="left",
            valign="middle"
        )
        lbl_info_text.bind(size=lbl_info_text.setter("text_size"))
        info_card.add_widget(lbl_info_title)
        info_card.add_widget(lbl_info_text)
        content.add_widget(info_card)

        scroll.add_widget(content)
        root.add_widget(scroll)
        self.add_widget(root)

        self.current_specs = {}

    def on_enter(self, *args):
        self._load_specs()

    def _load_specs(self, *args):
        self.current_specs = DeviceService.detect_device_specs()
        for k, (lbl_v, lbl_b) in self.spec_widgets.items():
            val = self.current_specs.get(k, "Unknown")
            if k == "ram_gb":
                val = f"{val} GB"
            elif k in ("refresh_rate", "fps_support"):
                val = f"{val} Hz" if k == "refresh_rate" else f"{val} FPS"
            lbl_v.text = str(val)

            status = self.current_specs.get("status_flags", {}).get(k, "detected")
            lbl_b.text = DeviceService.format_status_badge(status)

    def _edit_specs(self, *args):
        def on_hz_confirmed(hz_text):
            try:
                hz = int(hz_text)
                self.current_specs["refresh_rate"] = hz
                self.current_specs.setdefault("status_flags", {})["refresh_rate"] = "user_confirmed"
                lbl_v, lbl_b = self.spec_widgets["refresh_rate"]
                lbl_v.text = f"{hz} Hz"
                lbl_b.text = "[User Confirmed]"
                NeonMessageDialog("Confirmed", f"Refresh rate updated to {hz} Hz.").open()
            except ValueError:
                NeonMessageDialog("Error", "Please enter a valid numeric refresh rate (e.g., 60, 90, 120).").open()

        NeonInputDialog(
            title="Manual Specification Entry",
            prompt="Enter your phone's actual screen refresh rate (e.g. 60, 90, 120, 144):",
            default_text=str(self.current_specs.get("refresh_rate", 60)),
            on_submit=on_hz_confirmed
        ).open()

    def _optimize_device(self, *args):
        if self.manager:
            gen_screen = self.manager.get_screen("generator")
            hz = self.current_specs.get("refresh_rate", 60)
            if hasattr(gen_screen, "spin_hz"):
                gen_screen.spin_hz.text = f"{hz} Hz"
            self.manager.current = "generator"
