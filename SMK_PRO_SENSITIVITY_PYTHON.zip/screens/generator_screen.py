"""
Sensitivity Generator Screen for SMK PRO SENSITIVITY.
Provides interactive fine-tuning and deterministic 0-200 calculation engine with glowing visual meters.
"""
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.spinner import Spinner
from kivy.uix.label import Label
from kivy.uix.progressbar import ProgressBar
from kivy.core.clipboard import Clipboard
from widgets.neon_widgets import MagicBackground, NeonButton, NeonCard
from widgets.dialogs import NeonMessageDialog, NeonInputDialog
from screens.nav_header import ScreenHeader
from services.sensitivity_engine import SensitivityEngine
from services.profile_service import ProfileService
from localization.locales import tr


class GeneratorScreen(Screen):
    """Main interactive sensitivity calculator."""

    def __init__(self, **kwargs):
        super(GeneratorScreen, self).__init__(**kwargs)
        self.name = "generator"

        # Magical gaming background
        self.add_widget(MagicBackground())

        root = BoxLayout(orientation="vertical", padding=[10, 8, 10, 8], spacing=8)
        root.add_widget(ScreenHeader("nav_generator", show_back=True, back_target="home"))

        scroll = ScrollView(size_hint=(1, 1), do_scroll_x=False)
        content = BoxLayout(orientation="vertical", spacing=10, size_hint_y=None)
        content.bind(minimum_height=content.setter("height"))

        # 1. Device & Parameter Tuning Card
        input_card = NeonCard(orientation="vertical", spacing=8, size_hint_y=None)
        input_card.bind(minimum_height=input_card.setter("height"))

        lbl_settings_header = Label(
            text="[b]🎮 Hardware & Playstyle Parameters[/b]",
            markup=True,
            font_size="14sp",
            color=(0.0, 0.94, 1.0, 1.0),
            size_hint_y=None,
            height=26
        )
        input_card.add_widget(lbl_settings_header)

        # Refresh Rate Spinner
        box_hz = BoxLayout(orientation="horizontal", size_hint_y=None, height=40, spacing=8)
        lbl_hz = Label(text="Refresh Rate:", size_hint_x=0.45, font_size="12sp", color=(0.85, 0.88, 0.96, 1.0))
        self.spin_hz = Spinner(
            text="60 Hz",
            values=("60 Hz", "90 Hz", "120 Hz", "144 Hz"),
            size_hint_x=0.55,
            background_color=(0.14, 0.16, 0.25, 1.0),
            color=(0.0, 0.94, 1.0, 1.0)
        )
        box_hz.add_widget(lbl_hz)
        box_hz.add_widget(self.spin_hz)
        input_card.add_widget(box_hz)

        # Aim & Drag Style Spinner
        box_aim = BoxLayout(orientation="horizontal", size_hint_y=None, height=40, spacing=8)
        lbl_aim = Label(text="Aim Drag Style:", size_hint_x=0.45, font_size="12sp", color=(0.85, 0.88, 0.96, 1.0))
        self.spin_aim = Spinner(
            text="Headshot Drag",
            values=("Headshot Drag", "Balanced", "Speed Rush (360)", "Sniper Precision"),
            size_hint_x=0.55,
            background_color=(0.14, 0.16, 0.25, 1.0),
            color=(0.0, 0.94, 1.0, 1.0)
        )
        box_aim.add_widget(lbl_aim)
        box_aim.add_widget(self.spin_aim)
        input_card.add_widget(box_aim)

        # Graphics Setting Spinner
        box_gfx = BoxLayout(orientation="horizontal", size_hint_y=None, height=40, spacing=8)
        lbl_gfx = Label(text="Graphics Quality:", size_hint_x=0.45, font_size="12sp", color=(0.85, 0.88, 0.96, 1.0))
        self.spin_gfx = Spinner(
            text="Smooth",
            values=("Smooth", "Standard", "Ultra", "Max"),
            size_hint_x=0.55,
            background_color=(0.14, 0.16, 0.25, 1.0),
            color=(0.0, 0.94, 1.0, 1.0)
        )
        box_gfx.add_widget(lbl_gfx)
        box_gfx.add_widget(self.spin_gfx)
        input_card.add_widget(box_gfx)

        # HUD Fingers Claw Spinner
        box_fingers = BoxLayout(orientation="horizontal", size_hint_y=None, height=40, spacing=8)
        lbl_fingers = Label(text="HUD Claw Grip:", size_hint_x=0.45, font_size="12sp", color=(0.85, 0.88, 0.96, 1.0))
        self.spin_fingers = Spinner(
            text="2 Fingers (Thumbs)",
            values=("2 Fingers (Thumbs)", "3 Finger Claw", "4 Finger Claw", "5 Finger Claw"),
            size_hint_x=0.55,
            background_color=(0.14, 0.16, 0.25, 1.0),
            color=(0.0, 0.94, 1.0, 1.0)
        )
        box_fingers.add_widget(lbl_fingers)
        box_fingers.add_widget(self.spin_fingers)
        input_card.add_widget(box_fingers)

        # Gyroscope Spinner
        box_gyro = BoxLayout(orientation="horizontal", size_hint_y=None, height=40, spacing=8)
        lbl_gyro = Label(text="Gyroscope Sensor:", size_hint_x=0.45, font_size="12sp", color=(0.85, 0.88, 0.96, 1.0))
        self.spin_gyro = Spinner(
            text="Disabled",
            values=("Disabled", "Scope Only", "Always On"),
            size_hint_x=0.55,
            background_color=(0.14, 0.16, 0.25, 1.0),
            color=(0.0, 0.94, 1.0, 1.0)
        )
        box_gyro.add_widget(lbl_gyro)
        box_gyro.add_widget(self.spin_gyro)
        input_card.add_widget(box_gyro)

        # Calculate Button with magical feedback
        btn_run = NeonButton(
            text=f"⚡ CALCULATE OPTIMAL VALUES ⚡",
            variant="primary",
            size_hint_y=None,
            height=48,
            font_size="14sp"
        )
        btn_run.bind(on_release=self._generate_values)
        input_card.add_widget(btn_run)

        content.add_widget(input_card)

        # 2. Glowing Results Display Card
        self.results_card = NeonCard(orientation="vertical", spacing=8, size_hint_y=None)
        self.results_card.bind(minimum_height=self.results_card.setter("height"))

        lbl_res_header = Label(
            text="[b]🎯 Pro Sensitivity Output (Scale 0 - 200)[/b]",
            markup=True,
            font_size="14sp",
            color=(0.61, 0.31, 0.87, 1.0),
            size_hint_y=None,
            height=26
        )
        self.results_card.add_widget(lbl_res_header)

        # 6 Sens Value Cards with Level Bars
        self.sens_labels = {}
        self.sens_bars = {}
        grid_res = GridLayout(cols=2, spacing=8, size_hint_y=None)
        grid_res.bind(minimum_height=grid_res.setter("height"))

        sens_items = [
            ("general", "General Sensitivity"),
            ("red_dot", "Red Dot Sight"),
            ("scope_2x", "2x Scope"),
            ("scope_4x", "4x Scope"),
            ("sniper", "Sniper Scope (ADS)"),
            ("free_look", "Free Look Camera"),
        ]

        for key, name in sens_items:
            box_item = BoxLayout(orientation="vertical", size_hint_y=None, height=72, padding=4, spacing=2)
            lbl_name = Label(text=name, font_size="11sp", color=(0.75, 0.8, 0.92, 1.0), size_hint_y=0.35)
            
            lbl_val = Label(text="---", font_size="19sp", bold=True, color=(0.0, 0.94, 1.0, 1.0), size_hint_y=0.45)
            
            bar = ProgressBar(max=200, value=0, size_hint_y=0.2)
            
            box_item.add_widget(lbl_name)
            box_item.add_widget(lbl_val)
            box_item.add_widget(bar)
            grid_res.add_widget(box_item)
            self.sens_labels[key] = lbl_val
            self.sens_bars[key] = bar

        self.results_card.add_widget(grid_res)

        # Action Buttons Box (Copy, Save, Calibration Guide)
        action_box = BoxLayout(orientation="horizontal", spacing=8, size_hint_y=None, height=44)
        btn_copy = NeonButton(text="📋 " + tr("btn_copy"), variant="purple", font_size="11sp")
        btn_save = NeonButton(text="💾 " + tr("btn_save_profile"), variant="primary", font_size="11sp")
        btn_calib = NeonButton(text="🎯 Calibration Guide", variant="purple", font_size="11sp")

        btn_copy.bind(on_release=self._copy_results)
        btn_save.bind(on_release=self._save_profile_dialog)
        btn_calib.bind(on_release=self._show_calibration_guide)

        action_box.add_widget(btn_copy)
        action_box.add_widget(btn_save)
        action_box.add_widget(btn_calib)
        self.results_card.add_widget(action_box)

        content.add_widget(self.results_card)

        # Disclaimer footer
        lbl_disc = Label(
            text="* Free Fire scale: 0-200. Apply manually in game settings. 100% fair play, no memory hacking.",
            font_size="10sp",
            color=(0.55, 0.60, 0.72, 1.0),
            size_hint_y=None,
            height=25,
            halign="center"
        )
        content.add_widget(lbl_disc)

        scroll.add_widget(content)
        root.add_widget(scroll)
        self.add_widget(root)

        # Current generated values cache
        self.current_sens = {
            "general": 185, "red_dot": 175, "scope_2x": 165,
            "scope_4x": 150, "sniper": 110, "free_look": 180
        }
        self._render_values()

    def _generate_values(self, *args):
        hz_text = self.spin_hz.text
        hz = int(hz_text.replace(" Hz", "")) if "Hz" in hz_text else 60

        fingers_text = self.spin_fingers.text
        fingers = 2
        if "3" in fingers_text:
            fingers = 3
        elif "4" in fingers_text:
            fingers = 4
        elif "5" in fingers_text:
            fingers = 5

        res = SensitivityEngine.calculate(
            refresh_rate=hz,
            aim_style=self.spin_aim.text,
            graphics=self.spin_gfx.text,
            hud_fingers=fingers,
            gyro_mode=self.spin_gyro.text
        )

        for k in self.current_sens:
            self.current_sens[k] = res[k]

        self._render_values()

    def _render_values(self):
        for k, lbl in self.sens_labels.items():
            val = self.current_sens.get(k, 0)
            lbl.text = str(val)
            if k in self.sens_bars:
                self.sens_bars[k].value = val

    def _copy_results(self, *args):
        text_rep = (
            f"SMK PRO SENSITIVITY:\n"
            f"General: {self.current_sens['general']}\n"
            f"Red Dot: {self.current_sens['red_dot']}\n"
            f"2x Scope: {self.current_sens['scope_2x']}\n"
            f"4x Scope: {self.current_sens['scope_4x']}\n"
            f"Sniper Scope: {self.current_sens['sniper']}\n"
            f"Free Look: {self.current_sens['free_look']}\n"
        )
        Clipboard.copy(text_rep)
        NeonMessageDialog("Clipboard", tr("btn_copied")).open()

    def _save_profile_dialog(self, *args):
        def on_name_submit(name):
            if not name:
                return
            ok, msg = ProfileService.save_or_update(
                name=name,
                general=self.current_sens["general"],
                red_dot=self.current_sens["red_dot"],
                scope_2x=self.current_sens["scope_2x"],
                scope_4x=self.current_sens["scope_4x"],
                sniper=self.current_sens["sniper"],
                free_look=self.current_sens["free_look"],
                aim_style=self.spin_aim.text
            )
            NeonMessageDialog("Save Profile", msg).open()

        NeonInputDialog(
            title=tr("btn_save_profile"),
            prompt="Enter a unique name for this sensitivity profile:",
            default_text=f"Custom_{self.spin_aim.text[:6]}_{self.spin_hz.text[:3]}",
            on_submit=on_name_submit
        ).open()

    def _show_calibration_guide(self, *args):
        guide = SensitivityEngine.get_calibration_guide()
        NeonMessageDialog("Calibration Training", guide).open()
