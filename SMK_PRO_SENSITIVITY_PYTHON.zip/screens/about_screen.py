"""
About & Legal Privacy Screen for SMK PRO SENSITIVITY.
Affirmations of zero-cost architecture, privacy compliance, and third-party disclaimers.
"""
import webbrowser
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.core.clipboard import Clipboard
from widgets.neon_widgets import MagicBackground, NeonButton, NeonCard
from widgets.dialogs import NeonMessageDialog
from screens.nav_header import ScreenHeader
from core.config import APP_NAME, APP_VERSION, APP_AUTHOR, WHATSAPP_CHANNEL_URL, YOUTUBE_CHANNEL_URL


class AboutScreen(Screen):
    """About, terms, legal disclaimers, and social channels."""

    def __init__(self, **kwargs):
        super(AboutScreen, self).__init__(**kwargs)
        self.name = "about"

        self.add_widget(MagicBackground())

        root = BoxLayout(orientation="vertical", padding=[10, 8, 10, 8], spacing=8)
        root.add_widget(ScreenHeader("nav_about", show_back=True, back_target="home"))

        scroll = ScrollView(size_hint=(1, 1), do_scroll_x=False)
        content = BoxLayout(orientation="vertical", spacing=10, size_hint_y=None)
        content.bind(minimum_height=content.setter("height"))

        # App Overview Card
        card_info = NeonCard(orientation="vertical", spacing=6, size_hint_y=None, height=125, padding=10)
        lbl_title = Label(
            text=f"[b]{APP_NAME}[/b] (v{APP_VERSION})",
            markup=True,
            font_size="15sp",
            color=(0.0, 0.94, 1.0, 1.0),
            size_hint_y=None,
            height=25
        )
        lbl_author = Label(
            text=f"Engineered by {APP_AUTHOR}",
            font_size="11sp",
            color=(0.61, 0.31, 0.87, 1.0),
            size_hint_y=None,
            height=20
        )
        lbl_zero = Label(
            text="Architecture: 100% Offline | Zero-Cost | No Paid APIs | No Tracking",
            font_size="10sp",
            color=(0.0, 0.9, 0.45, 1.0),
            size_hint_y=None,
            height=20
        )
        card_info.add_widget(lbl_title)
        card_info.add_widget(lbl_author)
        card_info.add_widget(lbl_zero)
        content.add_widget(card_info)

        # Official Social Channels Card
        card_links = NeonCard(orientation="vertical", spacing=8, size_hint_y=None, height=135, padding=10)
        lbl_comm = Label(
            text="[b]Official Free Community Links[/b]",
            markup=True,
            font_size="13sp",
            color=(0.0, 0.94, 1.0, 1.0),
            size_hint_y=None,
            height=20
        )
        card_links.add_widget(lbl_comm)

        btn_wa = NeonButton(
            text="Join WhatsApp Channel",
            variant="success",
            size_hint_y=None,
            height=40,
            font_size="12sp"
        )
        btn_wa.bind(on_release=lambda x: self._open_url(WHATSAPP_CHANNEL_URL, "WhatsApp Channel"))

        btn_yt = NeonButton(
            text="Visit YouTube Channel (@sajidgaming225)",
            variant="danger",
            size_hint_y=None,
            height=40,
            font_size="12sp"
        )
        btn_yt.bind(on_release=lambda x: self._open_url(YOUTUBE_CHANNEL_URL, "YouTube Channel"))

        card_links.add_widget(btn_wa)
        card_links.add_widget(btn_yt)
        content.add_widget(card_links)

        # Mandatory Third-Party Legal Disclaimer Card
        card_disc = NeonCard(orientation="vertical", spacing=6, size_hint_y=None, height=160, padding=10)
        lbl_d_title = Label(
            text="[b]Legal Disclaimer & Fair Play Declaration[/b]",
            markup=True,
            font_size="12sp",
            color=(1.0, 0.23, 0.36, 1.0),
            size_hint_y=None,
            height=20
        )
        lbl_d_body = Label(
            text=(
                "SMK PRO SENSITIVITY is an independent mathematical recommendation tool. "
                "It is NOT affiliated with, authorized, maintained, sponsored, or endorsed by "
                "Garena, Free Fire, or any of its affiliates.\n\n"
                "FAIR PLAY GUARANTEE: This application does NOT modify game binary files, hook into RAM, "
                "alter network traffic, or inject scripts. All sensitivity values generated are intended for the "
                "player to manually enter into the game's official sensitivity menu."
            ),
            font_size="10sp",
            color=(0.7, 0.75, 0.88, 1.0),
            halign="left"
        )
        lbl_d_body.bind(size=lbl_d_body.setter("text_size"))
        card_disc.add_widget(lbl_d_title)
        card_disc.add_widget(lbl_d_body)
        content.add_widget(card_disc)

        scroll.add_widget(content)
        root.add_widget(scroll)
        self.add_widget(root)

    def _open_url(self, url: str, title: str):
        try:
            webbrowser.open(url)
        except Exception:
            Clipboard.copy(url)
            NeonMessageDialog(title, f"Could not launch browser automatically.\nLink copied:\n{url}").open()
