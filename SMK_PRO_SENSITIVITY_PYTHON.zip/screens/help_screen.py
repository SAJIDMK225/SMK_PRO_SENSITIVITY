"""
Help & Calibration Troubleshooting Guide Screen for SMK PRO SENSITIVITY.
Educational knowledge base for competitive Free Fire players.
"""
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from widgets.neon_widgets import MagicBackground, NeonButton, NeonCard
from screens.nav_header import ScreenHeader


class HelpScreen(Screen):
    """Knowledge base, calibration steps, and troubleshooting tips."""

    def __init__(self, **kwargs):
        super(HelpScreen, self).__init__(**kwargs)
        self.name = "help"

        self.add_widget(MagicBackground())

        root = BoxLayout(orientation="vertical", padding=[10, 8, 10, 8], spacing=8)
        root.add_widget(ScreenHeader("nav_help", show_back=True, back_target="home"))

        scroll = ScrollView(size_hint=(1, 1), do_scroll_x=False)
        content = BoxLayout(orientation="vertical", spacing=10, size_hint_y=None)
        content.bind(minimum_height=content.setter("height"))

        guides = [
            (
                "🎯 Training Ground 1-Tap Drag Calibration",
                (
                    "1. Equip an M1887 or Desert Eagle, stand 10-15m from the target dummy.\n"
                    "2. Perform your standard upward flick drag:\n"
                    "   - If your bullets stick to the body/chest: Your General is TOO LOW. Increase by +4.\n"
                    "   - If your crosshair flies over the head into the sky: Your General is TOO HIGH. Decrease by -4.\n"
                    "3. Repeat 20 shots until 16+ connect cleanly as red headshots."
                )
            ),
            (
                "⚡ Why 60Hz and 120Hz Need Different Sensitivities",
                (
                    "Phones with 120Hz/144Hz screens have touch digitizers polling at 240Hz to 480Hz. "
                    "A small swipe covers more distance with less latency. Therefore, 120Hz players usually need "
                    "General ~170-178 to avoid overshooting.\n\n"
                    "Phones at 60Hz have higher touch latency, requiring higher General (~190-200) "
                    "to register the fast flick before the enemy moves."
                )
            ),
            (
                "🎮 HUD Claw Fingers vs Thumb Player",
                (
                    "2-Finger (Thumbs): Your right thumb handles both aiming and jumping/crouching. "
                    "Keep sensitivity slightly higher so short thumb flicks achieve full 180 turns.\n\n"
                    "4-Finger Claw: You have a dedicated aim thumb while index fingers jump and fire. "
                    "You can comfortably use slightly lower, stabler sensitivities for laser-accurate sprays."
                )
            ),
            (
                "🔧 Common Troubleshooting Tips",
                (
                    "- Touch Delay / Frame Drops: In game settings, switch Graphics to 'Smooth' and High FPS to 'High'.\n"
                    "- Touch Sticking: Clean screen protector of moisture or oil.\n"
                    "- Screen Jitter: Ensure phone is not overheating or charging with an ungrounded charger."
                )
            )
        ]

        for title, text in guides:
            card = NeonCard(orientation="vertical", spacing=6, size_hint_y=None)
            card.bind(minimum_height=card.setter("height"))

            lbl_t = Label(
                text=f"[b]{title}[/b]",
                markup=True,
                font_size="13sp",
                color=(0.0, 0.94, 1.0, 1.0),
                size_hint_y=None,
                height=24,
                halign="left"
            )
            lbl_t.bind(size=lbl_t.setter("text_size"))

            lbl_b = Label(
                text=text,
                font_size="11sp",
                color=(0.85, 0.88, 0.96, 1.0),
                size_hint_y=None,
                halign="left",
                valign="top"
            )
            lbl_b.bind(size=lbl_b.setter("text_size"))
            # Auto-calculate height based on line breaks
            lbl_b.height = max(70, len(text.split("\n")) * 18 + 25)

            card.add_widget(lbl_t)
            card.add_widget(lbl_b)
            content.add_widget(card)

        scroll.add_widget(content)
        root.add_widget(scroll)
        self.add_widget(root)
