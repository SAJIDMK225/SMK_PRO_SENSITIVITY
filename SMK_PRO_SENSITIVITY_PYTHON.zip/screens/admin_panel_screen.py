"""
Local Admin Panel Screen for SMK PRO SENSITIVITY.
Coordinates offline license key generation, key revocation, stats, and password rotation.
"""
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.spinner import Spinner
from kivy.uix.label import Label
from kivy.core.clipboard import Clipboard
from widgets.neon_widgets import MagicBackground, NeonButton, NeonCard
from widgets.dialogs import NeonMessageDialog, NeonConfirmDialog, NeonInputDialog
from screens.nav_header import ScreenHeader
from security.auth import AdminAuthService
from security.keys import KeyManager
from database.db import DatabaseManager
from localization.locales import tr


class AdminPanelScreen(Screen):
    """Owner dashboard for key generation, diagnostics, and security."""

    def __init__(self, **kwargs):
        super(AdminPanelScreen, self).__init__(**kwargs)
        self.name = "admin_panel"

        self.add_widget(MagicBackground())

        root = BoxLayout(orientation="vertical", padding=[10, 8, 10, 8], spacing=8)
        
        # Header with explicit Logout
        header_box = BoxLayout(orientation="horizontal", size_hint_y=None, height=48, spacing=8)
        lbl_head = Label(
            text="[b]SMK Owner Control Panel[/b]",
            markup=True,
            font_size="15sp",
            color=(0.0, 0.94, 1.0, 1.0),
            size_hint_x=0.7,
            halign="left"
        )
        lbl_head.bind(size=lbl_head.setter("text_size"))
        btn_logout = NeonButton(
            text=tr("btn_logout"),
            variant="danger",
            size_hint=(None, 1),
            width=80,
            font_size="12sp"
        )
        btn_logout.bind(on_release=self._logout)
        header_box.add_widget(lbl_head)
        header_box.add_widget(btn_logout)
        root.add_widget(header_box)

        scroll = ScrollView(size_hint=(1, 1), do_scroll_x=False)
        content = BoxLayout(orientation="vertical", spacing=10, size_hint_y=None)
        content.bind(minimum_height=content.setter("height"))

        # 1. System Database Stats Card
        self.stats_card = NeonCard(orientation="vertical", spacing=4, size_hint_y=None, height=75, padding=8)
        self.lbl_stats = Label(
            text="Loading diagnostics...",
            font_size="11sp",
            color=(0.85, 0.88, 0.96, 1.0),
            halign="left"
        )
        self.lbl_stats.bind(size=self.lbl_stats.setter("text_size"))
        self.stats_card.add_widget(self.lbl_stats)
        content.add_widget(self.stats_card)

        # 2. Key Generation Card
        key_gen_card = NeonCard(orientation="vertical", spacing=8, size_hint_y=None, height=130, padding=10)
        lbl_kg = Label(
            text="[b]Generate Offline Activation Key[/b]",
            markup=True,
            font_size="13sp",
            color=(0.61, 0.31, 0.87, 1.0),
            size_hint_y=None,
            height=20
        )
        key_gen_card.add_widget(lbl_kg)

        row_gen = BoxLayout(orientation="horizontal", spacing=8, size_hint_y=None, height=38)
        self.spin_key_type = Spinner(
            text="Lifetime",
            values=("Lifetime", "7 Days", "30 Days", "90 Days", "365 Days"),
            size_hint_x=0.45,
            background_color=(0.14, 0.16, 0.25, 1.0),
            color=(0.0, 0.94, 1.0, 1.0)
        )
        btn_create = NeonButton(
            text=tr("btn_create_key"),
            variant="primary",
            size_hint_x=0.55,
            font_size="12sp"
        )
        btn_create.bind(on_release=self._generate_key)
        row_gen.add_widget(self.spin_key_type)
        row_gen.add_widget(btn_create)
        key_gen_card.add_widget(row_gen)

        # Password change shortcut
        btn_ch_pass = NeonButton(
            text="Change Admin Password",
            variant="purple",
            size_hint_y=None,
            height=34,
            font_size="11sp"
        )
        btn_ch_pass.bind(on_release=self._prompt_change_password)
        key_gen_card.add_widget(btn_ch_pass)
        content.add_widget(key_gen_card)

        # 3. Keys List Filter & Display
        filter_row = BoxLayout(orientation="horizontal", spacing=8, size_hint_y=None, height=36)
        lbl_filter = Label(text="Filter Status:", font_size="11sp", color=(0.7, 0.75, 0.88, 1.0), size_hint_x=0.4)
        self.spin_status_filter = Spinner(
            text="All",
            values=("All", "Unused", "Active", "Expired", "Revoked"),
            size_hint_x=0.6,
            background_color=(0.14, 0.16, 0.25, 1.0),
            color=(0.0, 0.94, 1.0, 1.0)
        )
        self.spin_status_filter.bind(text=self._on_filter_changed)
        filter_row.add_widget(lbl_filter)
        filter_row.add_widget(self.spin_status_filter)
        content.add_widget(filter_row)

        self.keys_list_box = BoxLayout(orientation="vertical", spacing=8, size_hint_y=None)
        self.keys_list_box.bind(minimum_height=self.keys_list_box.setter("height"))
        content.add_widget(self.keys_list_box)

        scroll.add_widget(content)
        root.add_widget(scroll)
        self.add_widget(root)

    def on_enter(self, *args):
        if not AdminAuthService.is_authenticated():
            if self.manager:
                self.manager.current = "admin_login"
            return
        self._refresh_stats()
        self._load_keys()

    def _refresh_stats(self):
        with DatabaseManager.get_connection() as conn:
            c = conn.cursor()
            c.execute("SELECT COUNT(*) FROM profiles")
            p_cnt = c.fetchone()[0]
            c.execute("SELECT COUNT(*) FROM phone_devices")
            d_cnt = c.fetchone()[0]
            c.execute("SELECT COUNT(*) FROM activation_keys")
            k_cnt = c.fetchone()[0]
            c.execute("SELECT COUNT(*) FROM user_feedback")
            f_cnt = c.fetchone()[0]

        self.lbl_stats.text = f"Database Records: {p_cnt} Profiles | {d_cnt} Devices | {k_cnt} Keys | {f_cnt} Feedbacks"

    def _generate_key(self, *args):
        choice = self.spin_key_type.text
        if choice == "Lifetime":
            k_type = "lifetime"
            days = 0
        else:
            k_type = "limited"
            days = int(choice.split()[0])

        key_code = KeyManager.generate_key(key_type=k_type, duration_days=days, note="Generated via Admin Panel")
        Clipboard.copy(key_code)
        self._refresh_stats()
        self._load_keys()
        NeonMessageDialog("Key Created & Copied", f"New Pro Key:\n[b]{key_code}[/b]\n(Copied to clipboard)").open()

    def _on_filter_changed(self, instance, text):
        self._load_keys()

    def _load_keys(self):
        self.keys_list_box.clear_widgets()
        status = self.spin_status_filter.text.lower()
        keys = KeyManager.list_keys(status_filter=status)

        if not keys:
            lbl_none = Label(text="No keys found in this filter.", font_size="12sp", color=(0.6, 0.65, 0.75, 1.0), size_hint_y=None, height=40)
            self.keys_list_box.add_widget(lbl_none)
            return

        for k in keys:
            card = NeonCard(orientation="vertical", spacing=4, size_hint_y=None, height=90, padding=8)

            row1 = BoxLayout(orientation="horizontal", size_hint_y=None, height=24)
            lbl_code = Label(
                text=f"[b]{k['key_code']}[/b]",
                markup=True,
                font_size="13sp",
                color=(0.0, 0.94, 1.0, 1.0),
                size_hint_x=0.7,
                halign="left"
            )
            lbl_code.bind(size=lbl_code.setter("text_size"))

            # Status color
            st_color = (0.0, 0.9, 0.45, 1.0) if k['status'] == 'active' else (0.7, 0.75, 0.88, 1.0) if k['status'] == 'unused' else (1.0, 0.23, 0.36, 1.0)
            lbl_st = Label(
                text=k['status'].upper(),
                font_size="11sp",
                bold=True,
                color=st_color,
                size_hint_x=0.3,
                halign="right"
            )
            lbl_st.bind(size=lbl_st.setter("text_size"))
            row1.add_widget(lbl_code)
            row1.add_widget(lbl_st)
            card.add_widget(row1)

            # Details
            details = f"Type: {k['key_type'].capitalize()} ({k['duration_days']}d) | Created: {k['created_at'][:10]}"
            lbl_det = Label(text=details, font_size="10sp", color=(0.65, 0.7, 0.8, 1.0), size_hint_y=None, height=18, halign="left")
            lbl_det.bind(size=lbl_det.setter("text_size"))
            card.add_widget(lbl_det)

            # Action Buttons (Copy, Revoke)
            btn_box = BoxLayout(orientation="horizontal", spacing=6, size_hint_y=None, height=30)
            btn_cp = NeonButton(text="Copy", variant="primary", font_size="10sp")
            btn_cp.bind(on_release=lambda inst, code=k['key_code']: self._copy_key(code))
            btn_box.add_widget(btn_cp)

            if k['status'] in ('unused', 'active'):
                btn_rev = NeonButton(text="Revoke", variant="danger", font_size="10sp")
                btn_rev.bind(on_release=lambda inst, kid=k['id']: self._confirm_revoke(kid))
                btn_box.add_widget(btn_rev)

            card.add_widget(btn_box)
            self.keys_list_box.add_widget(card)

    def _copy_key(self, code: str):
        Clipboard.copy(code)
        NeonMessageDialog("Clipboard", f"Copied key {code} to clipboard.").open()

    def _confirm_revoke(self, key_id: int):
        def on_confirm():
            KeyManager.deactivate_key(key_id)
            self._load_keys()
            NeonMessageDialog("Revoked", "Key revoked locally.").open()

        NeonConfirmDialog(
            title="Revoke Key?",
            message="Revoking this key disables Pro features on this installation. Confirm?",
            on_confirm=on_confirm
        ).open()

    def _prompt_change_password(self, *args):
        def on_old(old_pass):
            if not old_pass:
                return
            def on_new(new_pass):
                if not new_pass:
                    return
                ok, msg = AdminAuthService.change_password(old_pass, new_pass)
                NeonMessageDialog("Password Update", msg).open()

            NeonInputDialog(
                title="New Password",
                prompt="Enter your new admin password (minimum 6 characters):",
                is_password=True,
                on_submit=on_new
            ).open()

        NeonInputDialog(
            title="Verify Current Password",
            prompt="Enter current admin password to proceed:",
            is_password=True,
            on_submit=on_old
        ).open()

    def _logout(self, *args):
        AdminAuthService.logout()
        if self.manager:
            self.manager.current = "home"
