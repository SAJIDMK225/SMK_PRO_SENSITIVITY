"""
Offline Phone Database Screen for SMK PRO SENSITIVITY.
Searches, filters, and loads empirically tuned sensitivities for 25+ gaming devices.
"""
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.spinner import Spinner
from kivy.uix.textinput import TextInput
from kivy.uix.label import Label
from widgets.neon_widgets import MagicBackground, NeonButton, NeonCard
from widgets.dialogs import NeonMessageDialog, NeonInputDialog
from screens.nav_header import ScreenHeader
from database.db import DatabaseManager
from localization.locales import tr


class PhoneDatabaseScreen(Screen):
    """Offline searchable database of gaming phones."""

    def __init__(self, **kwargs):
        super(PhoneDatabaseScreen, self).__init__(**kwargs)
        self.name = "phone_db"

        self.add_widget(MagicBackground())

        root = BoxLayout(orientation="vertical", padding=[10, 8, 10, 8], spacing=8)
        root.add_widget(ScreenHeader("nav_phone_db", show_back=True, back_target="home"))

        # Filter and Search Bar Card
        filter_card = NeonCard(orientation="vertical", spacing=8, size_hint_y=None, height=95, padding=8)

        search_row = BoxLayout(orientation="horizontal", spacing=8, size_hint_y=None, height=38)
        self.txt_search = TextInput(
            hint_text="Search model or chipset...",
            multiline=False,
            size_hint_x=0.7,
            background_color=(0.14, 0.16, 0.25, 1.0),
            foreground_color=(0.95, 0.96, 1.0, 1.0),
            cursor_color=(0.0, 0.94, 1.0, 1.0)
        )
        self.txt_search.bind(text=self._on_search_text_changed)

        self.spin_brand = Spinner(
            text="All Brands",
            values=("All Brands",),
            size_hint_x=0.3,
            background_color=(0.14, 0.16, 0.25, 1.0),
            color=(0.0, 0.94, 1.0, 1.0)
        )
        self.spin_brand.bind(text=self._on_brand_selected)

        search_row.add_widget(self.txt_search)
        search_row.add_widget(self.spin_brand)
        filter_card.add_widget(search_row)

        # Quick Add Device button
        btn_add = NeonButton(
            text="+ Add Custom Phone Model (Offline)",
            variant="purple",
            size_hint_y=None,
            height=32,
            font_size="11sp"
        )
        btn_add.bind(on_release=self._add_custom_phone_dialog)
        filter_card.add_widget(btn_add)

        root.add_widget(filter_card)

        # Scrollable Phone List
        self.scroll = ScrollView(size_hint=(1, 1), do_scroll_x=False)
        self.list_container = BoxLayout(orientation="vertical", spacing=8, size_hint_y=None)
        self.list_container.bind(minimum_height=self.list_container.setter("height"))
        self.scroll.add_widget(self.list_container)
        root.add_widget(self.scroll)

        self.add_widget(root)

    def on_enter(self, *args):
        self._refresh_brand_spinner()
        self._load_phones()

    def _refresh_brand_spinner(self):
        brands = DatabaseManager.get_phone_brands()
        self.spin_brand.values = ["All Brands"] + brands

    def _on_search_text_changed(self, instance, text):
        self._load_phones()

    def _on_brand_selected(self, instance, text):
        self._load_phones()

    def _load_phones(self):
        self.list_container.clear_widgets()
        query = self.txt_search.text.strip()
        brand = self.spin_brand.text.strip()
        brand_filter = "" if brand == "All Brands" else brand

        phones = DatabaseManager.search_phones(query=query, brand_filter=brand_filter)

        if not phones:
            lbl_empty = Label(
                text="No phones found matching search criteria.",
                font_size="13sp",
                color=(0.6, 0.65, 0.78, 1.0),
                size_hint_y=None,
                height=50
            )
            self.list_container.add_widget(lbl_empty)
            return

        for p in phones:
            item_card = NeonCard(orientation="vertical", spacing=4, size_hint_y=None, height=105, padding=8)

            top_row = BoxLayout(orientation="horizontal", size_hint_y=None, height=24)
            lbl_name = Label(
                text=f"[b]{p['brand']} {p['model']}[/b]",
                markup=True,
                font_size="13sp",
                color=(0.0, 0.94, 1.0, 1.0),
                size_hint_x=0.75,
                halign="left"
            )
            lbl_name.bind(size=lbl_name.setter("text_size"))

            badge_text = f"[{p.get('verification_status', 'verified').capitalize()}]"
            lbl_badge = Label(
                text=badge_text,
                font_size="10sp",
                color=(0.0, 0.9, 0.45, 1.0),
                size_hint_x=0.25,
                halign="right"
            )
            lbl_badge.bind(size=lbl_badge.setter("text_size"))

            top_row.add_widget(lbl_name)
            top_row.add_widget(lbl_badge)
            item_card.add_widget(top_row)

            # Specs line
            specs_text = f"RAM: {p['ram_gb']}GB | Hz: {p['refresh_rate']}Hz | Chip: {p['chipset']}"
            lbl_specs = Label(text=specs_text, font_size="11sp", color=(0.7, 0.75, 0.88, 1.0), size_hint_y=None, height=20, halign="left")
            lbl_specs.bind(size=lbl_specs.setter("text_size"))
            item_card.add_widget(lbl_specs)

            # Bottom Action Line
            bot_row = BoxLayout(orientation="horizontal", size_hint_y=None, height=36, spacing=6)
            rec_text = f"Rec Sens: Gen {p['recommended_general']} | RedDot {p['recommended_red_dot']}"
            lbl_rec = Label(text=rec_text, font_size="11sp", color=(0.61, 0.31, 0.87, 1.0), size_hint_x=0.65, halign="left")
            lbl_rec.bind(size=lbl_rec.setter("text_size"))

            btn_load = NeonButton(text="Apply Sens", variant="primary", size_hint_x=0.35, font_size="11sp")
            btn_load.bind(on_release=lambda inst, phone=p: self._apply_phone_sens(phone))

            bot_row.add_widget(lbl_rec)
            bot_row.add_widget(btn_load)
            item_card.add_widget(bot_row)

            self.list_container.add_widget(item_card)

    def _apply_phone_sens(self, phone: dict):
        if self.manager:
            gen_screen = self.manager.get_screen("generator")
            hz = phone.get("refresh_rate", 60)
            if hasattr(gen_screen, "spin_hz"):
                gen_screen.spin_hz.text = f"{hz} Hz"
            if hasattr(gen_screen, "current_sens"):
                gen_screen.current_sens["general"] = phone.get("recommended_general", 180)
                gen_screen.current_sens["red_dot"] = phone.get("recommended_red_dot", 170)
                gen_screen._render_values()
            self.manager.current = "generator"
            NeonMessageDialog("Device Preset Loaded", f"Applied optimal settings for {phone['brand']} {phone['model']}!").open()

    def _add_custom_phone_dialog(self, *args):
        def on_submit(text_line):
            # Format: Brand, Model, RAM, RefreshRate, Chipset
            parts = [p.strip() for p in text_line.split(",")]
            if len(parts) < 2:
                NeonMessageDialog("Error", "Please enter at least 'Brand, Model' separated by commas.").open()
                return

            brand = parts[0]
            model = parts[1]
            ram = int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else 8
            hz = int(parts[3]) if len(parts) > 3 and parts[3].isdigit() else 120
            chip = parts[4] if len(parts) > 4 else "Octa-Core"

            try:
                DatabaseManager.add_custom_phone(
                    brand=brand,
                    model=model,
                    ram_gb=ram,
                    storage_gb=128,
                    refresh_rate=hz,
                    chipset=chip,
                    fps_support=60,
                    recommended_general=180,
                    recommended_red_dot=172,
                    notes="Manually added by user."
                )
                self._refresh_brand_spinner()
                self._load_phones()
                NeonMessageDialog("Success", f"Added {brand} {model} to offline database!").open()
            except Exception as e:
                NeonMessageDialog("Error", f"Failed to save phone: {str(e)}").open()

        NeonInputDialog(
            title="Add Custom Phone",
            prompt="Enter: Brand, Model, RAM(GB), RefreshRate(Hz), Chipset\n(e.g., Poco, F5, 8, 120, Snapdragon 7+ Gen 2):",
            default_text="Xiaomi, Redmi 12, 6, 90, Helio G88",
            on_submit=on_submit
        ).open()
