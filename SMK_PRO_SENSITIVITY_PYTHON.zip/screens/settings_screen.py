"""
Settings & Customization Screen for SMK PRO SENSITIVITY.
Controls visual themes, animations/reduced-motion, and dynamic localization.
"""
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.spinner import Spinner
from kivy.uix.switch import Switch
from kivy.uix.label import Label
from widgets.neon_widgets import MagicBackground, NeonButton, NeonCard
from widgets.dialogs import NeonMessageDialog, NeonConfirmDialog
from screens.nav_header import ScreenHeader
from database.db import DatabaseManager
from localization.locales import LocaleManager, tr
import core.config as config


class SettingsScreen(Screen):
    """App preferences and customization view."""

    def __init__(self, **kwargs):
        super(SettingsScreen, self).__init__(**kwargs)
        self.name = "settings"

        self.add_widget(MagicBackground())

        root = BoxLayout(orientation="vertical", padding=[10, 8, 10, 8], spacing=8)
        root.add_widget(ScreenHeader("nav_settings", show_back=True, back_target="home"))

        scroll = ScrollView(size_hint=(1, 1), do_scroll_x=False)
        content = BoxLayout(orientation="vertical", spacing=10, size_hint_y=None)
        content.bind(minimum_height=content.setter("height"))

        # 1. Appearance & Themes Card
        theme_card = NeonCard(orientation="vertical", spacing=8, size_hint_y=None)
        theme_card.bind(minimum_height=theme_card.setter("height"))

        lbl_th_head = Label(
            text="[b]Visual Theme & Display[/b]",
            markup=True,
            font_size="13sp",
            color=(0.0, 0.94, 1.0, 1.0),
            size_hint_y=None,
            height=24
        )
        theme_card.add_widget(lbl_th_head)

        row_th = BoxLayout(orientation="horizontal", size_hint_y=None, height=40, spacing=8)
        lbl_th = Label(text=tr("settings_theme"), size_hint_x=0.4, font_size="12sp", color=(0.7, 0.75, 0.88, 1.0))
        self.spin_theme = Spinner(
            text="Neon Cyber (Cyan & Blue)",
            values=("Neon Cyber (Cyan & Blue)", "Neon Syndicate (Purple)", "Amber Strike (Gold)"),
            size_hint_x=0.6,
            background_color=(0.14, 0.16, 0.25, 1.0),
            color=(0.0, 0.94, 1.0, 1.0)
        )
        self.spin_theme.bind(text=self._on_theme_changed)
        row_th.add_widget(lbl_th)
        row_th.add_widget(self.spin_theme)
        theme_card.add_widget(row_th)

        # Reduced motion switch row
        row_motion = BoxLayout(orientation="horizontal", size_hint_y=None, height=40, spacing=8)
        lbl_motion = Label(text=tr("settings_reduced_motion"), size_hint_x=0.65, font_size="12sp", color=(0.7, 0.75, 0.88, 1.0), halign="left")
        lbl_motion.bind(size=lbl_motion.setter("text_size"))
        self.sw_motion = Switch(size_hint_x=0.35)
        self.sw_motion.bind(active=self._on_motion_toggled)
        row_motion.add_widget(lbl_motion)
        row_motion.add_widget(self.sw_motion)
        theme_card.add_widget(row_motion)

        content.add_widget(theme_card)

        # 2. Language Selector Card
        lang_card = NeonCard(orientation="vertical", spacing=8, size_hint_y=None)
        lang_card.bind(minimum_height=lang_card.setter("height"))

        lbl_lang_head = Label(
            text="[b]Language Selection / زبان[/b]",
            markup=True,
            font_size="13sp",
            color=(0.61, 0.31, 0.87, 1.0),
            size_hint_y=None,
            height=24
        )
        lang_card.add_widget(lbl_lang_head)

        row_lang = BoxLayout(orientation="horizontal", size_hint_y=None, height=40, spacing=8)
        lbl_lang = Label(text=tr("settings_language"), size_hint_x=0.4, font_size="12sp", color=(0.7, 0.75, 0.88, 1.0))
        self.spin_lang = Spinner(
            text="English",
            values=("English", "Roman Urdu", "Urdu (اردو)"),
            size_hint_x=0.6,
            background_color=(0.14, 0.16, 0.25, 1.0),
            color=(0.0, 0.94, 1.0, 1.0)
        )
        self.spin_lang.bind(text=self._on_language_changed)
        row_lang.add_widget(lbl_lang)
        row_lang.add_widget(self.spin_lang)
        lang_card.add_widget(row_lang)

        content.add_widget(lang_card)

        # 3. Quick Navigation & Defaults Reset
        reset_card = NeonCard(orientation="vertical", spacing=8, size_hint_y=None, height=95, padding=10)
        lbl_res = Label(
            text="[b]Reset Application Preferences[/b]",
            markup=True,
            font_size="12sp",
            color=(1.0, 0.23, 0.36, 1.0),
            size_hint_y=None,
            height=20
        )
        btn_reset = NeonButton(
            text=tr("btn_reset_defaults"),
            variant="danger",
            size_hint_y=None,
            height=40,
            font_size="12sp"
        )
        btn_reset.bind(on_release=self._confirm_reset_settings)
        reset_card.add_widget(lbl_res)
        reset_card.add_widget(btn_reset)
        content.add_widget(reset_card)

        scroll.add_widget(content)
        root.add_widget(scroll)
        self.add_widget(root)

    def on_enter(self, *args):
        # Load saved settings
        red_motion = DatabaseManager.get_setting("reduced_motion", "false").lower() == "true"
        self.sw_motion.active = red_motion

        cur_lang = LocaleManager.get_language()
        if cur_lang == "ur_ro":
            self.spin_lang.text = "Roman Urdu"
        elif cur_lang == "ur_ar":
            self.spin_lang.text = "Urdu (اردو)"
        else:
            self.spin_lang.text = "English"

    def _on_theme_changed(self, instance, text):
        if "Purple" in text:
            config.ACTIVE_THEME = "neon_purple"
        elif "Gold" in text or "Amber" in text:
            config.ACTIVE_THEME = "cyber_gold"
        else:
            config.ACTIVE_THEME = "neon_cyber"
        DatabaseManager.set_setting("active_theme", config.ACTIVE_THEME)

    def _on_motion_toggled(self, instance, active):
        DatabaseManager.set_setting("reduced_motion", "true" if active else "false")

    def _on_language_changed(self, instance, text):
        if text == "Roman Urdu":
            code = "ur_ro"
        elif "Urdu" in text:
            code = "ur_ar"
        else:
            code = "en"

        LocaleManager.set_language(code)
        DatabaseManager.set_setting("app_language", code)
        NeonMessageDialog("Language", f"Language switched to {text}!").open()

    def _confirm_reset_settings(self, *args):
        def on_yes():
            DatabaseManager.set_setting("reduced_motion", "false")
            DatabaseManager.set_setting("active_theme", "neon_cyber")
            DatabaseManager.set_setting("app_language", "en")
            LocaleManager.set_language("en")
            self.sw_motion.active = False
            self.spin_lang.text = "English"
            self.spin_theme.text = "Neon Cyber (Cyan & Blue)"
            NeonMessageDialog("Reset", "Settings restored to defaults.").open()

        NeonConfirmDialog(
            title="Reset Settings?",
            message="Restore default theme, language, and motion settings?",
            on_confirm=on_yes
        ).open()
