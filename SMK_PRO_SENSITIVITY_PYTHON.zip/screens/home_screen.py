"""
Home Dashboard Screen for SMK PRO SENSITIVITY.
Features 3D Hacker live engine background, square cyber tiles, and official YouTube & WhatsApp cards.
"""
import webbrowser
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.image import Image
from kivy.uix.label import Label
from kivy.core.clipboard import Clipboard
from widgets.neon_widgets import MagicBackground, NeonButton, NeonCard, NeonSquareTile, get_asset_path
from widgets.dialogs import NeonMessageDialog, NeonInputDialog
from security.keys import KeyManager
from core.config import APP_NAME, APP_VERSION, WHATSAPP_CHANNEL_URL, YOUTUBE_CHANNEL_URL
from localization.locales import tr


class HomeScreen(Screen):
    """Main dashboard screen with 3D cyber hacker visuals and square action tiles."""

    def __init__(self, **kwargs):
        super(HomeScreen, self).__init__(**kwargs)
        self.name = "home"

        # 3D Live Hacker Engine Background (Perspective grid + Matrix digital rain)
        self.add_widget(MagicBackground())

        root = BoxLayout(orientation="vertical", padding=[10, 8, 10, 6], spacing=8)

        # 1. Top Brand Banner with Heroic Emblem
        top_card = NeonCard(orientation="horizontal", size_hint_y=None, height=68, padding=[8, 6, 10, 6], spacing=8)
        
        badge_path = get_asset_path("heroic_badge.png")
        if badge_path:
            img_badge = Image(source=badge_path, size_hint=(None, 1), width=54)
            top_card.add_widget(img_badge)

        brand_box = BoxLayout(orientation="vertical")
        lbl_app = Label(
            text=f"[b]{APP_NAME}[/b]",
            markup=True,
            font_size="16sp",
            color=(0.0, 0.94, 1.0, 1.0),
            halign="left"
        )
        lbl_app.bind(size=lbl_app.setter("text_size"))
        self.lbl_sub = Label(
            text=f"Hacker Edition Engine  •  v{APP_VERSION} (Offline)",
            font_size="11sp",
            color=(0.75, 0.8, 0.92, 1.0),
            halign="left"
        )
        self.lbl_sub.bind(size=self.lbl_sub.setter("text_size"))
        brand_box.add_widget(lbl_app)
        brand_box.add_widget(self.lbl_sub)
        top_card.add_widget(brand_box)

        # Quick Admin shortcut in top corner
        btn_admin = NeonButton(
            text="Admin 🔒",
            variant="purple",
            size_hint=(None, 1),
            width=76,
            font_size="12sp"
        )
        btn_admin.bind(on_release=lambda x: self._nav("admin_login"))
        top_card.add_widget(btn_admin)
        root.add_widget(top_card)

        # 2. Scrollable Body
        scroll = ScrollView(size_hint=(1, 1), do_scroll_x=False)
        content = BoxLayout(orientation="vertical", spacing=10, size_hint_y=None)
        content.bind(minimum_height=content.setter("height"))

        # Pro License Status Card
        self.license_card = NeonCard(orientation="vertical", size_hint_y=None, height=92, padding=8, spacing=3)
        self.lbl_license_title = Label(
            text=f"[b]👑 {tr('key_title')}[/b]",
            markup=True,
            font_size="12sp",
            color=(0.61, 0.31, 0.87, 1.0),
            size_hint_y=None,
            height=18
        )
        self.lbl_license_status = Label(
            text="Checking license status...",
            font_size="11sp",
            color=(0.9, 0.92, 0.98, 1.0),
            size_hint_y=None,
            height=20
        )
        btn_key_action = NeonButton(
            text="🔑 " + tr("btn_activate_key"),
            variant="purple",
            size_hint_y=None,
            height=34,
            font_size="11sp"
        )
        btn_key_action.bind(on_release=self._prompt_key_entry)
        self.license_card.add_widget(self.lbl_license_title)
        self.license_card.add_widget(self.lbl_license_status)
        self.license_card.add_widget(btn_key_action)
        content.add_widget(self.license_card)

        # 3. Square Options 2-Column Grid
        grid = GridLayout(cols=2, spacing=10, size_hint_y=None)
        grid.bind(minimum_height=grid.setter("height"))

        square_tiles = [
            ("icon_generator.png", "Sensitivity\nGenerator", "⚡ PRO CALC", "primary", "generator"),
            ("icon_device.png", "My Device\nDiagnostics", "📱 SPECS", "primary", "device"),
            ("icon_phonedb.png", "Offline Phone\nDatabase", "⚡ 25+ MODELS", "gold", "phone_db"),
            ("icon_profiles.png", "Saved Sensitivity\nProfiles", "💾 CUSTOM", "purple", "profiles"),
            ("icon_backup.png", "Offline Backup\n& Restore", "🛡️ DATA SAFE", "success", "backup_restore"),
            ("icon_feedback.png", "Community\nFeedback", "⭐ REVIEWS", "primary", "feedback"),
            ("icon_settings.png", "Visual Theme\n& Settings", "⚙️ CONFIG", "primary", "settings"),
            ("icon_guide.png", "1-Tap Headshot\nGuide", "📖 CALIBRATION", "purple", "help"),
            ("icon_about.png", "Fair Play\n& Legal Info", "⚖️ ZERO MEMORY", "purple", "about"),
            ("icon_admin.png", "Admin Security\nGateway", "🔒 PRIVATESMK", "danger", "admin_login"),
        ]

        for icon_file, title, badge, variant, screen_name in square_tiles:
            tile = NeonSquareTile(
                icon_name=icon_file,
                title=title,
                badge=badge,
                variant=variant,
                size_hint_y=None,
                height=115
            )
            tile.bind(on_release=lambda inst, sn=screen_name: self._nav(sn))
            grid.add_widget(tile)

        content.add_widget(grid)

        # 4. WhatsApp Channel Card (with prominent WhatsApp Logo)
        wa_card = NeonCard(orientation="horizontal", size_hint_y=None, height=72, padding=[10, 6, 10, 6], spacing=10)
        wa_logo_path = get_asset_path("whatsapp_logo.png")
        if wa_logo_path:
            img_wa = Image(source=wa_logo_path, size_hint=(None, 1), width=56)
            wa_card.add_widget(img_wa)
        
        wa_text_box = BoxLayout(orientation="vertical")
        lbl_wa_title = Label(
            text="[b]Join WhatsApp Channel[/b]",
            markup=True,
            font_size="13sp",
            color=(0.0, 0.95, 0.45, 1.0),
            halign="left"
        )
        lbl_wa_title.bind(size=lbl_wa_title.setter("text_size"))
        lbl_wa_desc = Label(
            text="Official SMK Pro Gaming Community",
            font_size="11sp",
            color=(0.8, 0.85, 0.95, 1.0),
            halign="left"
        )
        lbl_wa_desc.bind(size=lbl_wa_desc.setter("text_size"))
        wa_text_box.add_widget(lbl_wa_title)
        wa_text_box.add_widget(lbl_wa_desc)
        wa_card.add_widget(wa_text_box)

        btn_wa_open = NeonButton(text="Join >>", variant="success", size_hint=(None, 1), width=75, font_size="12sp")
        btn_wa_open.bind(on_release=lambda x: self._open_external_url(WHATSAPP_CHANNEL_URL, "WhatsApp Channel"))
        wa_card.add_widget(btn_wa_open)
        content.add_widget(wa_card)

        # 5. YouTube Channel Card (with prominent YouTube Logo)
        yt_card = NeonCard(orientation="horizontal", size_hint_y=None, height=72, padding=[10, 6, 10, 6], spacing=10)
        yt_logo_path = get_asset_path("youtube_logo.png")
        if yt_logo_path:
            img_yt = Image(source=yt_logo_path, size_hint=(None, 1), width=56)
            yt_card.add_widget(img_yt)

        yt_text_box = BoxLayout(orientation="vertical")
        lbl_yt_title = Label(
            text="[b]Watch YouTube Channel[/b]",
            markup=True,
            font_size="13sp",
            color=(1.0, 0.25, 0.35, 1.0),
            halign="left"
        )
        lbl_yt_title.bind(size=lbl_yt_title.setter("text_size"))
        lbl_yt_desc = Label(
            text="@sajidgaming225 • Free Fire Pro Gameplay",
            font_size="11sp",
            color=(0.8, 0.85, 0.95, 1.0),
            halign="left"
        )
        lbl_yt_desc.bind(size=lbl_yt_desc.setter("text_size"))
        yt_text_box.add_widget(lbl_yt_title)
        yt_text_box.add_widget(lbl_yt_desc)
        yt_card.add_widget(yt_text_box)

        btn_yt_open = NeonButton(text="Watch >>", variant="danger", size_hint=(None, 1), width=75, font_size="12sp")
        btn_yt_open.bind(on_release=lambda x: self._open_external_url(YOUTUBE_CHANNEL_URL, "YouTube Channel"))
        yt_card.add_widget(btn_yt_open)
        content.add_widget(yt_card)

        scroll.add_widget(content)
        root.add_widget(scroll)
        self.add_widget(root)

    def on_enter(self, *args):
        self._refresh_license_badge()

    def _refresh_license_badge(self):
        info = KeyManager.get_license_summary()
        if info["is_pro"]:
            self.lbl_license_status.text = f"[b]PRO ACTIVATED[/b] ({info['type']}) - Expires: {info['expires_at'][:10] if info['expires_at'] != 'Never' else 'Lifetime'}"
            self.lbl_license_status.color = (0.0, 0.9, 0.45, 1.0)
            self.lbl_license_status.markup = True
        else:
            self.lbl_license_status.text = "Standard Free Edition. Enter a Pro Key to unlock advanced calibration presets."
            self.lbl_license_status.color = (0.75, 0.8, 0.9, 1.0)
            self.lbl_license_status.markup = False

    def _prompt_key_entry(self, *args):
        def on_key_submit(key_code):
            if not key_code:
                return
            success, msg = KeyManager.activate_key(key_code)
            self._refresh_license_badge()
            NeonMessageDialog("Key Activation", msg).open()

        NeonInputDialog(
            title=tr("btn_activate_key"),
            prompt=tr("key_enter_prompt"),
            default_text="SMK-",
            on_submit=on_key_submit
        ).open()

    def _open_external_url(self, url: str, label: str):
        try:
            webbrowser.open(url)
        except Exception:
            Clipboard.copy(url)
            NeonMessageDialog(
                title=label,
                message=f"Could not launch browser automatically.\nLink copied to clipboard:\n{url}"
            ).open()

    def _nav(self, screen_name: str):
        if self.manager:
            self.manager.current = screen_name
