"""
Password-Protected Admin Authentication Screen for SMK PRO SENSITIVITY.
Enforces PBKDF2 verification, attempt rate limiting, lockout duration, and secure first-run setup.
"""
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.textinput import TextInput
from kivy.uix.label import Label
from widgets.neon_widgets import MagicBackground, NeonButton, NeonCard
from widgets.dialogs import NeonMessageDialog
from screens.nav_header import ScreenHeader
from security.auth import AdminAuthService
from core.config import INITIAL_OWNER_USERNAME
from localization.locales import tr


class AdminLoginScreen(Screen):
    """Admin login and initial password setup view."""

    def __init__(self, **kwargs):
        super(AdminLoginScreen, self).__init__(**kwargs)
        self.name = "admin_login"

        self.add_widget(MagicBackground())

        root = BoxLayout(orientation="vertical", padding=[12, 8, 12, 8], spacing=10)
        root.add_widget(ScreenHeader("admin_auth_title", show_back=True, back_target="home"))

        # Center card container
        root.add_widget(BoxLayout(size_hint_y=0.08))

        self.card = NeonCard(orientation="vertical", spacing=10, padding=16, size_hint_y=None)
        self.card.bind(minimum_height=self.card.setter("height"))

        self.lbl_mode_title = Label(
            text="[b]Admin Security Gateway[/b]",
            markup=True,
            font_size="15sp",
            color=(0.0, 0.94, 1.0, 1.0),
            size_hint_y=None,
            height=26
        )
        self.lbl_mode_desc = Label(
            text="Enter master owner credentials to access activation keys and database tools.",
            font_size="11sp",
            color=(0.7, 0.75, 0.88, 1.0),
            size_hint_y=None,
            height=30,
            halign="center"
        )
        self.lbl_mode_desc.bind(size=self.lbl_mode_desc.setter("text_size"))

        self.card.add_widget(self.lbl_mode_title)
        self.card.add_widget(self.lbl_mode_desc)

        # Username Input
        self.txt_username = TextInput(
            text=INITIAL_OWNER_USERNAME,
            multiline=False,
            font_size="14sp",
            size_hint_y=None,
            height=40,
            background_color=(0.14, 0.16, 0.25, 1.0),
            foreground_color=(0.95, 0.96, 1.0, 1.0),
            cursor_color=(0.0, 0.94, 1.0, 1.0)
        )
        self.card.add_widget(self.txt_username)

        # Password Input
        self.txt_password = TextInput(
            hint_text="Enter Admin Password",
            multiline=False,
            password=True,
            font_size="14sp",
            size_hint_y=None,
            height=40,
            background_color=(0.14, 0.16, 0.25, 1.0),
            foreground_color=(0.95, 0.96, 1.0, 1.0),
            cursor_color=(0.0, 0.94, 1.0, 1.0)
        )
        self.card.add_widget(self.txt_password)

        # Confirm Password Input (Only visible in First-Run Setup Mode)
        self.txt_confirm_pwd = TextInput(
            hint_text="Confirm Admin Password",
            multiline=False,
            password=True,
            font_size="14sp",
            size_hint_y=None,
            height=40,
            background_color=(0.14, 0.16, 0.25, 1.0),
            foreground_color=(0.95, 0.96, 1.0, 1.0),
            cursor_color=(0.0, 0.94, 1.0, 1.0)
        )
        self.card.add_widget(self.txt_confirm_pwd)

        # Action Button
        self.btn_action = NeonButton(
            text="AUTHORIZE & ENTER",
            variant="primary",
            size_hint_y=None,
            height=46,
            font_size="13sp"
        )
        self.btn_action.bind(on_release=self._handle_action)
        self.card.add_widget(self.btn_action)

        root.add_widget(self.card)
        root.add_widget(BoxLayout(size_hint_y=0.15))

        self.add_widget(root)
        self.is_setup_mode = False

    def on_enter(self, *args):
        self.txt_password.text = ""
        self.txt_confirm_pwd.text = ""
        self._check_setup_state()

    def _check_setup_state(self):
        self.is_setup_mode = AdminAuthService.is_first_run()
        if self.is_setup_mode:
            self.lbl_mode_title.text = f"[b]{tr('admin_first_run_title')}[/b]"
            self.lbl_mode_desc.text = tr("admin_first_run_desc")
            self.txt_confirm_pwd.opacity = 1.0
            self.txt_confirm_pwd.disabled = False
            self.btn_action.text = tr("admin_btn_set_password")
            self.btn_action.variant = "success"
        else:
            self.lbl_mode_title.text = f"[b]{tr('admin_auth_title')}[/b]"
            self.lbl_mode_desc.text = "Authorized owner login for privatesmk225."
            self.txt_confirm_pwd.opacity = 0.0
            self.txt_confirm_pwd.disabled = True
            self.btn_action.text = tr("btn_login")
            self.btn_action.variant = "primary"

    def _handle_action(self, *args):
        username = self.txt_username.text.strip()
        password = self.txt_password.text.strip()

        if not password:
            NeonMessageDialog("Validation", "Password cannot be empty.").open()
            return

        if self.is_setup_mode:
            confirm = self.txt_confirm_pwd.text.strip()
            if password != confirm:
                NeonMessageDialog("Password Mismatch", "Password and Confirmation do not match.").open()
                return

            ok, msg = AdminAuthService.setup_initial_owner_password(password)
            if ok:
                # Log in directly
                AdminAuthService.authenticate(username, password)
                NeonMessageDialog("Setup Complete", "Admin password configured securely! Redirecting to panel...", on_ok=self._go_panel).open()
            else:
                NeonMessageDialog("Setup Error", msg).open()
        else:
            success, msg = AdminAuthService.authenticate(username, password)
            if success:
                self.txt_password.text = ""
                self._go_panel()
            else:
                NeonMessageDialog("Access Denied", msg).open()

    def _go_panel(self):
        if self.manager:
            self.manager.current = "admin_panel"
