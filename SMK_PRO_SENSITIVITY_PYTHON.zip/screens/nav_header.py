"""
Reusable Futuristic Top Header & Navigation Bar for SMK PRO SENSITIVITY screens.
"""
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.app import App
from widgets.neon_widgets import NeonButton
from localization.locales import tr


class ScreenHeader(BoxLayout):
    """Consistent glowing navigation header for all app screens."""

    def __init__(self, title_key: str, screen_manager=None, show_back: bool = True, back_target: str = "home", **kwargs):
        kwargs.setdefault("orientation", "horizontal")
        kwargs.setdefault("size_hint_y", None)
        kwargs.setdefault("height", 52)
        kwargs.setdefault("padding", [8, 4, 8, 4])
        kwargs.setdefault("spacing", 8)
        super(ScreenHeader, self).__init__(**kwargs)

        self.screen_manager = screen_manager
        self.back_target = back_target

        if show_back:
            btn_back = NeonButton(
                text="< Back",
                variant="purple",
                size_hint=(None, 1),
                width=76,
                font_size="13sp"
            )
            btn_back.bind(on_release=self._go_back)
            self.add_widget(btn_back)

        self.lbl_title = Label(
            text=f"[b]{tr(title_key)}[/b]",
            markup=True,
            font_size="16sp",
            color=(0.0, 0.94, 1.0, 1.0),
            halign="left",
            valign="middle"
        )
        self.lbl_title.bind(size=self.lbl_title.setter("text_size"))
        self.add_widget(self.lbl_title)

        # Quick Home shortcut button
        if back_target != "home" or not show_back:
            btn_home = NeonButton(
                text="Home",
                variant="primary",
                size_hint=(None, 1),
                width=65,
                font_size="12sp"
            )
            btn_home.bind(on_release=lambda x: self._navigate_to("home"))
            self.add_widget(btn_home)

    def _get_active_sm(self):
        """Dynamically finds the ScreenManager even if not passed at init."""
        if self.screen_manager:
            return self.screen_manager
        
        # Check current screen's manager
        parent = self.parent
        while parent:
            if hasattr(parent, "manager") and parent.manager:
                self.screen_manager = parent.manager
                return self.screen_manager
            parent = parent.parent

        # Fallback to App singleton
        app = App.get_running_app()
        if app and hasattr(app, "sm") and app.sm:
            self.screen_manager = app.sm
            return self.screen_manager
        return None

    def _go_back(self, *args):
        sm = self._get_active_sm()
        if sm:
            sm.current = self.back_target

    def _navigate_to(self, screen_name: str):
        sm = self._get_active_sm()
        if sm:
            sm.current = screen_name
