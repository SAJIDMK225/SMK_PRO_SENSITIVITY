"""
Community Feedback Screen for SMK PRO SENSITIVITY.
Stores local player reviews and generates formatted text for manual sharing.
"""
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.spinner import Spinner
from kivy.uix.textinput import TextInput
from kivy.uix.label import Label
from kivy.core.clipboard import Clipboard
from widgets.neon_widgets import MagicBackground, NeonButton, NeonCard
from widgets.dialogs import NeonMessageDialog
from screens.nav_header import ScreenHeader
from database.db import DatabaseManager
from localization.locales import tr


class FeedbackScreen(Screen):
    """Local user rating and feedback collection screen."""

    def __init__(self, **kwargs):
        super(FeedbackScreen, self).__init__(**kwargs)
        self.name = "feedback"

        self.add_widget(MagicBackground())

        root = BoxLayout(orientation="vertical", padding=[10, 8, 10, 8], spacing=8)
        root.add_widget(ScreenHeader("nav_feedback", show_back=True, back_target="home"))

        scroll = ScrollView(size_hint=(1, 1), do_scroll_x=False)
        content = BoxLayout(orientation="vertical", spacing=10, size_hint_y=None)
        content.bind(minimum_height=content.setter("height"))

        # Feedback Submission Card
        card = NeonCard(orientation="vertical", spacing=8, size_hint_y=None)
        card.bind(minimum_height=card.setter("height"))

        lbl_head = Label(
            text="[b]Share Sensitivity Review & Device Experience[/b]",
            markup=True,
            font_size="13sp",
            color=(0.0, 0.94, 1.0, 1.0),
            size_hint_y=None,
            height=24
        )
        card.add_widget(lbl_head)

        # Rating selection row
        row_rate = BoxLayout(orientation="horizontal", size_hint_y=None, height=40, spacing=8)
        lbl_r = Label(text="Rating:", size_hint_x=0.35, font_size="12sp", color=(0.7, 0.75, 0.88, 1.0))
        self.spin_rating = Spinner(
            text="5 Stars (⭐⭐⭐⭐⭐)",
            values=(
                "5 Stars (⭐⭐⭐⭐⭐)",
                "4 Stars (⭐⭐⭐⭐)",
                "3 Stars (⭐⭐⭐)",
                "2 Stars (⭐⭐)",
                "1 Star (⭐)"
            ),
            size_hint_x=0.65,
            background_color=(0.14, 0.16, 0.25, 1.0),
            color=(0.0, 0.94, 1.0, 1.0)
        )
        row_rate.add_widget(lbl_r)
        row_rate.add_widget(self.spin_rating)
        card.add_widget(row_rate)

        # Category selection row
        row_cat = BoxLayout(orientation="horizontal", size_hint_y=None, height=40, spacing=8)
        lbl_c = Label(text="Category:", size_hint_x=0.35, font_size="12sp", color=(0.7, 0.75, 0.88, 1.0))
        self.spin_category = Spinner(
            text="Headshot Drag Precision",
            values=(
                "Headshot Drag Precision",
                "Phone DB Preset Quality",
                "Gyroscope Calibration",
                "120Hz/90Hz Performance",
                "Suggestion or Request"
            ),
            size_hint_x=0.65,
            background_color=(0.14, 0.16, 0.25, 1.0),
            color=(0.0, 0.94, 1.0, 1.0)
        )
        row_cat.add_widget(lbl_c)
        row_cat.add_widget(self.spin_category)
        card.add_widget(row_cat)

        # Comment Input
        lbl_com = Label(
            text="Your notes, phone model, or calibration tips:",
            font_size="11sp",
            color=(0.7, 0.75, 0.88, 1.0),
            size_hint_y=None,
            height=20,
            halign="left"
        )
        lbl_com.bind(size=lbl_com.setter("text_size"))
        card.add_widget(lbl_com)

        self.txt_comment = TextInput(
            hint_text="e.g. Poco X3 Pro with 120Hz works best at General 182 and Red Dot 174...",
            multiline=True,
            font_size="12sp",
            size_hint_y=None,
            height=85,
            background_color=(0.14, 0.16, 0.25, 1.0),
            foreground_color=(0.95, 0.96, 1.0, 1.0),
            cursor_color=(0.0, 0.94, 1.0, 1.0)
        )
        card.add_widget(self.txt_comment)

        # Buttons Row (Save Offline, Copy/Share Text)
        btn_box = BoxLayout(orientation="horizontal", spacing=8, size_hint_y=None, height=44)
        btn_save = NeonButton(text=tr("btn_submit_feedback"), variant="primary", font_size="11sp")
        btn_share = NeonButton(text=tr("btn_share_feedback"), variant="purple", font_size="11sp")

        btn_save.bind(on_release=self._save_feedback)
        btn_share.bind(on_release=self._copy_feedback_text)

        btn_box.add_widget(btn_save)
        btn_box.add_widget(btn_share)
        card.add_widget(btn_box)

        content.add_widget(card)

        # Offline Privacy Guarantee Card
        sec_card = NeonCard(orientation="vertical", spacing=4, size_hint_y=None, height=90, padding=10)
        lbl_sec_title = Label(
            text="[b]Zero-Tracking Offline Guarantee[/b]",
            markup=True,
            font_size="12sp",
            color=(0.0, 0.9, 0.45, 1.0),
            size_hint_y=None,
            height=20
        )
        lbl_sec_body = Label(
            text=(
                "SMK PRO SENSITIVITY never uploads personal logs or telemetry in the background. "
                "Your feedback is saved locally on your device storage. If you choose to share tips with the "
                "SMK gaming community, use the 'Share Feedback Text' button to copy and paste to WhatsApp."
            ),
            font_size="10sp",
            color=(0.65, 0.7, 0.8, 1.0),
            halign="left"
        )
        lbl_sec_body.bind(size=lbl_sec_body.setter("text_size"))
        sec_card.add_widget(lbl_sec_title)
        sec_card.add_widget(lbl_sec_body)
        content.add_widget(sec_card)

        scroll.add_widget(content)
        root.add_widget(scroll)
        self.add_widget(root)

    def _save_feedback(self, *args):
        comment = self.txt_comment.text.strip()
        if not comment:
            NeonMessageDialog("Validation", "Please enter a comment or tips before saving.").open()
            return

        star_str = self.spin_rating.text
        rating = 5 if "5" in star_str else 4 if "4" in star_str else 3 if "3" in star_str else 2 if "2" in star_str else 1
        cat = self.spin_category.text

        DatabaseManager.add_feedback(rating=rating, category=cat, comment=comment)
        NeonMessageDialog("Saved", tr("feedback_saved")).open()
        self.txt_comment.text = ""

    def _copy_feedback_text(self, *args):
        comment = self.txt_comment.text.strip() or "Loving SMK PRO Sensitivity settings!"
        star_str = self.spin_rating.text
        cat = self.spin_category.text

        share_msg = (
            f"🎮 *SMK PRO SENSITIVITY USER FEEDBACK*\n"
            f"⭐ Rating: {star_str}\n"
            f"🏷️ Category: {cat}\n"
            f"💬 Review: {comment}\n\n"
            f"Join Official Channel: https://whatsapp.com/channel/0029VangZH52UPBHGbkqXH3u"
        )
        Clipboard.copy(share_msg)
        NeonMessageDialog("Clipboard", "Formatted feedback copied to clipboard!\nYou can now paste it directly into WhatsApp.").open()
