"""
Animated Splash Screen for SMK PRO SENSITIVITY.
Features glowing energy pulse, SMK logo emblem, and seamless transition to Dashboard.
"""
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.image import Image
from kivy.uix.label import Label
from kivy.clock import Clock
from kivy.animation import Animation
from widgets.neon_widgets import MagicBackground, NeonButton, NeonCard, get_asset_path
from core.config import APP_NAME, APP_SUBTITLE, APP_VERSION
from localization.locales import tr


class SplashScreen(Screen):
    """Initial splash & welcome screen."""

    def __init__(self, **kwargs):
        super(SplashScreen, self).__init__(**kwargs)
        self.name = "splash"

        # Magical animated gaming background
        self.add_widget(MagicBackground())

        # Main Layout
        layout = BoxLayout(orientation="vertical", padding=[20, 16, 20, 16], spacing=12)

        # Spacer top
        layout.add_widget(BoxLayout(size_hint_y=0.06))

        # Central Hero Card
        card = NeonCard(orientation="vertical", spacing=8, padding=16, size_hint_y=0.88)

        # Logo Image Emblem
        logo_path = get_asset_path("logo_smk_glow.png")
        if logo_path:
            self.img_logo = Image(
                source=logo_path,
                size_hint=(None, None),
                size=(150, 150),
                pos_hint={"center_x": 0.5}
            )
            card.add_widget(self.img_logo)

        self.lbl_tag = Label(
            text="⚡ ULTIMATE GAMING CALIBRATION ⚡",
            font_size="11sp",
            bold=True,
            color=(0.61, 0.31, 0.87, 1.0),
            size_hint_y=None,
            height=20
        )

        self.lbl_title = Label(
            text=f"[b]{APP_NAME}[/b]",
            markup=True,
            font_size="22sp",
            color=(0.0, 0.94, 1.0, 1.0),
            size_hint_y=None,
            height=40
        )

        self.lbl_subtitle = Label(
            text=APP_SUBTITLE,
            font_size="12sp",
            color=(0.75, 0.80, 0.92, 1.0),
            size_hint_y=None,
            height=22
        )

        self.lbl_ver = Label(
            text=f"Version {APP_VERSION}  •  100% Offline & Free",
            font_size="11sp",
            bold=True,
            color=(0.0, 0.9, 0.45, 1.0),
            size_hint_y=None,
            height=20
        )

        self.lbl_disclaimer = Label(
            text=tr("disclaimer_banner"),
            font_size="10sp",
            color=(0.60, 0.65, 0.78, 1.0),
            halign="center",
            valign="middle"
        )
        self.lbl_disclaimer.bind(size=self.lbl_disclaimer.setter("text_size"))

        btn_enter = NeonButton(
            text="⚡ ENTER DASHBOARD >>",
            variant="primary",
            size_hint_y=None,
            height=48,
            font_size="14sp"
        )
        btn_enter.bind(on_release=self._proceed_to_home)

        card.add_widget(self.lbl_tag)
        card.add_widget(self.lbl_title)
        card.add_widget(self.lbl_subtitle)
        card.add_widget(self.lbl_ver)
        card.add_widget(self.lbl_disclaimer)
        card.add_widget(btn_enter)

        layout.add_widget(card)

        # Spacer bottom
        layout.add_widget(BoxLayout(size_hint_y=0.06))

        self.add_widget(layout)

    def on_enter(self, *args):
        # Pulsing animation on logo
        if hasattr(self, "img_logo") and self.img_logo:
            anim = Animation(size=(160, 160), duration=1.2, t="in_out_sine") + Animation(size=(145, 145), duration=1.2, t="in_out_sine")
            anim.repeat = True
            anim.start(self.img_logo)

        # Auto proceed after 3.2 seconds
        self._timer = Clock.schedule_once(self._proceed_to_home, 3.2)

    def _proceed_to_home(self, *args):
        if hasattr(self, "_timer") and self._timer:
            self._timer.cancel()
        if self.manager:
            self.manager.current = "home"
