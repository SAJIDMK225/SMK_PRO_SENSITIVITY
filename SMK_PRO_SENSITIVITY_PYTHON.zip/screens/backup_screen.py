"""
Offline Backup, Restore & Data Recovery Screen for SMK PRO SENSITIVITY.
Coordinates cryptographic JSON export, integrity validation, and disaster recovery.
"""
import os
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from widgets.neon_widgets import MagicBackground, NeonButton, NeonCard
from widgets.dialogs import NeonMessageDialog, NeonConfirmDialog, NeonInputDialog
from screens.nav_header import ScreenHeader
from services.backup_service import BackupService
from database.db import DatabaseManager
from localization.locales import tr


class BackupScreen(Screen):
    """Offline data persistence, export, and restoration."""

    def __init__(self, **kwargs):
        super(BackupScreen, self).__init__(**kwargs)
        self.name = "backup_restore"

        self.add_widget(MagicBackground())

        root = BoxLayout(orientation="vertical", padding=[10, 8, 10, 8], spacing=8)
        root.add_widget(ScreenHeader("nav_backup", show_back=True, back_target="home"))

        scroll = ScrollView(size_hint=(1, 1), do_scroll_x=False)
        content = BoxLayout(orientation="vertical", spacing=10, size_hint_y=None)
        content.bind(minimum_height=content.setter("height"))

        # 1. Export Backup Card
        export_card = NeonCard(orientation="vertical", spacing=8, size_hint_y=None, height=140, padding=10)
        lbl_ex_title = Label(
            text="[b]Export Local Data Backup[/b]",
            markup=True,
            font_size="13sp",
            color=(0.0, 0.94, 1.0, 1.0),
            size_hint_y=None,
            height=20
        )
        lbl_ex_desc = Label(
            text=tr("backup_export_info"),
            font_size="11sp",
            color=(0.7, 0.75, 0.88, 1.0),
            size_hint_y=None,
            height=34,
            halign="left"
        )
        lbl_ex_desc.bind(size=lbl_ex_desc.setter("text_size"))
        btn_export = NeonButton(
            text=tr("btn_export_backup"),
            variant="primary",
            size_hint_y=None,
            height=42,
            font_size="12sp"
        )
        btn_export.bind(on_release=self._export_backup)
        export_card.add_widget(lbl_ex_title)
        export_card.add_widget(lbl_ex_desc)
        export_card.add_widget(btn_export)
        content.add_widget(export_card)

        # 2. Restore Backup Card
        restore_card = NeonCard(orientation="vertical", spacing=8, size_hint_y=None, height=180, padding=10)
        lbl_res_title = Label(
            text="[b]Restore Backup Archive[/b]",
            markup=True,
            font_size="13sp",
            color=(0.61, 0.31, 0.87, 1.0),
            size_hint_y=None,
            height=20
        )
        lbl_res_desc = Label(
            text=tr("backup_restore_info"),
            font_size="11sp",
            color=(0.7, 0.75, 0.88, 1.0),
            size_hint_y=None,
            height=28,
            halign="left"
        )
        lbl_res_desc.bind(size=lbl_res_desc.setter("text_size"))

        self.txt_restore_path = TextInput(
            hint_text="Enter full path to backup JSON file...",
            multiline=False,
            font_size="12sp",
            size_hint_y=None,
            height=38,
            background_color=(0.14, 0.16, 0.25, 1.0),
            foreground_color=(0.95, 0.96, 1.0, 1.0),
            cursor_color=(0.0, 0.94, 1.0, 1.0)
        )

        btn_restore = NeonButton(
            text=tr("btn_restore_backup"),
            variant="purple",
            size_hint_y=None,
            height=40,
            font_size="12sp"
        )
        btn_restore.bind(on_release=self._restore_backup)

        restore_card.add_widget(lbl_res_title)
        restore_card.add_widget(lbl_res_desc)
        restore_card.add_widget(self.txt_restore_path)
        restore_card.add_widget(btn_restore)
        content.add_widget(restore_card)

        # 3. Security & Limitation Warning
        warn_card = NeonCard(orientation="vertical", spacing=4, size_hint_y=None, height=120, padding=10)
        lbl_w_title = Label(
            text="[b]Storage Limitation Notice[/b]",
            markup=True,
            font_size="12sp",
            color=(1.0, 0.23, 0.36, 1.0),
            size_hint_y=None,
            height=20
        )
        lbl_w_body = Label(
            text=(
                "IMPORTANT: All backups are stored strictly offline on your phone or computer. "
                "There is NO remote cloud sync. If your phone is lost, wiped, or factory reset, "
                "a backup kept solely on this internal storage will be erased. "
                "We recommend copying your exported backup JSON to an SD card or safe computer."
            ),
            font_size="10sp",
            color=(0.7, 0.75, 0.88, 1.0),
            halign="left"
        )
        lbl_w_body.bind(size=lbl_w_body.setter("text_size"))
        warn_card.add_widget(lbl_w_title)
        warn_card.add_widget(lbl_w_body)
        content.add_widget(warn_card)

        scroll.add_widget(content)
        root.add_widget(scroll)
        self.add_widget(root)

    def _export_backup(self, *args):
        ok, res = BackupService.export_to_file()
        if ok:
            self.txt_restore_path.text = res
            NeonMessageDialog("Backup Exported", f"Backup archive created successfully!\nPath:\n{res}").open()
        else:
            NeonMessageDialog("Export Failed", res).open()

    def _restore_backup(self, *args):
        path = self.txt_restore_path.text.strip()
        if not path:
            NeonMessageDialog("Path Required", "Please enter the backup JSON file path.").open()
            return

        def on_confirm_restore():
            ok, msg = BackupService.restore_from_file(path)
            NeonMessageDialog("Restore Complete" if ok else "Restore Failed", msg).open()

        NeonConfirmDialog(
            title="Restore Data?",
            message="Restoring will import profiles and phones from the backup. Existing matching profiles will be updated. Proceed?",
            on_confirm=on_confirm_restore
        ).open()
