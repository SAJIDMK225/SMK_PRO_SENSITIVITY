"""
SQLite Database manager for SMK PRO SENSITIVITY.
Handles profiles, activation keys, phone database, admin authentication, and feedback.
"""
import sqlite3
import os
import json
from datetime import datetime
from typing import List, Dict, Any, Optional
from core.config import get_db_path
from database.seeds import INITIAL_DEVICES


class DatabaseManager:
    """Singleton/Class-level SQLite Database Handler."""
    
    _db_path: Optional[str] = None

    @classmethod
    def set_db_path(cls, path: str):
        cls._db_path = path

    @classmethod
    def get_path(cls) -> str:
        if cls._db_path:
            return cls._db_path
        return get_db_path()

    @classmethod
    def get_connection(cls) -> sqlite3.Connection:
        db_path = cls.get_path()
        os.makedirs(os.path.dirname(os.path.abspath(db_path)), exist_ok=True)
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        return conn

    @classmethod
    def init_database(cls):
        """Creates tables and seeds default verified phone records."""
        with cls.get_connection() as conn:
            cursor = conn.cursor()
            
            # 1. Admin Authentication Table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS admin_auth (
                    id INTEGER PRIMARY KEY,
                    username TEXT UNIQUE NOT NULL,
                    password_hash TEXT NOT NULL,
                    salt TEXT NOT NULL,
                    failed_attempts INTEGER DEFAULT 0,
                    lockout_until REAL DEFAULT 0.0,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
            """)
            
            # 2. Activation Keys Table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS activation_keys (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    key_code TEXT UNIQUE NOT NULL,
                    key_type TEXT NOT NULL, -- 'lifetime' or 'limited'
                    duration_days INTEGER DEFAULT 0,
                    status TEXT NOT NULL,   -- 'unused', 'active', 'expired', 'revoked'
                    created_at TEXT NOT NULL,
                    activated_at TEXT,
                    expires_at TEXT,
                    note TEXT
                )
            """)
            
            # 3. Sensitivity Profiles Table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS profiles (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT UNIQUE NOT NULL,
                    general INTEGER NOT NULL,
                    red_dot INTEGER NOT NULL,
                    scope_2x INTEGER NOT NULL,
                    scope_4x INTEGER NOT NULL,
                    sniper INTEGER NOT NULL,
                    free_look INTEGER NOT NULL,
                    aim_style TEXT NOT NULL,
                    device_model TEXT,
                    refresh_rate INTEGER DEFAULT 60,
                    hud_fingers INTEGER DEFAULT 2,
                    notes TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
            """)
            
            # 4. Phone Devices Database Table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS phone_devices (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    brand TEXT NOT NULL,
                    model TEXT NOT NULL,
                    ram_gb INTEGER,
                    storage_gb INTEGER,
                    refresh_rate INTEGER DEFAULT 60,
                    chipset TEXT,
                    fps_support INTEGER DEFAULT 60,
                    verification_status TEXT DEFAULT 'verified',
                    recommended_general INTEGER DEFAULT 180,
                    recommended_red_dot INTEGER DEFAULT 170,
                    notes TEXT,
                    UNIQUE(brand, model)
                )
            """)
            
            # 5. User Feedback Table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS user_feedback (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    rating INTEGER NOT NULL,
                    category TEXT NOT NULL,
                    comment TEXT NOT NULL,
                    helpful INTEGER DEFAULT 1,
                    created_at TEXT NOT NULL
                )
            """)
            
            # 6. App Settings Table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS app_settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                )
            """)
            
            conn.commit()

        # Seed devices if empty
        cls.seed_initial_devices()

    @classmethod
    def seed_initial_devices(cls):
        """Populate initial verified devices safely without overwriting user changes."""
        with cls.get_connection() as conn:
            cursor = conn.cursor()
            for dev in INITIAL_DEVICES:
                cursor.execute("""
                    INSERT OR IGNORE INTO phone_devices 
                    (brand, model, ram_gb, storage_gb, refresh_rate, chipset, fps_support, 
                     verification_status, recommended_general, recommended_red_dot, notes)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    dev["brand"], dev["model"], dev["ram_gb"], dev["storage_gb"],
                    dev["refresh_rate"], dev["chipset"], dev["fps_support"],
                    dev["verification_status"], dev["recommended_general"],
                    dev["recommended_red_dot"], dev["notes"]
                ))
            conn.commit()

    # --- Profile Operations ---
    @classmethod
    def save_profile(cls, name: str, general: int, red_dot: int, scope_2x: int, 
                     scope_4x: int, sniper: int, free_look: int, aim_style: str, 
                     device_model: str = "", refresh_rate: int = 60, hud_fingers: int = 2,
                     notes: str = "") -> bool:
        now = datetime.now().isoformat()
        with cls.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO profiles 
                (name, general, red_dot, scope_2x, scope_4x, sniper, free_look, 
                 aim_style, device_model, refresh_rate, hud_fingers, notes, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(name) DO UPDATE SET
                    general = excluded.general,
                    red_dot = excluded.red_dot,
                    scope_2x = excluded.scope_2x,
                    scope_4x = excluded.scope_4x,
                    sniper = excluded.sniper,
                    free_look = excluded.free_look,
                    aim_style = excluded.aim_style,
                    device_model = excluded.device_model,
                    refresh_rate = excluded.refresh_rate,
                    hud_fingers = excluded.hud_fingers,
                    notes = excluded.notes,
                    updated_at = excluded.updated_at
            """, (name, general, red_dot, scope_2x, scope_4x, sniper, free_look,
                  aim_style, device_model, refresh_rate, hud_fingers, notes, now, now))
            conn.commit()
            return True

    @classmethod
    def get_all_profiles(cls) -> List[Dict[str, Any]]:
        with cls.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM profiles ORDER BY updated_at DESC")
            return [dict(row) for row in cursor.fetchall()]

    @classmethod
    def get_profile_by_name(cls, name: str) -> Optional[Dict[str, Any]]:
        with cls.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM profiles WHERE name = ?", (name,))
            row = cursor.fetchone()
            return dict(row) if row else None

    @classmethod
    def delete_profile(cls, profile_id: int) -> bool:
        with cls.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM profiles WHERE id = ?", (profile_id,))
            conn.commit()
            return cursor.rowcount > 0

    @classmethod
    def rename_profile(cls, profile_id: int, new_name: str) -> bool:
        now = datetime.now().isoformat()
        with cls.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE profiles SET name = ?, updated_at = ? WHERE id = ?", (new_name, now, profile_id))
            conn.commit()
            return cursor.rowcount > 0

    # --- Phone Devices Operations ---
    @classmethod
    def search_phones(cls, query: str = "", brand_filter: str = "") -> List[Dict[str, Any]]:
        with cls.get_connection() as conn:
            cursor = conn.cursor()
            sql = "SELECT * FROM phone_devices WHERE 1=1"
            params = []
            if query.strip():
                sql += " AND (model LIKE ? OR brand LIKE ? OR chipset LIKE ?)"
                q = f"%{query.strip()}%"
                params.extend([q, q, q])
            if brand_filter.strip() and brand_filter != "All":
                sql += " AND brand = ?"
                params.append(brand_filter.strip())
            sql += " ORDER BY brand ASC, model ASC"
            cursor.execute(sql, params)
            return [dict(row) for row in cursor.fetchall()]

    @classmethod
    def get_phone_brands(cls) -> List[str]:
        with cls.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT DISTINCT brand FROM phone_devices ORDER BY brand ASC")
            return [row["brand"] for row in cursor.fetchall()]

    @classmethod
    def add_custom_phone(cls, brand: str, model: str, ram_gb: int, storage_gb: int,
                          refresh_rate: int, chipset: str, fps_support: int,
                          recommended_general: int, recommended_red_dot: int,
                          notes: str = "") -> bool:
        with cls.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO phone_devices 
                (brand, model, ram_gb, storage_gb, refresh_rate, chipset, fps_support,
                 verification_status, recommended_general, recommended_red_dot, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, 'user_confirmed', ?, ?, ?)
            """, (brand.strip(), model.strip(), ram_gb, storage_gb, refresh_rate,
                  chipset.strip(), fps_support, recommended_general, recommended_red_dot, notes.strip()))
            conn.commit()
            return True

    # --- Feedback Operations ---
    @classmethod
    def add_feedback(cls, rating: int, category: str, comment: str, helpful: int = 1) -> bool:
        now = datetime.now().isoformat()
        with cls.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO user_feedback (rating, category, comment, helpful, created_at)
                VALUES (?, ?, ?, ?, ?)
            """, (rating, category, comment, helpful, now))
            conn.commit()
            return True

    @classmethod
    def get_all_feedback(cls) -> List[Dict[str, Any]]:
        with cls.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM user_feedback ORDER BY created_at DESC")
            return [dict(row) for row in cursor.fetchall()]

    # --- Settings Operations ---
    @classmethod
    def set_setting(cls, key: str, value: str):
        with cls.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO app_settings (key, value) VALUES (?, ?)
                ON CONFLICT(key) DO UPDATE SET value = excluded.value
            """, (key, str(value)))
            conn.commit()

    @classmethod
    def get_setting(cls, key: str, default: Optional[str] = None) -> Optional[str]:
        with cls.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT value FROM app_settings WHERE key = ?", (key,))
            row = cursor.fetchone()
            return row["value"] if row else default
