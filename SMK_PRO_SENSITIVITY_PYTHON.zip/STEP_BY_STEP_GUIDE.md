# SMK PRO SENSITIVITY — Aasan Roman Urdu Step-by-Step Guide

Yeh guide beginners (naye developers aur gaming enthusiasts) k liye likhi gayi hai taake aap baghair kisi mushkil k SMK PRO SENSITIVITY project ko chala sakein, test kar sakein, aur Android APK build kar sakein.

---

## 1. Project Me Kon Konsi Files Hain?

Aap k workspace me yeh mukammal structure create ho chuka hai:

- `main.py`: Main application file jo sabhi 13 screens ko Kivy ScreenManager me load karti hai.
- `requirements.txt`: Python dependencies (Kivy, pytest, sdl2, etc.).
- `buildozer.spec`: Android APK build karne ki complete configuration file.
- `core/config.py`: Themes, colors, app constants aur database paths.
- `database/db.py`: SQLite database engine jo profiles, keys, feedback aur phone data sambhalta hai.
- `database/seeds.py`: 25+ famous gaming phones (Poco, Infinix, Tecno, Samsung, iPhone) ka verified data.
- `security/auth.py`: PBKDF2 salted password security, 5 attempts k baad 5 minute lockout, aur session timeout.
- `security/keys.py`: Offline Pro key generator (`SMK-XXXXXXXX-XXXX`), checksum validator, aur license expiry tracker.
- `services/sensitivity_engine.py`: Free Fire k 6 sensitivity channels (0–200) calculate karne wala engine.
- `services/device_service.py`: Phone hardware specs (RAM, Hz, Chipset) safe tareeqay se check karne ka service.
- `services/profile_service.py`: Custom sensitivity profiles save, duplicate, compare aur delete karne ka system.
- `services/backup_service.py`: SHA256 checksum k sath offline JSON backup export aur restore karne ka tool.
- `localization/locales.py`: English, Roman Urdu, aur Urdu Script k translations.
- `widgets/neon_widgets.py`: Glowing Neon buttons, press ripples, magic sparks, aur animated background lines.
- `widgets/dialogs.py`: Confirmation popups, error alerts, aur input boxes.
- `screens/`: Tamam 13 working screens (Splash, Home, Generator, Device, Phone DB, Profiles, Admin Login, Admin Panel, Feedback, Settings, Backup, Help, About).
- `tests/`: 22 automated unit aur GUI tests.

---

## 2. Zaroori Software (Requirements)

1. **Python 3.11** (Windows par installed hona chahiye).
2. **Kivy 2.3.1** (Python GUI framework).
3. **WSL (Windows Subsystem for Linux)** ya Ubuntu (Sirf tab chahiye jab aapko Android APK build karni ho). Desktop par test karne k liye WSL zaroori nahi hai.

---

## 3. Project Ko Antigravity Me Kese Kholein?

1. Antigravity IDE open karein.
2. File menu me ja kar **Open Folder** par click karein.
3. Folder select karein:
   `D:\SMK_PRO_SENSITIVITY_PYTHON`
4. IDE k andar built-in terminal kholne k liye `Ctrl + ~` dabayein.

---

## 4. Dependencies Install Aur Tests Run Karne Ka Tareeqa

Terminal me neechay diye gaye commands ek ek kar k chalayein:

### Step 4.1: Packages Check / Install Karein
```powershell
py -3.11 -m pip install -r requirements.txt
```

### Step 4.2: Automated Tests Chalayein
Yeh command tamam 22 tests chalaye gi aur verify kare gi k sensitivity math, database, security, aur GUI theek hain:
```powershell
py -3.11 -m pytest tests/ -v
```

### Step 4.3: Desktop Par App Run Karein
App ko desktop screen par dekhne k liye yeh command chalayein:
```powershell
py -3.11 main.py
```
App phone screen size (420x780) me pop-up ho kar start ho jaye gi jahan aap har button ko tap kar k test kar sakte hain.

---

## 5. Admin Panel Aur Pro Key Ka Istemal

1. Home Dashboard k top right corner me **Admin** button par click karein.
2. **Username**: `privatesmk225`
3. **Pehli Baar (First-Run)**: App aapse kahe gi k apna password enter karein aur confirm karein. Apna pasandeeda password darj karein.
4. Login hone k baad Admin Panel me aap:
   - Naye **Lifetime** ya **30 Days / 90 Days** Pro Keys bana sakte hain.
   - Keys ki list dekh sakte hain.
   - Kisi b key ko Copy kar sakte hain ya Revoke (band) kar sakte hain.
   - Admin password change kar sakte hain.
5. Home screen par wapis aakar **Activate Pro Key** par tap karein aur banayi hui key paste karein. Pro status unlock ho jaye ga!

---

## 6. Android APK Build Kese Karein (WSL / Ubuntu)

Android APK build karne k liye Google k toolchains Linux par run hote hain. Agar aap Windows par hain to WSL install kar k build kar sakte hain:

### Step 6.1: WSL Install Karein (Agar pehlay se nahi hai)
PowerShell ko **Run as Administrator** open karein aur yeh command chalayein:
```powershell
wsl --install -d Ubuntu
```
Computer restart karein aur Ubuntu ka username/password set karein.

### Step 6.2: Ubuntu Terminal Me Build Tools Install Karein
Ubuntu terminal open karein aur yeh command run karein:
```bash
sudo apt update
sudo apt install -y git zip unzip openjdk-17-jdk python3-pip autoconf libtool pkg-config zlib1g-dev libncurses5-dev libncursesw5-dev libtinfo5 cmake libffi-dev libssl-dev
pip install --user --upgrade buildozer cython virtualenv
```

### Step 6.3: Project Folder Me Jayein Aur APK Build Karein
```bash
cd /mnt/d/SMK_PRO_SENSITIVITY_PYTHON
buildozer -v android debug
```
Pehli baar build hone me 10-15 minute lag sakte hain kyun k Buildozer Android SDK aur NDK download karta hai.

### Step 6.4: APK Kahan Mile Gi?
Build complete hone par APK is folder me save hoti hai:
`/mnt/d/SMK_PRO_SENSITIVITY_PYTHON/bin/smkprosensitivity-2.5.0-arm64-v8a_armeabi-v7a-debug.apk`
Windows Explorer me path yeh hoga:
`D:\SMK_PRO_SENSITIVITY_PYTHON\bin\`

---

## 7. Complete Project Ki ZIP Kahan Hai?

Mukammal project ki ZIP archive workspace k root me mojood hai:
`D:\SMK_PRO_SENSITIVITY_PYTHON\SMK_PRO_SENSITIVITY_PYTHON.zip`

Aap is ZIP file ko kisi b computer ya dost ko send kar sakte hain.

---

## 8. Common Problems Aur Solutions (Troubleshooting)

### Masla 1: `python: command not found` ya `No module named kivy`
- **Waja**: Default Python 3.14 me Kivy C-extensions ka wheel mojood nahi hota.
- **Solution**: Hamesha `py -3.11` istemal karein jesa k:
  ```powershell
  py -3.11 main.py
  ```

### Masla 2: Phone par lag ya low FPS feel ho raha hai
- **Solution**: App k **Settings** screen me ja kar **Reduced Motion Mode** ko ON kar dein. Is se background wave animations stop ho jayengi aur low-end devices par battery aur CPU save hoga.

### Masla 3: Free Fire me headshot nahi lag raha
- **Solution**: App k **Help & Guide** screen me Training Ground calibration steps parhein. General sensitivity ko +4 ya -4 adjust kar k test dummy par fire karein taake recoil lock ho sakay.
