# SMK PRO SENSITIVITY — Python & Kivy Edition

**SMK PRO SENSITIVITY** is a high-performance, 100% offline gaming sensitivity optimizer built with Python 3 and Kivy. Engineered for competitive mobile gaming (Free Fire) players who need deterministic, hardware-tailored sensitivity values (0–200 range) without risky game modifications or third-party hacks.

---

## ⚡ Key Highlights

- **Rules-Based Deterministic Engine**: Generates mathematically balanced 0–200 sensitivities across 6 channels:
  - General Sensitivity
  - Red Dot Sight
  - 2x Scope
  - 4x Scope
  - Sniper Scope (ADS)
  - Free Camera Button
- **Hardware-Aware Tuning**: Optimizes for 60Hz, 90Hz, 120Hz, and 144Hz displays, touch sampling latency, graphics levels, and HUD claw finger ergonomics (2, 3, 4, 5 finger).
- **Offline Phone Database**: Pre-seeded SQLite database with 25+ verified popular gaming smartphones (Poco, Xiaomi, Infinix, Tecno, Samsung, Realme, OnePlus, Asus ROG, Apple).
- **Full Profile Management**: Create, load, clone, rename, compare differences, export, and delete custom sensitivity profiles.
- **PBKDF2 Password-Protected Local Admin Panel**: Salted PBKDF2-HMAC-SHA256 owner authentication (`privatesmk225`) with login attempt limits, temporary lockout, and offline key management.
- **Offline Pro Key Management**: Generate and validate lifetime and limited-duration pro activation keys (`SMK-XXXXXXXX-XXXX`) with algorithmic checksum verification.
- **Cryptographic Backup & Restore**: Export and restore profiles and custom devices using SHA256 integrity-verified JSON files.
- **Zero-Cost & Fair Play**: 100% free, no paid APIs, no subscriptions, no tracking, and strict zero-game-memory injection.

---

## 📁 Project Architecture

```
SMK_PRO_SENSITIVITY_PYTHON/
├── main.py                  # Kivy application bootstrap and ScreenManager
├── requirements.txt         # Production and development dependencies
├── buildozer.spec           # Buildozer Android packaging configuration
├── README.md                # Comprehensive project documentation
├── STEP_BY_STEP_GUIDE.md    # Beginner-friendly guide in Roman Urdu
├── BUILD_AND_TEST_REPORT.md # Verification report with test execution logs
├── core/
│   ├── __init__.py
│   └── config.py            # App constants, neon theme palettes, file paths
├── database/
│   ├── __init__.py
│   ├── db.py                # SQLite connection, CRUD operations, transactions
│   └── seeds.py             # 25+ verified gaming phone specifications
├── security/
│   ├── __init__.py
│   ├── auth.py              # PBKDF2 password hashing, salt, attempt lockout
│   └── keys.py              # Offline key generator, duration tracking, gating
├── services/
│   ├── __init__.py
│   ├── sensitivity_engine.py# Mathematical 0-200 sensitivity calculations
│   ├── device_service.py    # Hardware detection and verification flags
│   ├── profile_service.py   # Business logic for user sensitivity profiles
│   └── backup_service.py    # SHA256 integrity checked backup/restore
├── localization/
│   ├── __init__.py
│   └── locales.py           # English, Roman Urdu, and Urdu script translations
├── widgets/
│   ├── __init__.py
│   ├── neon_widgets.py      # NeonButton with ripple, glowing cards, wave bg
│   └── dialogs.py           # Confirmation dialogs, alerts, and input modals
├── screens/
│   ├── __init__.py
│   ├── nav_header.py        # Reusable glowing navigation top bar
│   ├── splash_screen.py     # Animated cyber splash view
│   ├── home_screen.py       # Main dashboard with quick action tiles
│   ├── generator_screen.py  # Interactive sensitivity calculator
│   ├── device_screen.py     # Hardware inspection & confirmation
│   ├── phone_db_screen.py   # Searchable offline phone database
│   ├── profiles_screen.py   # Saved profiles management & compare
│   ├── admin_login_screen.py# Password-protected admin gateway
│   ├── admin_panel_screen.py# Pro key generation & system statistics
│   ├── feedback_screen.py   # Community feedback & WhatsApp share
│   ├── settings_screen.py   # Themes, motion toggle, language selector
│   ├── backup_screen.py     # Offline backup export & restore
│   ├── help_screen.py       # Training ground 1-tap calibration guide
│   └── about_screen.py      # Legal disclaimer & external channel links
└── tests/
    ├── __init__.py
    ├── test_sensitivity.py  # Math bounds, 120Hz vs 60Hz dynamics tests
    ├── test_auth.py         # PBKDF2 hashing, lockout rate limits
    ├── test_keys.py         # Key generation, checksum, activation tests
    ├── test_database.py     # SQLite seeding, profile CRUD tests
    ├── test_backup.py       # Backup SHA256 integrity & tamper tests
    ├── test_localization.py # Language translation completeness tests
    └── test_gui.py          # Kivy screen registration smoke tests
```

---

## 🚀 Running on Desktop (Windows / Linux / macOS)

### 1. Requirements
- Python 3.10, 3.11, or 3.12 (Recommended: Python 3.11)
- Pip package manager

### 2. Install Dependencies
```bash
py -3.11 -m pip install -r requirements.txt
```

### 3. Run Automated Tests
```bash
py -3.11 -m pytest tests/ -v
```

### 4. Launch the App
```bash
py -3.11 main.py
```

---

## 📱 Building Android APK with Buildozer

Because Buildozer requires a POSIX environment (Linux) to manage the Android SDK, NDK, and cross-compilation toolchains, compile using **WSL (Windows Subsystem for Linux)**, **Ubuntu Linux**, or **GitHub Actions**.

### Ubuntu / WSL Setup Commands
```bash
# 1. Install system build dependencies
sudo apt update
sudo apt install -y git zip unzip openjdk-17-jdk python3-pip autoconf libtool pkg-config zlib1g-dev libncurses5-dev libncursesw5-dev libtinfo5 cmake libffi-dev libssl-dev

# 2. Install buildozer and cython
pip install --user --upgrade buildozer cython virtualenv

# 3. Build Debug APK
buildozer -v android debug
```
The output APK will be placed in the `bin/` directory:
`bin/smkprosensitivity-2.5.0-arm64-v8a_armeabi-v7a-debug.apk`

---

## 🔒 Security & Admin Setup

- **Owner Username**: `privatesmk225`
- **Initial Setup**: On first opening the Admin Panel, the app prompts for the owner password. It is hashed using PBKDF2-HMAC-SHA256 with 120,000 iterations and a cryptographically random salt. No plain passwords are stored or logged.
- **Lockout Policy**: After 5 failed attempts, the admin panel locks out attempts for 5 minutes.

---

## ⚖️ Legal Disclaimer

*SMK PRO SENSITIVITY is an independent tool and is NOT affiliated with, sponsored by, or endorsed by Garena or Free Fire. This tool does NOT alter game memory, files, or network streams. All generated settings are applied manually by the player in their in-game settings menu.*
